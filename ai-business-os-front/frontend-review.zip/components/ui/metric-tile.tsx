import type { CSSProperties } from "react";

import { Surface } from "@/components/ui/surface";
import { cn } from "@/lib/cn";

type MetricTileVariant = "revenue" | "expense" | "flow" | "marketing" | "cac" | "romi" | "default";

type MetricTileProps = {
  label: string;
  value: string;
  note: string;
  size?: "compact" | "regular" | "wide" | "hero";
  variant?: MetricTileVariant;
  uiScale?: number;
};

const METRIC_TILE_THEMES: Record<
  MetricTileVariant,
  {
    icon: string;
    iconBg: string;
    iconText: string;
    topAccent: string;
    noteBadge: string;
    titleAccent: string;
    spark: number[];
  }
> = {
  revenue: {
    icon: "R",
    iconBg: "bg-emerald-50 ring-emerald-100",
    iconText: "text-emerald-600",
    topAccent: "from-emerald-400 via-emerald-500 to-teal-500",
    noteBadge: "Выручка",
    titleAccent: "text-emerald-600",
    spark: [14, 20, 28, 22],
  },
  expense: {
    icon: "E",
    iconBg: "bg-rose-50 ring-rose-100",
    iconText: "text-rose-600",
    topAccent: "from-rose-400 via-rose-500 to-orange-500",
    noteBadge: "Расходы",
    titleAccent: "text-rose-600",
    spark: [22, 16, 12, 18],
  },
  flow: {
    icon: "F",
    iconBg: "bg-violet-50 ring-violet-100",
    iconText: "text-violet-600",
    topAccent: "from-violet-400 via-violet-500 to-indigo-500",
    noteBadge: "Поток",
    titleAccent: "text-violet-600",
    spark: [18, 26, 22, 30],
  },
  marketing: {
    icon: "M",
    iconBg: "bg-sky-50 ring-sky-100",
    iconText: "text-sky-600",
    topAccent: "from-sky-400 via-sky-500 to-cyan-500",
    noteBadge: "Маркетинг",
    titleAccent: "text-sky-600",
    spark: [10, 18, 14, 24],
  },
  cac: {
    icon: "C",
    iconBg: "bg-amber-50 ring-amber-100",
    iconText: "text-amber-700",
    topAccent: "from-amber-400 via-amber-500 to-orange-500",
    noteBadge: "CAC",
    titleAccent: "text-amber-700",
    spark: [14, 14, 22, 16],
  },
  romi: {
    icon: "%",
    iconBg: "bg-cyan-50 ring-cyan-100",
    iconText: "text-cyan-700",
    topAccent: "from-cyan-400 via-sky-500 to-blue-500",
    noteBadge: "ROMI",
    titleAccent: "text-cyan-700",
    spark: [16, 24, 28, 26],
  },
  default: {
    icon: "•",
    iconBg: "bg-violet-50 ring-violet-100",
    iconText: "text-violet-600",
    topAccent: "from-violet-400 via-violet-500 to-indigo-500",
    noteBadge: "Ядро",
    titleAccent: "text-violet-600",
    spark: [12, 16, 20, 16],
  },
};

export function MetricTile({
  label,
  value,
  note,
  size = "regular",
  variant = "default",
  uiScale = 1,
}: MetricTileProps) {
  const compact = size === "compact";
  const wide = size === "wide" || size === "hero";
  const hero = size === "hero";
  const boosted = uiScale >= 1.08;
  const theme = METRIC_TILE_THEMES[variant];
  const compactNoteStyle: CSSProperties | undefined = compact
    ? {
        display: "-webkit-box",
        WebkitBoxOrient: "vertical",
        WebkitLineClamp: 2,
        overflow: "hidden",
      }
    : undefined;

  return (
    <Surface
      className={cn(
        "relative h-full overflow-hidden",
        compact ? "p-3.5" : wide ? "p-5" : "p-4",
        compact && "bg-[linear-gradient(180deg,#ffffff_0%,#fafaff_100%)]",
      )}
    >
      <div
        className={cn(
          "absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r",
          theme.topAccent,
        )}
      />

      <div className={cn("flex h-full flex-col gap-3", compact && "pt-1")}>
        <div className="flex items-center justify-between gap-3">
          <div
            className={cn(
              "flex items-center justify-center rounded-2xl ring-1",
              compact ? (boosted ? "h-10 w-10" : "h-9 w-9") : boosted ? "h-11 w-11" : "h-10 w-10",
              theme.iconBg,
              theme.iconText,
            )}
          >
            <span className={cn("font-semibold", compact ? (boosted ? "text-[12px]" : "text-[11px]") : boosted ? "text-base" : "text-sm")}>
              {theme.icon}
            </span>
          </div>
          <span
            className={cn(
              "min-w-0 break-words text-right uppercase tracking-[0.22em] text-slate-400",
              compact ? (boosted ? "text-[11px] leading-4" : "text-[10px] leading-4") : boosted ? "text-sm" : "text-xs",
            )}
          >
            {label}
          </span>
        </div>

        <div
          className={cn(
            "grid flex-1 gap-3",
            compact
              ? "content-between"
              : wide
                ? "grid-cols-[1fr_auto]"
                : "content-center",
          )}
        >
          <div className="min-w-0">
            <p
              className={cn(
                "min-w-0 break-words font-semibold tracking-[-0.05em] text-slate-950",
                compact ? (boosted ? "text-[22px] leading-none" : "text-[20px] leading-none") : wide ? (boosted ? "text-[34px]" : "text-3xl") : boosted ? "text-[26px]" : "text-2xl",
              )}
            >
              {value}
            </p>
            <p
              className={cn(
                "break-words text-slate-500",
                compact ? (boosted ? "mt-1.5 text-sm leading-5" : "mt-1.5 text-xs leading-4") : boosted ? "mt-2 text-base leading-6" : "mt-2 text-sm leading-6",
              )}
              style={compactNoteStyle}
            >
              {note}
            </p>
            {compact ? (
              <div className="mt-2.5 grid gap-1.5">
                <div className="grid grid-cols-2 gap-1.5">
                  <div className="rounded-[14px] border border-slate-200 bg-white px-2 py-1.5">
                    <p className="text-[10px] uppercase tracking-[0.18em] text-slate-400">
                      Темп
                    </p>
                    <p className={cn("mt-0.5 break-words font-semibold leading-4", boosted ? "text-[12px]" : "text-[11px]", theme.titleAccent)}>
                      {theme.noteBadge}
                    </p>
                  </div>
                  <div className="rounded-[14px] border border-violet-100 bg-violet-50 px-2 py-1.5">
                    <p className="text-[10px] uppercase tracking-[0.18em] text-violet-400">
                      Статус
                    </p>
                    <p className={cn("mt-0.5 break-words font-semibold leading-4 text-violet-700", boosted ? "text-[12px]" : "text-[11px]")}>
                      Онлайн
                    </p>
                  </div>
                </div>
                <div className="h-1.5 rounded-full bg-slate-100">
                  <div
                    className={cn("h-full rounded-full bg-gradient-to-r", theme.topAccent)}
                    style={{ width: `${theme.spark.reduce((sum, value) => sum + value, 0) / 2}%` }}
                  />
                </div>
              </div>
            ) : null}
          </div>

          {wide ? (
            <div className={cn("grid gap-2", boosted ? "min-w-[112px]" : "min-w-[96px]")}>
              <div className="rounded-[16px] border border-slate-200 bg-slate-50 px-3 py-2">
                <p className="text-[10px] uppercase tracking-[0.22em] text-slate-400">
                  Режим
                </p>
                <p className={cn("mt-1 break-words font-semibold leading-5 text-slate-950", boosted ? "text-base" : "text-sm")}>
                  {hero ? "Hero" : "Wide"}
                </p>
              </div>
              <div className="rounded-[16px] border border-violet-100 bg-violet-50 px-3 py-2">
                <p className="text-[10px] uppercase tracking-[0.22em] text-violet-400">
                  Данные
                </p>
                <p className={cn("mt-1 break-words font-semibold leading-5 text-violet-700", boosted ? "text-base" : "text-sm")}>
                  {compact ? "Сжаты" : "Полные"}
                </p>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </Surface>
  );
}
