import type { HTMLAttributes } from "react";
import { cn } from "@/lib/cn";

type BadgeVariant = "neutral" | "accent" | "soft" | "dark";

const badgeStyles: Record<BadgeVariant, string> = {
  neutral: "border-slate-200 bg-white text-slate-700",
  accent: "border-violet-200 bg-violet-50 text-violet-700",
  soft: "border-slate-200 bg-slate-50 text-slate-500",
  dark: "border-slate-900 bg-slate-900 text-white",
};

type BadgeProps = HTMLAttributes<HTMLSpanElement> & {
  variant?: BadgeVariant;
};

export function Badge({
  className,
  variant = "neutral",
  ...props
}: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium tracking-[0.01em]",
        badgeStyles[variant],
        className,
      )}
      {...props}
    />
  );
}
