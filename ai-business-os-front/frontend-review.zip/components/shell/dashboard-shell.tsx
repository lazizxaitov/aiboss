import { Suspense, type ReactNode } from "react";

import { BusinessContextProvider } from "@/components/business/business-context-provider";
import { AppSidebar } from "@/components/shell/app-sidebar";
import { AppTopbar } from "@/components/shell/app-topbar";

export function DashboardShell({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <Suspense fallback={null}>
      <BusinessContextProvider>
      <div className="min-h-screen bg-[#eef2f8] p-4">
        <div className="flex min-h-[calc(100vh-2rem)] w-full items-stretch gap-4 text-slate-950">
          <AppSidebar />
          <div className="flex min-w-0 flex-1 flex-col gap-4">
            <AppTopbar />
            <main className="min-h-0 flex-1">{children}</main>
          </div>
        </div>
      </div>
      </BusinessContextProvider>
    </Suspense>
  );
}
