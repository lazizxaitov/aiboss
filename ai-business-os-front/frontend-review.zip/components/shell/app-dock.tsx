'use client';

import Link from "next/link";
import { usePathname } from "next/navigation";
import { dashboardNavigation } from "@/lib/navigation";
import { cn } from "@/lib/cn";

export function AppDock() {
  const pathname = usePathname();

  return (
    <div className="border-b border-slate-200 bg-white/80 backdrop-blur-xl">
      <div className="mx-auto max-w-[1600px] px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex gap-2 overflow-x-auto rounded-[24px] border border-slate-200 bg-white p-2 shadow-[0_1px_2px_rgba(15,23,42,0.03),0_10px_30px_rgba(15,23,42,0.04)]">
          {dashboardNavigation.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname === item.href || pathname.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href}
                title={item.note}
                aria-label={item.label}
                className={cn(
                  "shrink-0 rounded-2xl border px-3.5 py-2 text-sm font-medium transition-colors duration-200",
                  active
                    ? "border-violet-200 bg-violet-50 text-violet-700 shadow-sm"
                    : "border-transparent bg-white text-slate-500 hover:border-slate-200 hover:bg-slate-50 hover:text-slate-900",
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
