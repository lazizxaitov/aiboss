"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";

import { cn } from "@/lib/cn";
import { getNotifications, markAllNotificationsRead } from "@/lib/core-api";
import { emitNotificationsChanged } from "@/lib/notifications-events";
import {
  NOTIFICATION_TABS,
  getNotificationTabLabel,
  getNotificationToneLabel,
  type NotificationItem,
  type NotificationTab,
  filterNotifications,
  getUnreadCount,
} from "@/modules/alerts/notifications-data";

function formatRussianDate(date: Date) {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "numeric",
    month: "long",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function AppTopbar() {
  const now = new Date();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<NotificationTab>("All");
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const bellRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!notificationsOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node | null;
      if (target && bellRef.current?.contains(target)) return;
      setNotificationsOpen(false);
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setNotificationsOpen(false);
    };

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [notificationsOpen]);

  useEffect(() => {
    let active = true;

    void getNotifications()
      .then((feed) => {
        if (active) setNotifications(feed.items);
      })
      .catch(() => {
        if (active) setNotifications([]);
      });

    return () => {
      active = false;
    };
  }, []);

  const visibleNotifications = useMemo(() => filterNotifications(activeTab, notifications), [activeTab, notifications]);
  const unreadCount = useMemo(() => getUnreadCount("All", notifications), [notifications]);

  const handleMarkAllRead = async () => {
    try {
      setIsSyncing(true);
      await markAllNotificationsRead();
      const feed = await getNotifications();
      setNotifications(feed.items);
      emitNotificationsChanged();
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <header className="relative flex flex-wrap items-center justify-end gap-2 sm:gap-2.5">
      <label className="flex h-[40px] w-[170px] items-center gap-1.5 rounded-full bg-white px-3 text-sm text-slate-400 shadow-[0_8px_22px_rgba(15,23,42,0.04)] sm:w-[190px]">
        <span className="text-xs leading-none text-slate-300">⌕</span>
        <input
          type="search"
          placeholder="Поиск"
          className="w-full bg-transparent text-[12px] font-medium text-slate-700 outline-none placeholder:text-slate-400"
        />
      </label>

      <div className="flex items-center gap-2">
        <div className="flex h-[40px] min-w-[184px] items-center justify-center rounded-full bg-white px-4 text-[12px] font-semibold text-slate-950 shadow-[0_8px_22px_rgba(15,23,42,0.04)]">
          {formatRussianDate(now)}
        </div>

        <div ref={bellRef} className="relative">
          <button
            type="button"
            className="relative flex h-[40px] w-[40px] items-center justify-center rounded-full bg-white text-slate-950 shadow-[0_8px_22px_rgba(15,23,42,0.04)] transition hover:bg-slate-50"
            aria-label="Уведомления"
            aria-expanded={notificationsOpen}
            aria-haspopup="dialog"
            onClick={() => setNotificationsOpen((current) => !current)}
          >
            <span className="text-[15px] leading-none">🔔</span>
            {unreadCount > 0 ? <span className="absolute right-0 top-0 h-2.5 w-2.5 rounded-full bg-violet-500 ring-2 ring-white" /> : null}
          </button>

          {notificationsOpen ? (
            <div className="absolute right-0 top-[calc(100%+12px)] z-50 w-[min(92vw,820px)] overflow-hidden rounded-[32px] border border-slate-200 bg-white shadow-[0_30px_90px_rgba(15,23,42,0.18)]">
              <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-5">
                <div>
                  <h2 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">Уведомления</h2>
                  <p className="mt-2 text-sm font-medium text-slate-400">{unreadCount} непрочитанных</p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium text-slate-500 transition hover:bg-slate-50 hover:text-slate-950"
                    onClick={() => void handleMarkAllRead()}
                    disabled={isSyncing}
                  >
                    <span className="text-lg leading-none">✓✓</span>
                    {isSyncing ? "Обновляем..." : "Отметить все как прочитанные"}
                  </button>
                  <button
                    type="button"
                    className="flex h-10 w-10 items-center justify-center rounded-full border border-slate-200 text-slate-500 transition hover:bg-slate-50 hover:text-slate-950"
                    aria-label="Settings"
                  >
                    ⚙
                  </button>
                </div>
              </div>

              <div className="flex gap-3 overflow-x-auto border-b border-slate-100 px-6 py-4">
                {NOTIFICATION_TABS.map((tab) => {
                  const active = activeTab === tab;
                  const count = getUnreadCount(tab, notifications);
                  return (
                    <button
                      key={tab}
                      type="button"
                      onClick={() => setActiveTab(tab)}
                      className={cn(
                        "inline-flex shrink-0 items-center gap-2 rounded-full px-3 py-2 text-sm font-medium transition",
                        active ? "bg-violet-50 text-violet-600" : "text-slate-400 hover:bg-slate-50 hover:text-slate-700",
                      )}
                    >
                      <span>{getNotificationTabLabel(tab)}</span>
                      {active ? <span className="inline-flex h-6 min-w-6 items-center justify-center rounded-full bg-violet-600 px-2 text-xs font-semibold text-white">{count}</span> : null}
                    </button>
                  );
                })}
              </div>

              <div className="max-h-[520px] overflow-y-auto">
                {visibleNotifications.length > 0 ? (
                  visibleNotifications.map((item) => (
                    <article
                      key={item.id}
                      className={cn(
                        "border-b border-slate-100 px-6 py-5 last:border-b-0",
                        item.read ? "bg-white/70" : "bg-white",
                      )}
                    >
                      <div className="flex items-start gap-4">
                        <NotificationGlyph tone={item.tone} />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-4">
                            <div className="min-w-0">
                              <div className="flex items-center gap-3">
                                <h3 className="truncate text-[19px] font-semibold tracking-[-0.03em] text-slate-950">{item.title}</h3>
                                <NotificationTag tone={item.tone}>{getNotificationTabLabel(item.tag)}</NotificationTag>
                              </div>
                              <p className="mt-2 max-w-3xl text-[15px] leading-7 text-slate-500">{item.message}</p>
                            </div>
                            {item.unread ? <span className="mt-2 h-3 w-3 shrink-0 rounded-full bg-violet-500" /> : null}
                          </div>

                          <div className="mt-4 flex items-center justify-between gap-4">
                            <p className="text-sm font-medium text-slate-400">{item.time}</p>
                            <Link
                              href={item.detailsHref}
                              onClick={() => setNotificationsOpen(false)}
                              className="inline-flex items-center gap-2 text-[17px] font-medium text-violet-600 transition hover:text-violet-700"
                            >
                              {item.actionLabel}
                              <span className="text-[18px] leading-none">›</span>
                            </Link>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))
                ) : (
                  <div className="px-6 py-12 text-center">
                    <p className="text-[17px] font-medium text-slate-900">Уведомлений пока нет</p>
                    <p className="mt-2 text-sm leading-6 text-slate-500">
                      Новые события появятся здесь сразу после обновления данных.
                    </p>
                  </div>
                )}
              </div>

              <div className="border-t border-slate-100 px-6 py-5">
                <Link
                  href="/alerts"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-full py-3 text-[17px] font-semibold text-violet-600 transition hover:bg-violet-50"
                  onClick={() => setNotificationsOpen(false)}
                >
                  Все уведомления
                  <span className="text-[20px] leading-none">›</span>
                </Link>
              </div>
            </div>
          ) : null}
        </div>

        <Link
          href="/settings"
          className="flex h-[40px] w-[40px] items-center justify-center overflow-hidden rounded-full bg-slate-950 text-sm font-semibold text-white shadow-[0_8px_22px_rgba(15,23,42,0.08)]"
          aria-label="Настройки"
        >
          <span className="text-[12px]">А</span>
        </Link>
      </div>
    </header>
  );
}

function NotificationGlyph({ tone }: { tone: NotificationItem["tone"] }) {
  const toneClasses: Record<NotificationItem["tone"], string> = {
    ai: "bg-violet-100 text-violet-600",
    success: "bg-emerald-100 text-emerald-600",
    danger: "bg-rose-100 text-rose-600",
    info: "bg-sky-100 text-sky-600",
  };

  const icon = tone === "success" ? "✓" : tone === "danger" ? "✕" : tone === "info" ? "i" : "✦";
  return (
    <div className={cn("flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl text-[28px]", toneClasses[tone])}>
      {icon}
    </div>
  );
}

function NotificationTag({ tone, children }: { tone: NotificationItem["tone"]; children: string }) {
  const toneClasses: Record<NotificationItem["tone"], string> = {
    ai: "bg-violet-100 text-violet-600",
    success: "bg-emerald-100 text-emerald-600",
    danger: "bg-rose-100 text-rose-600",
    info: "bg-sky-100 text-sky-600",
  };

  return (
    <span className={cn("inline-flex rounded-full px-3 py-1 text-xs font-semibold", toneClasses[tone])}>
      {children}
      <span className="sr-only">{getNotificationToneLabel(tone)}</span>
    </span>
  );
}
