"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

import { cn } from "@/lib/cn";
import { getNotifications } from "@/lib/core-api";
import { NOTIFICATIONS_CHANGED_EVENT } from "@/lib/notifications-events";

type SidebarItem = {
  label: string;
  href: string;
  icon:
    | "dashboard"
    | "analytics"
    | "sales"
    | "visits"
    | "product"
    | "inventory"
    | "customer"
    | "payout"
    | "profile"
    | "inbox"
    | "settings";
  badge?: number;
};

const mainItems: SidebarItem[] = [
  { label: "Панель", href: "/", icon: "dashboard" },
  { label: "Аналитика", href: "/ceo", icon: "analytics" },
  { label: "Продажи", href: "/sales", icon: "sales" },
  { label: "Визиты", href: "/visits", icon: "visits" },
  { label: "Товары", href: "/products", icon: "product" },
  { label: "Склад", href: "/inventory", icon: "inventory" },
  { label: "Клиенты", href: "/customers", icon: "customer" },
  { label: "Финансы", href: "/finance", icon: "payout" },
];

const settingsItems: SidebarItem[] = [
  { label: "Профиль", href: "/settings", icon: "profile" },
  { label: "Входящие", href: "/alerts", icon: "inbox" },
  { label: "Настройки", href: "/settings", icon: "settings" },
];

function isActive(pathname: string, href: string) {
  if (href === "/") {
    return pathname === "/";
  }

  return pathname === href || pathname.startsWith(`${href}/`);
}

function SidebarIcon({ name, active }: { name: SidebarItem["icon"]; active?: boolean }) {
  const stroke = active ? "#334155" : "#9bb0c8";

  switch (name) {
    case "dashboard":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3.5" y="3.5" width="6.5" height="7" rx="1.2" />
          <rect x="13.9" y="3.5" width="6.5" height="13" rx="1.2" />
          <rect x="3.5" y="13.2" width="6.5" height="7.3" rx="1.2" />
        </svg>
      );
    case "analytics":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 19.5h16" />
          <path d="M7 16V11" />
          <path d="M12 16V7.5" />
          <path d="M17 16V9.5" />
        </svg>
      );
    case "sales":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 19.5h16" />
          <path d="M6 16.5V13" />
          <path d="M11 16.5V9.5" />
          <path d="M16 16.5V6.5" />
          <path d="M5.5 7.5l4 3 4.8-4 4.2 2.5" />
        </svg>
      );
    case "visits":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 20s6-4.8 6-10a6 6 0 1 0-12 0c0 5.2 6 10 6 10Z" />
          <circle cx="12" cy="10" r="2.2" />
        </svg>
      );
    case "product":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 7.5h14v10.2a1.8 1.8 0 0 1-1.8 1.8H6.8A1.8 1.8 0 0 1 5 17.7z" />
          <path d="M8 7.5a4 4 0 0 1 8 0" />
        </svg>
      );
    case "inventory":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4.5 8.5 12 4l7.5 4.5v7L12 20l-7.5-4.5z" />
          <path d="M4.5 8.5 12 13l7.5-4.5" />
          <path d="M12 13v7" />
        </svg>
      );
    case "customer":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="9" cy="8" r="2.8" />
          <path d="M4.8 18.2a4.6 4.6 0 0 1 8.4 0" />
          <circle cx="17.5" cy="9.2" r="2.1" />
          <path d="M14.8 18a4 4 0 0 1 5.7-2.8" />
        </svg>
      );
    case "payout":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <rect x="4.5" y="5" width="15" height="14" rx="2.4" />
          <path d="M8 9.2h8" />
          <path d="M8 12h6" />
          <path d="M8 14.8h4.5" />
        </svg>
      );
    case "profile":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="8.2" r="3" />
          <path d="M5.5 19a6.7 6.7 0 0 1 13 0" />
        </svg>
      );
    case "inbox":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <rect x="4.5" y="5.5" width="15" height="13" rx="2.3" />
          <path d="M4.8 13.2h4l1.2 2h4l1.2-2h4" />
        </svg>
      );
    case "settings":
      return (
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke={stroke} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3.1" />
          <path d="M19 12a7 7 0 0 0-.1-1.1l2-1.5-2-3.4-2.4 1a7.2 7.2 0 0 0-1.9-1.1l-.4-2.6H9.8l-.4 2.6a7.2 7.2 0 0 0-1.9 1.1l-2.4-1-2 3.4 2 1.5A7 7 0 0 0 5 12a7 7 0 0 0 .1 1.1l-2 1.5 2 3.4 2.4-1a7.2 7.2 0 0 0 1.9 1.1l.4 2.6h4.4l.4-2.6a7.2 7.2 0 0 0 1.9-1.1l2.4 1 2-3.4-2-1.5A7 7 0 0 0 19 12Z" />
        </svg>
      );
  }
}

function SidebarLink({ item, active }: { item: SidebarItem; active: boolean }) {
  return (
    <Link
      href={item.href}
      title={item.label}
      className={cn(
        "group flex items-center justify-between gap-3 rounded-full px-3.5 py-2.5 text-[14px] font-medium transition-colors",
        active
          ? "border border-slate-200 bg-[#f4f7fb] text-slate-950 shadow-[0_8px_24px_rgba(15,23,42,0.06)]"
          : "text-[#9db5d1] hover:text-[#7f9bbd]",
      )}
    >
      <span className="flex min-w-0 items-center gap-4">
        <span
          className={cn(
            "flex h-4.5 w-4.5 shrink-0 items-center justify-center",
            active ? "text-slate-700" : "text-[#9bb0c8]",
          )}
        >
          <SidebarIcon name={item.icon} active={active} />
        </span>
        <span className="truncate">{item.label}</span>
      </span>

      {typeof item.badge === "number" && item.badge > 0 ? (
        <span className="flex h-8 min-w-8 items-center justify-center rounded-full bg-[#f65f5f] px-2 text-sm font-semibold text-white shadow-sm">
          {item.badge}
        </span>
      ) : null}
    </Link>
  );
}

export function AppSidebar() {
  const pathname = usePathname();
  const [inboxCount, setInboxCount] = useState(0);

  useEffect(() => {
    let active = true;

    void getNotifications()
      .then((feed) => {
        if (active) setInboxCount(feed.unread_count);
      })
      .catch(() => {
        if (active) setInboxCount(0);
      });

    const refresh = () => {
      void getNotifications()
        .then((feed) => setInboxCount(feed.unread_count))
        .catch(() => setInboxCount(0));
    };

    window.addEventListener(NOTIFICATIONS_CHANGED_EVENT, refresh);

    return () => {
      active = false;
      window.removeEventListener(NOTIFICATIONS_CHANGED_EVENT, refresh);
    };
  }, []);

  const itemsWithCounts = settingsItems.map((item) =>
    item.icon === "inbox" ? { ...item, badge: inboxCount } : item,
  );

  return (
    <aside className="hidden shrink-0 bg-[#eef2f8] px-4 py-4 lg:sticky lg:top-4 lg:flex lg:h-[calc(100vh-2rem)] lg:w-[288px] xl:w-[300px] lg:self-start">
      <div className="flex h-full w-full flex-col overflow-hidden rounded-[32px] bg-white px-4 pb-4 pt-10 shadow-[0_24px_60px_rgba(15,23,42,0.04)]">
        <div className="px-1">
          <div className="flex items-center gap-2.5">
            <div className="relative h-9 w-9">
              <div className="absolute inset-y-1 left-1.5 w-4.5 rounded-full bg-black" />
              <div className="absolute inset-y-1 right-0 w-4.5 rounded-full bg-[#cfe0ff]" />
            </div>
            <div className="text-[18px] font-medium tracking-[-0.06em] text-slate-950">
              AI БОС
            </div>
          </div>
        </div>

        <div className="mt-8 px-1">
          <p className="text-[12px] font-medium text-[#c0c0c0]">Administrator</p>
        </div>

        <nav className="mt-2.5 space-y-2">
          {mainItems.map((item) => (
            <SidebarLink key={item.href} item={item} active={isActive(pathname, item.href)} />
          ))}
        </nav>

        <div className="mt-8 px-1">
          <p className="text-[12px] font-medium text-[#c0c0c0]">Settings</p>
        </div>

        <nav className="mt-2.5 space-y-2">
          {itemsWithCounts.map((item) => (
            <SidebarLink key={item.href + item.label} item={item} active={isActive(pathname, item.href)} />
          ))}
        </nav>

        <div className="mt-auto flex flex-col items-center gap-3 pt-4 lg:pt-6">
          <div className="flex items-center gap-2 text-[#97aac0]">
            <span className="text-[16px] leading-none text-black">☀</span>
            <div className="relative h-6 w-10.5 rounded-full bg-[#c0d2e7] p-0.5">
              <div className="h-4.5 w-4.5 rounded-full bg-white shadow-[0_2px_8px_rgba(15,23,42,0.12)]" />
            </div>
            <span className="text-[14px] leading-none">☾</span>
          </div>

          <p className="text-center text-[11px] leading-none text-[#adc0d4]">© Copyright AI БОС 2026</p>
        </div>
      </div>
    </aside>
  );
}
