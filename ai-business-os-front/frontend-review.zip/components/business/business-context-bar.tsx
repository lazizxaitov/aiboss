"use client";

import { useMemo, useState } from "react";

import { Badge } from "@/components/ui/badge";
import { Surface } from "@/components/ui/surface";
import {
  useBusinessContext,
  useSelectedOrganizationNames,
  type BusinessContextOrganizationOption,
} from "@/components/business/business-context-provider";
import type { AnalyticsPeriodPreset } from "@/lib/core-api";

const PERIOD_OPTIONS: Array<{ value: AnalyticsPeriodPreset; label: string }> = [
  { value: "today", label: "Сегодня" },
  { value: "7d", label: "7 дней" },
  { value: "30d", label: "30 дней" },
  { value: "current_month", label: "Этот месяц" },
  { value: "previous_month", label: "Прошлый месяц" },
  { value: "all", label: "Весь период" },
  { value: "custom", label: "Произвольный" },
];

function formatDateLabel(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

function buildSelectionLabel(names: string[]) {
  if (names.length <= 1) return names[0] ?? "Все организации";
  if (names.length === 2) return `${names[0]} + ${names[1]}`;
  return `${names[0]} + ещё ${names.length - 1}`;
}

function OrganizationOption({
  option,
  selected,
  onToggle,
}: {
  option: BusinessContextOrganizationOption;
  selected: boolean;
  onToggle: (id: string) => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-slate-200 px-3 py-2.5 text-sm text-slate-700 transition hover:border-slate-300 hover:bg-slate-50">
      <input
        type="checkbox"
        checked={selected}
        onChange={() => onToggle(option.id)}
        className="h-4 w-4 rounded border-slate-300 text-violet-600 focus:ring-violet-500"
      />
      <span className="truncate">{option.name}</span>
    </label>
  );
}

export function BusinessContextBar() {
  const {
    state,
    availableOrganizations,
    loading,
    setOrganizationSelection,
    setPeriodPreset,
    setCustomPeriod,
  } = useBusinessContext();
  const selectedNames = useSelectedOrganizationNames();
  const [organizationsOpen, setOrganizationsOpen] = useState(false);
  const [customOpen, setCustomOpen] = useState(false);
  const [draftFrom, setDraftFrom] = useState(state.period.dateFrom ?? "");
  const [draftTo, setDraftTo] = useState(state.period.dateTo ?? "");

  const selectedSet = useMemo(
    () => new Set(state.selectedOrganizationIds),
    [state.selectedOrganizationIds],
  );

  const organizationLabel = buildSelectionLabel(selectedNames);
  const periodLabel =
    PERIOD_OPTIONS.find((item) => item.value === state.period.preset)?.label ?? "30 дней";

  const toggleOrganization = (organizationId: string) => {
    const next = selectedSet.has(organizationId)
      ? state.selectedOrganizationIds.filter((item) => item !== organizationId)
      : [...state.selectedOrganizationIds, organizationId];
    setOrganizationSelection(next);
  };

  return (
    <Surface className="relative overflow-visible px-4 py-4 sm:px-5">
      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div className="min-w-0">
          <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">Глобальный контекст</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button
              type="button"
              className="inline-flex min-w-[230px] items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-left text-sm font-medium text-slate-950 transition hover:border-slate-300"
              onClick={() => setOrganizationsOpen((current) => !current)}
            >
              <span className="truncate">{loading ? "Загрузка организаций..." : organizationLabel}</span>
              <span className="text-slate-400">{organizationsOpen ? "▴" : "▾"}</span>
            </button>

            <div className="flex flex-wrap gap-2">
              {PERIOD_OPTIONS.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={
                    state.period.preset === option.value
                      ? "inline-flex items-center rounded-full border border-violet-200 bg-violet-50 px-3 py-2 text-sm font-medium text-violet-700"
                      : "inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-500 transition hover:border-slate-300 hover:text-slate-700"
                  }
                  onClick={() => {
                    setPeriodPreset(option.value);
                    setCustomOpen(option.value === "custom");
                  }}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {state.period.preset === "custom" ? (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge variant="soft">
                {formatDateLabel(state.period.dateFrom)} → {formatDateLabel(state.period.dateTo)}
              </Badge>
              <button
                type="button"
                className="text-sm font-medium text-violet-600 transition hover:text-violet-700"
                onClick={() => setCustomOpen((current) => !current)}
              >
                Изменить период
              </button>
            </div>
          ) : null}
        </div>

        <div className="flex flex-wrap items-center gap-2 text-sm text-slate-500">
          <Badge variant="soft">
            {state.organizationMode === "ALL"
              ? "Режим: все организации"
              : state.organizationMode === "SINGLE"
                ? "Режим: одна организация"
                : "Режим: несколько организаций"}
          </Badge>
          <Badge variant="soft">Период: {periodLabel}</Badge>
        </div>
      </div>

      {organizationsOpen ? (
        <div className="absolute left-4 right-4 top-[calc(100%+12px)] z-40 rounded-[24px] border border-slate-200 bg-white p-4 shadow-[0_24px_60px_rgba(15,23,42,0.12)] sm:left-5 sm:right-auto sm:w-[420px]">
          <div className="flex items-center justify-between gap-3">
            <h3 className="text-sm font-semibold text-slate-950">Организации</h3>
            <button
              type="button"
              className="text-sm font-medium text-violet-600 transition hover:text-violet-700"
              onClick={() => setOrganizationSelection([])}
            >
              Все организации
            </button>
          </div>
          <div className="mt-3 max-h-[320px] space-y-2 overflow-y-auto pr-1">
            {availableOrganizations.map((option) => (
              <OrganizationOption
                key={option.id}
                option={option}
                selected={selectedSet.has(option.id)}
                onToggle={toggleOrganization}
              />
            ))}
          </div>
        </div>
      ) : null}

      {customOpen ? (
        <div className="mt-4 rounded-[22px] border border-slate-200 bg-slate-50/70 p-4">
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="space-y-1.5 text-sm text-slate-500">
              <span>Дата начала</span>
              <input
                type="date"
                value={draftFrom}
                onChange={(event) => setDraftFrom(event.target.value)}
                className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-slate-950 outline-none transition focus:border-violet-300"
              />
            </label>
            <label className="space-y-1.5 text-sm text-slate-500">
              <span>Дата конца</span>
              <input
                type="date"
                value={draftTo}
                onChange={(event) => setDraftTo(event.target.value)}
                className="w-full rounded-2xl border border-slate-200 bg-white px-3 py-2.5 text-slate-950 outline-none transition focus:border-violet-300"
              />
            </label>
          </div>
          <div className="mt-3 flex items-center justify-end gap-2">
            <button
              type="button"
              className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-600 transition hover:border-slate-300 hover:text-slate-900"
              onClick={() => setCustomOpen(false)}
            >
              Скрыть
            </button>
            <button
              type="button"
              className="rounded-full bg-slate-950 px-4 py-2 text-sm font-medium text-white transition hover:bg-slate-800"
              onClick={() => {
                if (draftFrom && draftTo) {
                  setCustomPeriod(draftFrom, draftTo);
                  setCustomOpen(false);
                }
              }}
            >
              Применить
            </button>
          </div>
        </div>
      ) : null}
    </Surface>
  );
}
