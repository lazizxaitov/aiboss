"use client";

import { useEffect, useState } from "react";

import {
  getSmartUpOrganizations,
  getSmartUpMigrationCompleteness,
  getSmartUpMigrationJob,
  migrateAllSmartUpOrganizations,
  resetSmartUpImportedData,
  syncSmartUpOrganizationsFromEnv,
  testSmartUpOrganizationConnection,
  type SmartUpAccessPayload,
  type SmartUpConnectionCheckResponse,
  type SmartUpCompletenessReport,
  type SmartUpMigrationJobResponse,
  type SmartUpMigrationAllResponse,
  type SmartUpMigrationMode,
  type SmartUpOrganization,
} from "@/lib/core-api";

type SmartUpOrganizationRow = {
  id: string;
  name: string;
  company_id: string;
  filial_id: string;
  project_code: string;
  sort_order: number;
  is_active: boolean;
  last_sync_at: string | null;
  isDraft: boolean;
};

type SmartUpAuthFormState = {
  baseUrl: string;
  username: string;
  password: string;
  timeoutSeconds: string;
};

type SmartUpStatusPanelResult =
  | SmartUpConnectionCheckResponse
  | SmartUpMigrationAllResponse
  | SmartUpCompletenessReport
  | null;

function toRow(organization: SmartUpOrganization): SmartUpOrganizationRow {
  return {
    id: organization.id,
    name: organization.name,
    company_id: organization.company_id,
    filial_id: organization.filial_id,
    project_code: organization.project_code,
    sort_order: organization.sort_order,
    is_active: organization.is_active,
    last_sync_at: organization.last_sync_at,
    isDraft: false,
  };
}

const initialAuthState: SmartUpAuthFormState = {
  baseUrl: "https://smartup.online",
  username: "",
  password: "",
  timeoutSeconds: "30",
};

const SMARTUP_MIGRATION_JOB_STORAGE_KEY = "smartup:last-migration-job-id";

export function SmartUpAccessForm() {
  const [auth, setAuth] = useState<SmartUpAuthFormState>(initialAuthState);
  const [organizations, setOrganizations] = useState<SmartUpOrganizationRow[]>([]);
  const [loadingOrganizations, setLoadingOrganizations] = useState(true);
  const [organizationBootstrapState, setOrganizationBootstrapState] = useState<{
    status: "idle" | "loading" | "success" | "error";
    message: string;
  }>({ status: "idle", message: "" });
  const [resetState, setResetState] = useState<{
    status: "idle" | "loading" | "success" | "error";
    message: string;
  }>({ status: "idle", message: "" });
  const [testingOrganizationId, setTestingOrganizationId] = useState<string | null>(null);
  const [selectedOrganizationId, setSelectedOrganizationId] = useState<string | null>(null);
  const [showMigrationErrors, setShowMigrationErrors] = useState(false);
  const [migrationMode, setMigrationMode] =
    useState<SmartUpMigrationMode>("weekly_reconciliation");
  const [fullMigrationConfirmed, setFullMigrationConfirmed] = useState(false);
  const [connectionState, setConnectionState] = useState<{
    status: "idle" | "loading" | "success" | "error";
    message: string;
    result: SmartUpConnectionCheckResponse | null;
  }>({ status: "idle", message: "", result: null });
  const [migrationState, setMigrationState] = useState<{
    status: "idle" | "loading" | "success" | "error";
    message: string;
    job: SmartUpMigrationJobResponse | null;
  }>({ status: "idle", message: "", job: null });
  const [completenessState, setCompletenessState] = useState<{
    status: "idle" | "loading" | "success" | "error";
    message: string;
    result: SmartUpCompletenessReport | null;
  }>({ status: "idle", message: "", result: null });

  async function loadOrganizations() {
    setLoadingOrganizations(true);
    try {
      const result = await getSmartUpOrganizations();
      const rows = result.items.map(toRow);
      setOrganizations(rows);
      setSelectedOrganizationId((current) =>
        current && rows.some((row) => row.id === current) ? current : rows[0]?.id ?? null,
      );
    } catch (error) {
      setConnectionState({
        status: "error",
        message: error instanceof Error ? error.message : "Не удалось загрузить организации.",
        result: null,
      });
    } finally {
      setLoadingOrganizations(false);
    }
  }

  async function syncOrganizationsFromEnv() {
    setOrganizationBootstrapState({ status: "loading", message: "Обновляем список организаций..." });
    try {
      const result = await syncSmartUpOrganizationsFromEnv();
      setOrganizationBootstrapState({
        status: "success",
        message: `Загружено ${result.loaded} организаций из настроек.`,
      });
      await loadOrganizations();
    } catch (error) {
      setOrganizationBootstrapState({
        status: "error",
        message: error instanceof Error ? error.message : "Не удалось обновить список организаций.",
      });
    }
  }

  async function resetImportedData() {
    const confirmed = window.confirm(
      "Удалить все старые данные SmartUp из базы и оставить только список организаций?",
    );
    if (!confirmed) {
      return;
    }

    setResetState({
      status: "loading",
      message: "Очищаем старые записи SmartUp...",
    });
    try {
      const result = await resetSmartUpImportedData();
      window.localStorage.removeItem(SMARTUP_MIGRATION_JOB_STORAGE_KEY);
      setMigrationState({ status: "idle", message: "", job: null });
      setCompletenessState({ status: "idle", message: "", result: null });
      setConnectionState({ status: "idle", message: "", result: null });
      setResetState({
        status: "success",
        message: `${result.message} Очищено таблиц: ${Object.keys(result.cleared_tables).length}.`,
      });
      await loadOrganizations();
    } catch (error) {
      setResetState({
        status: "error",
        message: error instanceof Error ? error.message : "Не удалось очистить данные SmartUp.",
      });
    }
  }

  useEffect(() => {
    const timer = window.setTimeout(() => {
      void loadOrganizations();
    }, 0);

    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    const savedJobId = window.localStorage.getItem(SMARTUP_MIGRATION_JOB_STORAGE_KEY);
    if (savedJobId === null) {
      return;
    }
    const jobId: string = savedJobId;

    let cancelled = false;

    async function restoreMigrationJob() {
      try {
        const job = await getSmartUpMigrationJob(jobId);
        if (cancelled) {
          return;
        }
        setMigrationState({
          status:
            job.status === "failed" ? "error" : job.status === "completed" ? "success" : "loading",
          message: job.message,
          job,
        });

        if (job.status === "pending" || job.status === "running") {
          void pollMigrationJob(job.job_id, (nextJob) => {
            if (cancelled) {
              return;
            }
            setMigrationState({
              status:
                nextJob.status === "failed"
                  ? "error"
                  : nextJob.status === "completed"
                    ? "success"
                    : "loading",
              message: nextJob.message,
              job: nextJob,
            });
            persistMigrationJob(nextJob);
          });
        } else {
          persistMigrationJob(job);
        }
      } catch {
        if (!cancelled) {
          window.localStorage.removeItem(SMARTUP_MIGRATION_JOB_STORAGE_KEY);
        }
      }
    }

    void restoreMigrationJob();

    return () => {
      cancelled = true;
    };
  }, []);

  function updateAuthField<K extends keyof SmartUpAuthFormState>(key: K, value: string) {
    setAuth((current) => ({ ...current, [key]: value }));
  }

  const selectedOrganization =
    organizations.find((organization) => organization.id === selectedOrganizationId) ?? null;

  async function testConnection(row: SmartUpOrganizationRow | null) {
    if (row === null) {
      setConnectionState({
        status: "error",
        message: "Сначала выберите организацию из списка.",
        result: null,
      });
      return;
    }
    if (!row.id) {
      setConnectionState({
        status: "error",
        message: "Сначала выберите организацию из списка.",
        result: null,
      });
      return;
    }
    setTestingOrganizationId(row.id);
    setConnectionState({ status: "loading", message: "Проверяем подключение...", result: null });
    try {
      const payload: SmartUpAccessPayload = {
        base_url: auth.baseUrl,
        username: auth.username,
        password: auth.password,
        timeout_seconds: Number(auth.timeoutSeconds) || 30,
        migration_mode: migrationMode,
      };
      const result = await testSmartUpOrganizationConnection(row.id, payload);
      setConnectionState({
        status: "success",
        message: result.connected
          ? `Соединение установлено для ${row.name}.`
          : result.message,
        result,
      });
    } catch (error) {
      setConnectionState({
        status: "error",
        message: error instanceof Error ? error.message : "Не удалось проверить соединение.",
        result: null,
      });
    } finally {
      setTestingOrganizationId(null);
    }
  }

  async function runMigration() {
    setShowMigrationErrors(false);
    setMigrationState({ status: "loading", message: "Запускаем загрузку данных...", job: null });
    try {
      const payload: SmartUpAccessPayload = {
        base_url: auth.baseUrl,
        username: auth.username,
        password: auth.password,
        timeout_seconds: Number(auth.timeoutSeconds) || 30,
        migration_mode: migrationMode,
      };
      const job = await migrateAllSmartUpOrganizations(payload);
      persistMigrationJob(job);
      setMigrationState({
        status: "loading",
        message: job.message,
        job,
      });
      await pollMigrationJob(job.job_id, (currentJob) => {
        setMigrationState({
          status:
            currentJob.status === "failed"
              ? "error"
              : currentJob.status === "completed"
                ? "success"
                : "loading",
          message: currentJob.message,
          job: currentJob,
        });
        persistMigrationJob(currentJob);
      });
    } catch (error) {
      window.localStorage.removeItem(SMARTUP_MIGRATION_JOB_STORAGE_KEY);
      setMigrationState({
        status: "error",
        message: error instanceof Error ? error.message : "Не удалось запустить миграцию.",
        job: null,
      });
    }
  }

  async function checkCompleteness() {
    if (selectedOrganization === null) {
      setCompletenessState({
        status: "error",
        message: "Сначала выберите организацию.",
        result: null,
      });
      return;
    }

    setCompletenessState({
      status: "loading",
      message: "Проверяем полноту загрузки...",
      result: null,
    });

    try {
      const result = await getSmartUpMigrationCompleteness({
        organizationId: selectedOrganization.id,
        migrationMode,
      });
      setCompletenessState({
        status: result.failed_entities > 0 || result.partial_entities > 0 ? "error" : "success",
        message: `Проверка полноты для ${selectedOrganization.name} завершена.`,
        result,
      });
    } catch (error) {
      setCompletenessState({
        status: "error",
        message: error instanceof Error ? error.message : "Не удалось проверить полноту.",
        result: null,
      });
    }
  }

  return (
    <div className="space-y-4">
      <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-slate-500">SmartUp</p>
            <h2 className="mt-2 text-lg font-semibold tracking-[-0.04em] text-slate-950">
              Подключение организаций и запуск загрузки
            </h2>
          </div>
          <button
            type="button"
            onClick={() => void syncOrganizationsFromEnv()}
            className="rounded-full border border-violet-200 bg-violet-50 px-4 py-2 text-sm font-semibold text-violet-700 transition-colors hover:bg-violet-100"
          >
            Обновить список
          </button>
        </div>

        {organizationBootstrapState.status !== "idle" ? (
          <p
            className={[
              "mt-3 rounded-[18px] border px-4 py-3 text-sm",
              organizationBootstrapState.status === "success"
                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                : organizationBootstrapState.status === "error"
                  ? "border-rose-200 bg-rose-50 text-rose-700"
                  : "border-violet-200 bg-violet-50 text-violet-700",
            ].join(" ")}
          >
            {organizationBootstrapState.message}
          </p>
        ) : null}

        {selectedOrganization ? (
          <div className="mt-4 rounded-[20px] border border-violet-200 bg-violet-50/60 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-violet-600">
              Выбрана для работы
            </p>
            <div className="mt-2 grid gap-2 md:grid-cols-3">
              <DetailRow label="Название" value={selectedOrganization.name} />
              <DetailRow label="Company ID" value={selectedOrganization.company_id} />
              <DetailRow label="filial_id" value={selectedOrganization.filial_id} />
            </div>
          </div>
        ) : null}

        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {organizations.map((organization) => {
            const selected = organization.id === selectedOrganizationId;
            return (
              <button
                key={organization.id}
                type="button"
                onClick={() => setSelectedOrganizationId(organization.id)}
                className={[
                  "rounded-[20px] border p-4 text-left transition-all",
                  selected
                    ? "border-violet-300 bg-violet-50 shadow-sm ring-4 ring-violet-100"
                    : "border-slate-200 bg-slate-50 hover:border-slate-300 hover:bg-white",
                ].join(" ")}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-950">{organization.name}</p>
                    <p className="mt-1 text-xs text-slate-500">
                      {organization.company_id} · {organization.filial_id}
                    </p>
                  </div>
                  <span
                    className={[
                      "rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.22em]",
                      selected
                        ? "bg-violet-600 text-white"
                        : "border border-slate-200 bg-white text-slate-500",
                    ].join(" ")}
                  >
                    {organization.project_code}
                  </span>
                </div>
                <div className="mt-3 flex items-center justify-between gap-2">
                  <span
                    className={[
                      "rounded-full px-2.5 py-1 text-xs font-medium",
                      organization.is_active
                        ? "bg-emerald-50 text-emerald-700"
                        : "bg-slate-100 text-slate-500",
                    ].join(" ")}
                  >
                    {organization.is_active ? "Активна" : "Неактивна"}
                  </span>
                  {selected ? (
                    <span className="text-xs font-semibold text-violet-700">Выбрана</span>
                  ) : (
                    <span className="text-xs text-slate-400">Нажмите для выбора</span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void testConnection(selectedOrganization)}
            disabled={selectedOrganization === null || testingOrganizationId !== null}
            className="rounded-full bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {testingOrganizationId !== null ? "Проверка..." : "Проверить выбранную"}
          </button>
          <button
            type="button"
            onClick={() => void syncOrganizationsFromEnv()}
            className="rounded-full border border-violet-200 bg-violet-50 px-4 py-2 text-sm font-semibold text-violet-700 transition-colors hover:bg-violet-100"
          >
            Обновить список
          </button>
          <button
            type="button"
            onClick={() => setMigrationMode("weekly_reconciliation")}
            className={[
              "rounded-full px-4 py-2 text-sm font-semibold transition-colors",
              migrationMode === "weekly_reconciliation"
                ? "border border-violet-300 bg-violet-50 text-violet-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
            ].join(" ")}
          >
            Недельная сверка
          </button>
          <button
            type="button"
            onClick={() => setMigrationMode("one_day_check")}
            className={[
              "rounded-full px-4 py-2 text-sm font-semibold transition-colors",
              migrationMode === "one_day_check"
                ? "border border-violet-300 bg-violet-50 text-violet-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
            ].join(" ")}
          >
            1 день
          </button>
          <button
            type="button"
            onClick={() => {
              if (!fullMigrationConfirmed) {
                return;
              }
              setMigrationMode("full_backfill");
            }}
            className={[
              "rounded-full px-4 py-2 text-sm font-semibold transition-colors",
              fullMigrationConfirmed
                ? migrationMode === "full_backfill"
                  ? "border border-violet-300 bg-violet-50 text-violet-700"
                  : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                : "cursor-not-allowed border border-slate-200 bg-slate-100 text-slate-400",
            ].join(" ")}
            disabled={!fullMigrationConfirmed}
          >
            Полная загрузка
          </button>
          <button
            type="button"
            onClick={() => setMigrationMode("live_sync")}
            className={[
              "rounded-full px-4 py-2 text-sm font-semibold transition-colors",
              migrationMode === "live_sync"
                ? "border border-violet-300 bg-violet-50 text-violet-700"
                : "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
            ].join(" ")}
          >
            Онлайн-обновление
          </button>
          <button
            type="button"
            onClick={() => void checkCompleteness()}
            className="rounded-full border border-violet-200 bg-violet-50 px-4 py-2 text-sm font-semibold text-violet-700 transition-colors hover:bg-violet-100"
          >
            Проверить покрытие
          </button>
          <button
            type="button"
            onClick={() => void runMigration()}
            className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50"
          >
            Запустить{" "}
            {migrationMode === "weekly_reconciliation"
              ? "Недельная сверка"
            : migrationMode === "live_sync"
                ? "Онлайн-обновление"
              : "Полная"}
          </button>
          <button
            type="button"
            onClick={() => void resetImportedData()}
            className="rounded-full border border-rose-200 bg-rose-50 px-4 py-2 text-sm font-semibold text-rose-700 transition-colors hover:bg-rose-100"
          >
            Обнулить базу
          </button>
        </div>
        {resetState.status !== "idle" ? (
          <p
            className={[
              "mt-3 rounded-[18px] border px-4 py-3 text-sm",
              resetState.status === "success"
                ? "border-emerald-200 bg-emerald-50 text-emerald-700"
                : resetState.status === "error"
                  ? "border-rose-200 bg-rose-50 text-rose-700"
                  : "border-rose-200 bg-rose-50 text-rose-700",
            ].join(" ")}
          >
            {resetState.message}
          </p>
        ) : null}
        <p className="mt-2 text-xs uppercase tracking-[0.24em] text-slate-400">
          Примерное время: {estimateMigrationDuration(migrationMode, organizations.length)}
        </p>
        <label className="mt-3 flex items-start gap-3 rounded-[18px] border border-slate-200 bg-slate-50 px-4 py-3">
          <input
            type="checkbox"
            checked={fullMigrationConfirmed}
            onChange={(event) => {
              const confirmed = event.target.checked;
              setFullMigrationConfirmed(confirmed);
              if (!confirmed && migrationMode === "full_backfill") {
                setMigrationMode("weekly_reconciliation");
              }
            }}
            className="mt-1 h-4 w-4 rounded border-slate-300 text-violet-600 focus:ring-violet-500"
          />
          <span className="text-sm leading-6 text-slate-700">
            Подтверждаю запуск <span className="font-semibold">полной загрузки</span>. Этот режим
            может занять много времени и выполнит полный исторический импорт.
          </span>
        </label>

        {loadingOrganizations ? (
          <p className="mt-3 text-sm text-slate-500">Загружаем организации...</p>
        ) : null}

        <div className="grid gap-4 lg:grid-cols-2">
          <Field
            label="Адрес SmartUp"
            value={auth.baseUrl}
            onChange={(value) => updateAuthField("baseUrl", value)}
            placeholder="https://smartup.online"
          />
          <Field
            label="Логин"
            value={auth.username}
            onChange={(value) => updateAuthField("username", value)}
            placeholder="Введите логин SmartUp"
          />
          <Field
            label="Пароль"
            type="password"
            value={auth.password}
            onChange={(value) => updateAuthField("password", value)}
            placeholder="Введите пароль SmartUp"
          />
          <Field
            label="Ожидание, сек."
            value={auth.timeoutSeconds}
            onChange={(value) => updateAuthField("timeoutSeconds", value)}
            placeholder="30"
          />
        </div>
        <p className="mt-3 text-sm leading-6 text-slate-500">
          Организации подключаются из настроек проекта. Здесь можно выбрать нужную организацию и
          проверить соединение перед загрузкой.
        </p>
        <p className="mt-1 text-xs uppercase tracking-[0.24em] text-slate-400">
          Режим миграции:{" "}
          {migrationMode === "weekly_reconciliation"
            ? "Недельная сверка"
            : migrationMode === "live_sync"
              ? "Онлайн-обновление"
              : migrationMode === "one_day_check"
                ? "1 день"
                : "Полная загрузка"}
        </p>
      </section>

      <StatusPanel title="Проверка соединения" state={connectionState} />
      <StatusPanel title="Проверка полноты" state={completenessState} />
      <StatusPanel
        title="Результат миграции"
        state={migrationState}
        showMigrationErrors={showMigrationErrors}
        onToggleMigrationErrors={() => setShowMigrationErrors((current) => !current)}
      />
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  type?: string;
}) {
  return (
    <label className="block flex-1 space-y-2">
      <span className="text-xs uppercase tracking-[0.24em] text-slate-500">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="w-full rounded-[18px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition-colors placeholder:text-slate-400 focus:border-violet-400 focus:ring-4 focus:ring-violet-100"
      />
    </label>
  );
}

function StatusPanel({
  title,
  state,
  showMigrationErrors,
  onToggleMigrationErrors,
}: {
  title: string;
  state: {
    status: "idle" | "loading" | "success" | "error";
    message: string;
    result?: SmartUpStatusPanelResult;
    job?: SmartUpMigrationJobResponse | null;
  };
  showMigrationErrors?: boolean;
  onToggleMigrationErrors?: () => void;
}) {
  if (state.status === "idle") {
    return null;
  }

  const report =
    state.job?.result ??
    (state.result && "organizations_count" in state.result
      ? (state.result as SmartUpMigrationAllResponse)
      : null);
  const completeness =
    report === null && state.result && "total_entities" in state.result
      ? (state.result as SmartUpCompletenessReport)
      : null;
  const connection =
    report === null && state.result && "connected" in state.result
      ? (state.result as SmartUpConnectionCheckResponse)
      : null;
  const groupedBatchErrors = report ? groupMigrationErrors(report.batch_errors) : [];

  return (
    <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-[0.28em] text-slate-500">{title}</p>
          <p className="mt-2 text-sm leading-6 text-slate-700">{state.message}</p>
          {state.job ? (
            <div className="mt-3 space-y-2 text-xs text-slate-500">
              <p>
                Job {state.job.job_id} · {state.job.progress_organizations}/
                {state.job.total_organizations} организаций
              </p>
              <div className="flex flex-wrap gap-2">
                <JobChip label="Режим" value={formatJobMode(state.job.migration_mode)} />
                <JobChip label="Этап" value={formatJobPhase(state.job.current_phase)} />
                <JobChip
                  label="Организация"
                  value={state.job.current_organization_name ?? "—"}
                />
                <JobChip
                  label="Сущность"
                  value={state.job.current_entity_label ?? state.job.current_entity_type ?? "—"}
                />
              </div>
            </div>
          ) : null}
        </div>
        <span
          className={[
            "rounded-full px-3 py-1 text-xs font-semibold",
            state.status === "success"
              ? "bg-emerald-50 text-emerald-700"
              : state.status === "error"
                ? "bg-rose-50 text-rose-700"
                : "bg-violet-50 text-violet-700",
          ].join(" ")}
        >
          {state.status === "success"
            ? "Готово"
            : state.status === "error"
              ? "Ошибка"
              : "В процессе"}
        </span>
      </div>

      {connection ? (
        <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          <DetailRow label="Код" value={connection.code ?? "—"} />
          <DetailRow label="HTTP статус" value={connection.upstream_status?.toString() ?? "—"} />
          <DetailRow label="Организация" value={connection.organization_name ?? "—"} />
          <DetailRow label="Код филиала" value={connection.filial_id ?? "—"} />
          <DetailRow label="URL запроса" value={connection.requested_url} />
          <DetailRow label="Ответ источника" value={connection.upstream_response || "—"} />
        </div>
      ) : null}

      {report ? (
        <div className="mt-4 space-y-4">
          <div className="rounded-[18px] border border-emerald-200 bg-emerald-50/50 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-emerald-600">Отчёт миграции</p>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-emerald-950">
              <span className="rounded-full bg-white px-3 py-1 font-semibold shadow-sm">
                База данных
              </span>
              <span>{report.organizations_count} организаций</span>
              {report.history_start && report.history_end ? (
                <span>
                  с {formatDate(report.history_start)} по {formatDate(report.history_end)}
                </span>
              ) : null}
            </div>
          </div>

          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            <Metric label="Организаций" value={report.organizations_count} />
            <Metric label="Бизнесов" value={report.summary.businesses} />
            <Metric label="Источников" value={report.summary.source_systems} />
            <Metric label="Контактов" value={report.summary.contacts} />
            <Metric label="Сделок" value={report.summary.sales} />
            <Metric label="Маркетинг" value={report.summary.marketing_activities} />
            <Metric label="Финансовых записей" value={report.summary.finance_entries} />
            <Metric label="Записей ядра" value={report.summary.records} />
            <Metric label="Батчей" value={report.summary.batches} />
            <Metric label="Ошибок" value={report.summary.errors} />
            <Metric label="Запусков" value={report.runs.length} />
            <Metric label="Ошибок батчей" value={report.batch_errors.length} />
          </div>

          {report.batch_errors.length ? (
            <div className="rounded-[18px] border border-rose-200 bg-rose-50/60 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-[0.24em] text-rose-600">
                    Что не загрузилось
                  </p>
                  <p className="mt-1 text-sm text-rose-900">Ошибки по пакетам и причинам сбоя.</p>
                  <div className="mt-3 flex flex-wrap gap-2 text-xs text-rose-900">
                    <span className="rounded-full bg-white px-3 py-1 font-semibold shadow-sm">
                      {report.batch_errors.length} ошибок
                    </span>
                    <span className="rounded-full bg-white px-3 py-1 font-semibold shadow-sm">
                      {groupedBatchErrors.length} организаций
                    </span>
                    <span className="rounded-full bg-white px-3 py-1 font-semibold shadow-sm">
                      {new Set(report.batch_errors.map((error) => error.entity_type ?? "—")).size} сущностей
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleMigrationErrors?.()}
                  className="rounded-full border border-rose-200 bg-white px-4 py-2 text-sm font-semibold text-rose-700 transition-colors hover:bg-rose-50"
                >
                  {showMigrationErrors ? "Скрыть ошибки" : "Показать ошибки"}
                </button>
              </div>

              {showMigrationErrors ? (
                <div className="mt-4 space-y-3">
                  {groupedBatchErrors.map((group) => (
                    <div
                      key={group.organization_name}
                      className="rounded-[16px] border border-rose-200 bg-white p-4 shadow-sm"
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="text-sm font-semibold text-slate-950">
                            {group.organization_name}
                          </p>
                          <p className="mt-1 text-xs text-slate-500">
                            {group.errors.length} ошибок · {group.entity_types.length} сущностей
                          </p>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {group.entity_types.slice(0, 3).map((entityType) => (
                            <span
                              key={entityType}
                              className="rounded-full border border-rose-200 bg-rose-50 px-3 py-1 text-xs font-semibold text-rose-700"
                            >
                              {entityType}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="mt-4 space-y-3">
                        {group.errors.map((error, index) => (
                          <div
                            key={`${error.batch_id}-${error.error_code}-${index}`}
                            className="rounded-[14px] border border-rose-100 bg-rose-50/40 p-3"
                          >
                            <div className="flex flex-wrap items-start justify-between gap-3">
                              <div>
                                <p className="text-sm font-semibold text-slate-950">
                                  {error.batch_name}
                                </p>
                                <p className="mt-1 text-xs text-slate-500">
                                  {error.batch_status} · {error.entity_type ?? "—"}
                                </p>
                              </div>
                              <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-rose-700 shadow-sm">
                                {error.error_code}
                              </span>
                            </div>

                            <div className="mt-3 grid gap-2 sm:grid-cols-2">
                              <DetailRow label="Причина" value={error.error_message} />
                              <DetailRow label="Источник" value={error.source_endpoint ?? "—"} />
                              <DetailRow label="URL запроса" value={error.requested_url ?? "—"} />
                              <DetailRow label="Сущность" value={error.entity_type ?? "—"} />
                              <DetailRow label="ID батча" value={error.batch_id} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}

          <div className="space-y-3">
            <p className="text-xs uppercase tracking-[0.24em] text-slate-400">По организациям</p>
            <div className="grid gap-3">
              {report.organizations.map((organization) => (
                <div key={organization.organization_id} className="rounded-[18px] border border-slate-200 bg-slate-50 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-slate-950">{organization.name}</p>
                      <p className="mt-1 text-xs text-slate-500">Код филиала: {organization.filial_id}</p>
                    </div>
                  </div>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
                    <MiniStat label="Бизнес" value={organization.summary.businesses} />
                    <MiniStat label="Источник" value={organization.summary.source_systems} />
                    <MiniStat label="Контакты" value={organization.summary.contacts} />
                    <MiniStat label="Сделки" value={organization.summary.sales} />
                    <MiniStat label="Маркетинг" value={organization.summary.marketing_activities} />
                    <MiniStat label="Финансы" value={organization.summary.finance_entries} />
                    <MiniStat label="Батчи" value={organization.summary.batches} />
                    <MiniStat label="Ошибки" value={organization.summary.errors} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : completeness ? (
        <div className="mt-4 space-y-4">
          <div className="rounded-[18px] border border-violet-200 bg-violet-50/50 p-4">
            <p className="text-xs uppercase tracking-[0.24em] text-violet-600">
              Отчёт полноты
            </p>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-violet-950">
              <span className="rounded-full bg-white px-3 py-1 font-semibold shadow-sm">
                {completeness.total_organizations} организаций
              </span>
              <span>{completeness.total_entities} сущностей</span>
              <span>{completeness.completed_entities} завершено</span>
              <span>{completeness.partial_entities} частично</span>
              <span>{completeness.failed_entities} с ошибкой</span>
            </div>
          </div>

          <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            <Metric label="Сырых записей" value={completeness.raw_records} />
            <Metric label="Записей ядра" value={completeness.core_records} />
            <Metric label="Завершено" value={completeness.completed_entities} />
            <Metric label="Частично" value={completeness.partial_entities} />
            <Metric label="С ошибкой" value={completeness.failed_entities} />
            <Metric label="Позиции" value={completeness.items.length} />
          </div>

          <div className="space-y-3">
            <p className="text-xs uppercase tracking-[0.24em] text-slate-400">
              Что требует доимпорта
            </p>
            <div className="space-y-3">
              {completeness.items
                .filter((item) => item.status !== "complete")
                .map((item) => (
                  <div
                    key={`${item.organization_id}-${item.entity_type}`}
                    className="rounded-[16px] border border-slate-200 bg-white p-4 shadow-sm"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-semibold text-slate-950">
                          {item.organization_name}
                        </p>
                        <p className="mt-1 text-xs text-slate-500">{item.entity_type}</p>
                      </div>
                      <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700">
                        {item.status}
                      </span>
                    </div>
                    <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-4">
                      <DetailRow label="Батчи" value={item.batch_count.toString()} />
                      <DetailRow label="Ошибки" value={item.failed_batches.toString()} />
                      <DetailRow label="Сырые данные" value={item.raw_records.toString()} />
                      <DetailRow label="Ядро" value={item.core_records.toString()} />
                    </div>
                    {item.missing_intervals.length ? (
                      <div className="mt-3 space-y-2">
                        <p className="text-xs uppercase tracking-[0.24em] text-rose-500">
                          Разрывы
                        </p>
                        <div className="space-y-2">
                          {item.missing_intervals.map((gap, gapIndex) => (
                            <div
                              key={`${item.organization_id}-${item.entity_type}-${gapIndex}`}
                              className="rounded-[14px] border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-900"
                            >
                              {formatDate(gap.period_start)} → {formatDate(gap.period_end)}
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null}
                  </div>
                ))}
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}

function sleep(ms: number) {
  return new Promise<void>((resolve) => {
    window.setTimeout(resolve, ms);
  });
}

async function pollMigrationJob(
  jobId: string,
  onUpdate: (job: SmartUpMigrationJobResponse) => void,
) {
  let currentJob = await getSmartUpMigrationJob(jobId);
  onUpdate(currentJob);

  while (currentJob.status === "pending" || currentJob.status === "running") {
    await sleep(2000);
    currentJob = await getSmartUpMigrationJob(jobId);
    onUpdate(currentJob);
  }

  return currentJob;
}

function persistMigrationJob(job: SmartUpMigrationJobResponse) {
  if (typeof window === "undefined") {
    return;
  }
  if (job.status === "pending" || job.status === "running") {
    window.localStorage.setItem(SMARTUP_MIGRATION_JOB_STORAGE_KEY, job.job_id);
    return;
  }
  window.localStorage.removeItem(SMARTUP_MIGRATION_JOB_STORAGE_KEY);
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-[16px] border border-slate-200 bg-slate-50 px-3 py-2">
      <p className="text-[10px] uppercase tracking-[0.24em] text-slate-400">{label}</p>
      <p className="mt-1 text-lg font-semibold tracking-[-0.04em] text-slate-950">{value}</p>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-[16px] border border-white bg-white px-3 py-2 shadow-sm">
      <p className="text-[10px] uppercase tracking-[0.24em] text-slate-400">{label}</p>
      <p className="mt-1 text-sm font-semibold text-slate-950">{value}</p>
    </div>
  );
}

function JobChip({ label, value }: { label: string; value: string }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[11px] text-slate-600">
      <span className="uppercase tracking-[0.24em] text-slate-400">{label}</span>
      <span className="font-medium text-slate-900">{value}</span>
    </span>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-[16px] border border-slate-200 bg-slate-50 px-3 py-2">
      <p className="text-[10px] uppercase tracking-[0.24em] text-slate-400">{label}</p>
      <p className="mt-1 break-all text-sm text-slate-900">{value}</p>
    </div>
  );
}

function groupMigrationErrors(errors: SmartUpMigrationAllResponse["batch_errors"]) {
  const groups = new Map<
    string,
    {
      organization_name: string;
      errors: SmartUpMigrationAllResponse["batch_errors"];
      entity_types: string[];
    }
  >();

  for (const error of errors) {
    const key = error.organization_name;
    const current =
      groups.get(key) ?? {
        organization_name: key,
        errors: [],
        entity_types: [],
      };

    current.errors.push(error);
    if (error.entity_type && !current.entity_types.includes(error.entity_type)) {
      current.entity_types.push(error.entity_type);
    }
    groups.set(key, current);
  }

  return [...groups.values()].sort((left, right) => right.errors.length - left.errors.length);
}

function formatJobPhase(phase: string | null | undefined): string {
  return (
    {
      preparing: "Подготовка",
      organization: "Организация",
      entity: "Источник данных",
      organization_completed: "Организация завершена",
      organization_failed: "Ошибка организации",
      completed: "Готово",
    }[phase ?? ""] ?? phase ?? "—"
  );
}

function formatJobMode(mode: SmartUpMigrationMode): string {
  return (
    {
      full_backfill: "Полная загрузка",
      weekly_reconciliation: "Недельная сверка",
      live_sync: "Онлайн-обновление",
      one_day_check: "1 день",
    }[mode] ?? mode
  );
}

function estimateMigrationDuration(
  mode: SmartUpMigrationMode,
  organizationsCount: number,
): string {
  const count = Math.max(organizationsCount, 1);
  const ranges: Record<SmartUpMigrationMode, [number, number]> = {
    one_day_check: [1, 5],
    weekly_reconciliation: [Math.max(2, count * 2), Math.max(5, count * 6)],
    live_sync: [Math.max(1, count), Math.max(3, count * 2)],
    full_backfill: [Math.max(10, count * 20), Math.max(20, count * 45)],
  };
  const [minMinutes, maxMinutes] = ranges[mode];
  return `${minMinutes}-${maxMinutes} мин`;
}

function formatDate(value: string): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date(value));
}
