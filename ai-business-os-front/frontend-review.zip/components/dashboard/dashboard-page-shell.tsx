"use client";

import { BusinessContextBar } from "@/components/business/business-context-bar";
import { DashboardGrid } from "@/components/dashboard/dashboard-grid";
import { DashboardManifestProvider } from "@/components/dashboard/dashboard-manifest-provider";

export function DashboardPageShell() {
  return (
    <DashboardManifestProvider>
      <section className="space-y-4">
        <BusinessContextBar />
        <DashboardGrid />
      </section>
    </DashboardManifestProvider>
  );
}
