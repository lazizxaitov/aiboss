"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Responsive,
  type Layout,
  type LayoutItem,
  type ResponsiveLayouts,
} from "react-grid-layout/legacy";

import { Badge } from "@/components/ui/badge";
import { Surface } from "@/components/ui/surface";
import { useDashboardManifest } from "@/components/dashboard/dashboard-manifest-provider";
import { cn } from "@/lib/cn";
import {
  type AnalyticsDataStatus,
  type AnalyticsMetricValue,
  type DashboardDrilldown,
  type DashboardManifestWidget,
  type DashboardSemanticSize,
} from "@/lib/core-api";

const GRID_STORAGE_KEY = "ai-business-os:dashboard-manifest-layout:v1";
const GRID_COLS = { lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 };

type WidgetLayoutConstraint = {
  w: number;
  h: number;
  minW: number;
  minH: number;
  maxW: number;
  maxH: number;
};

type SerializedMetricValue = AnalyticsMetricValue;

type ExecutiveNumber = {
  label?: string;
  current?: string | number | null;
  previous?: string | number | null;
  delta?: string | number | null;
  direction?: string | null;
};

type SerializedProductRow = {
  product_id?: string | null;
  product_external_id?: string | null;
  product_name?: string | null;
  organization_id?: string | null;
  organization_name?: string | null;
  sold_units?: SerializedMetricValue;
  revenue?: SerializedMetricValue;
  orders_count?: SerializedMetricValue;
  customers_count?: SerializedMetricValue;
  average_selling_price?: SerializedMetricValue;
  returns_quantity?: SerializedMetricValue;
  returns_amount?: SerializedMetricValue;
  return_rate?: SerializedMetricValue;
  current_stock?: SerializedMetricValue;
  stock_value?: SerializedMetricValue;
  sales_velocity_7d?: SerializedMetricValue;
  sales_velocity_30d?: SerializedMetricValue;
  days_of_stock?: SerializedMetricValue;
  sales_change_pct?: SerializedMetricValue;
  units_change_pct?: SerializedMetricValue;
  revenue_change_pct?: SerializedMetricValue;
  classification?: string | null;
  classification_tags?: string[];
  stockout_risk?: string | null;
  first_sale_date?: string | null;
  last_sale_date?: string | null;
  data_status?: AnalyticsDataStatus;
};

type SerializedCustomerRow = {
  customer_external_id?: string | null;
  customer_name?: string | null;
  organization_ids?: string[];
  orders_count?: SerializedMetricValue;
  revenue?: SerializedMetricValue;
  sold_units?: SerializedMetricValue;
  average_order_value?: SerializedMetricValue;
  days_since_last_order?: SerializedMetricValue;
  purchase_frequency?: SerializedMetricValue;
  returns_count?: SerializedMetricValue;
  returns_amount?: SerializedMetricValue;
  visits_count?: SerializedMetricValue;
  products_count?: SerializedMetricValue;
  organizations_count?: SerializedMetricValue;
  customer_value_score?: SerializedMetricValue;
  segment?: string | null;
  first_order_date?: string | null;
  last_order_date?: string | null;
  data_status?: AnalyticsDataStatus;
};

type SerializedOrganizationRow = {
  organization_id: string;
  organization_name: string;
  metrics: Record<string, SerializedMetricValue>;
  products_sold?: SerializedMetricValue;
  sales_reps?: SerializedMetricValue;
  visits?: SerializedMetricValue;
  stock?: SerializedMetricValue;
  data_status?: AnalyticsDataStatus;
};

type SerializedInventoryOpportunity = {
  product_external_id?: string | null;
  product_name?: string | null;
  from_organization_id?: string;
  from_organization_name?: string;
  to_organization_id?: string;
  to_organization_name?: string;
  source_stock?: SerializedMetricValue;
  destination_stock?: SerializedMetricValue;
  source_days?: SerializedMetricValue;
  destination_days?: SerializedMetricValue;
  source_velocity?: SerializedMetricValue;
  destination_velocity?: SerializedMetricValue;
  reason?: string | null;
};

type SerializedSalesRepRow = {
  sales_rep_external_id?: string | null;
  sales_rep_name?: string | null;
  organization_id?: string | null;
  organization_name?: string | null;
  visits_count?: SerializedMetricValue;
  orders_count?: SerializedMetricValue;
  revenue?: SerializedMetricValue;
  sold_units?: SerializedMetricValue;
  average_order_value?: SerializedMetricValue;
  conversion_rate?: SerializedMetricValue;
  last_visit_date?: string | null;
  data_status?: AnalyticsDataStatus;
};

type SerializedAIInsight = {
  id?: string;
  type?: string;
  severity?: string;
  title?: string;
  summary?: string;
  recommendation?: string | null;
  confidence?: number | null;
  metric_key?: string | null;
  entity_type?: string | null;
  entity_id?: string | null;
  organization_ids?: string[];
  metrics?: ExecutiveNumber[];
  evidence?: string[];
  tags?: string[];
};

function statusLabel(status: AnalyticsDataStatus) {
  switch (status) {
    case "AVAILABLE":
      return "Данные подтверждены";
    case "PARTIAL":
      return "Частичное покрытие";
    case "NO_DATA":
      return "Нет данных";
    case "NO_VERIFIED_DATA":
      return "Нет подтверждённых данных";
    case "UNRESOLVED":
      return "Источник не разрешён";
    case "PERMISSION_RESTRICTED":
      return "Нет доступа";
    case "INSUFFICIENT_HISTORY":
      return "Недостаточно истории";
    case "ANALYSIS_PENDING":
      return "Анализ обновляется";
    case "NOT_SUPPORTED":
      return "Не поддерживается";
    default:
      return "Недоступно";
  }
}

function statusVariant(status: AnalyticsDataStatus): "accent" | "soft" | "dark" | "neutral" {
  switch (status) {
    case "PARTIAL":
    case "ANALYSIS_PENDING":
      return "accent";
    case "AVAILABLE":
      return "soft";
    case "NO_DATA":
    case "NO_VERIFIED_DATA":
    case "UNRESOLVED":
    case "PERMISSION_RESTRICTED":
    case "NOT_SUPPORTED":
    case "INSUFFICIENT_HISTORY":
      return "neutral";
    default:
      return "neutral";
  }
}

function semanticConstraint(
  semanticSize: DashboardSemanticSize,
  widget: DashboardManifestWidget,
): WidgetLayoutConstraint {
  const base: Record<DashboardSemanticSize, WidgetLayoutConstraint> = {
    XS: { w: 2, h: 2, minW: 2, minH: 2, maxW: 3, maxH: 2 },
    S: { w: 3, h: 2, minW: 2, minH: 2, maxW: 4, maxH: 3 },
    M: { w: 4, h: 3, minW: 3, minH: 3, maxW: 6, maxH: 4 },
    L: { w: 6, h: 4, minW: 4, minH: 4, maxW: 8, maxH: 7 },
    XL: { w: 8, h: 4, minW: 6, minH: 4, maxW: 12, maxH: 8 },
  };

  const constraint = { ...base[semanticSize] };
  if (widget.supports_internal_scroll && widget.content_density === "high") {
    constraint.minH = Math.max(constraint.minH, 4);
    constraint.h = Math.max(constraint.h, 5);
  }
  if (widget.widget_type === "table") {
    constraint.w = 8;
    constraint.h = 5;
    constraint.minW = 6;
    constraint.minH = 5;
    constraint.maxW = 12;
    constraint.maxH = 9;
  }
  if (widget.widget_type === "line_chart" || widget.widget_type === "organization_comparison") {
    constraint.w = 8;
    constraint.minW = 6;
  }
  if (widget.widget_type === "product_ranking" || widget.widget_type === "customer_ranking") {
    constraint.h = 5;
    constraint.minH = 4;
  }
  return constraint;
}

function buildDefaultLayouts(widgets: DashboardManifestWidget[]): ResponsiveLayouts {
  let cursorX = 0;
  let cursorY = 0;
  let rowHeight = 0;

  const lg: LayoutItem[] = widgets.map((widget) => {
    const size = semanticConstraint(widget.semantic_size, widget);
    if (cursorX + size.w > GRID_COLS.lg) {
      cursorX = 0;
      cursorY += rowHeight;
      rowHeight = 0;
    }

    const item: LayoutItem = {
      i: widget.widget_id,
      x: cursorX,
      y: cursorY,
      w: size.w,
      h: size.h,
      minW: size.minW,
      minH: size.minH,
      maxW: size.maxW,
      maxH: size.maxH,
      static: widget.locked_position && widget.locked_size,
      isDraggable: !widget.locked_position,
      isResizable: !widget.locked_size,
    };

    cursorX += size.w;
    rowHeight = Math.max(rowHeight, size.h);
    return item;
  });

  return {
    lg,
    md: lg.map((item) => ({ ...item, x: 0, y: item.y, w: Math.min(item.w, GRID_COLS.md) })),
    sm: lg.map((item) => ({ ...item, x: 0, y: item.y, w: Math.min(item.w, GRID_COLS.sm) })),
    xs: lg.map((item) => ({ ...item, x: 0, y: item.y, w: Math.min(Math.max(item.minW ?? 2, 2), GRID_COLS.xs) })),
    xxs: lg.map((item) => ({ ...item, x: 0, y: item.y, w: Math.min(Math.max(item.minW ?? 2, 2), GRID_COLS.xxs) })),
  };
}

function loadSavedLayouts(widgetIds: string[]) {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(GRID_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ResponsiveLayouts;
    const ids = new Set(widgetIds);
    const next = Object.fromEntries(
      Object.entries(parsed).map(([breakpoint, items]) => [
        breakpoint,
        (items as Layout).filter((item) => ids.has(item.i)),
      ]),
    ) as ResponsiveLayouts;
    return next;
  } catch {
    return null;
  }
}

function saveLayouts(layouts: ResponsiveLayouts) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(GRID_STORAGE_KEY, JSON.stringify(layouts));
}

function buildDrilldownHref(drilldown: DashboardDrilldown | null) {
  if (!drilldown) return null;
  const pathMap: Record<string, string> = {
    analytics: "/ceo",
    sales: "/sales",
    products: "/products",
    customers: "/customers",
    inventory: "/inventory",
    organizations: "/ceo",
    visits: "/visits",
    finance: "/finance",
    "ai-analytics": "/ceo",
    data_quality: "/settings",
  };
  const pathname = pathMap[drilldown.target] ?? "/ceo";
  const params = new URLSearchParams();
  if (drilldown.organization_ids.length > 0) {
    params.set("org", drilldown.organization_ids.join(","));
  }
  if (drilldown.entity_type) params.set("entity_type", drilldown.entity_type);
  if (drilldown.entity_id) params.set("entity_id", drilldown.entity_id);
  for (const [key, value] of Object.entries(drilldown.filters)) {
    params.set(key, value);
  }
  return params.toString() ? `${pathname}?${params.toString()}` : pathname;
}

function useMeasuredWidth<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const updateWidth = () => {
      setWidth(node.getBoundingClientRect().width);
    };

    updateWidth();

    const observer = new ResizeObserver(() => {
      updateWidth();
    });
    observer.observe(node);

    return () => {
      observer.disconnect();
    };
  }, []);

  return [ref, width] as const;
}

function parseNumber(value: string | number | null | undefined) {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const normalized = String(value).replace(/\s+/g, "").replace(",", ".");
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function formatPlainNumber(value: string | number | null | undefined) {
  const parsed = parseNumber(value);
  if (parsed === null) return "—";
  return new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 }).format(parsed);
}

function formatMoney(value: string | number | null | undefined, currencyCode?: string | null) {
  const parsed = parseNumber(value);
  if (parsed === null) return "—";
  const formatted = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 }).format(parsed);
  return currencyCode ? `${formatted} ${currencyCode}` : formatted;
}

function formatPercent(value: string | number | null | undefined) {
  const parsed = parseNumber(value);
  if (parsed === null) return "—";
  return `${new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 1 }).format(parsed)}%`;
}

function metricCurrency(metric?: SerializedMetricValue | null) {
  return metric?.currency || (metric?.unit === "currency" ? "UZS" : null);
}

function formatMetric(metric?: SerializedMetricValue | null) {
  if (!metric) return "—";
  if (metric.value === null || metric.value === undefined || metric.value === "") {
    return metric.data_status === "NO_VERIFIED_DATA" ? "Нет подтверждённых данных" : "—";
  }
  if (metric.unit === "currency") {
    return formatMoney(metric.value, metricCurrency(metric));
  }
  if (metric.unit === "percent") {
    return formatPercent(metric.value);
  }
  if (metric.unit === "days") {
    const value = formatPlainNumber(metric.value);
    return value === "—" ? value : `${value} дн.`;
  }
  return formatPlainNumber(metric.value);
}

function metricDelta(metric?: SerializedMetricValue | null) {
  if (!metric || metric.delta === null || metric.delta === undefined || metric.delta === "") return null;
  const deltaValue = parseNumber(metric.delta);
  const percent = parseNumber(metric.percent_delta);
  const direction = deltaValue !== null && deltaValue > 0 ? "+" : "";
  if (metric.unit === "currency") {
    return `${direction}${formatMoney(metric.delta, metricCurrency(metric))}${percent !== null ? ` · ${direction}${formatPercent(percent)}` : ""}`;
  }
  if (percent !== null) {
    return `${direction}${formatPercent(percent)}`;
  }
  return `${direction}${formatPlainNumber(metric.delta)}`;
}

function widgetPayload<T>(widget: DashboardManifestWidget) {
  return (widget.payload ?? {}) as T;
}

function metricTone(metric?: SerializedMetricValue | null) {
  const status = metric?.data_status;
  if (status === "AVAILABLE") return "text-slate-950";
  if (status === "PARTIAL" || status === "ANALYSIS_PENDING") return "text-violet-700";
  return "text-slate-500";
}

function widgetHeader(widget: DashboardManifestWidget) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div className="min-w-0">
        <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">{widget.widget_type.replaceAll("_", " ")}</p>
        <h3 className="mt-2 text-[22px] font-semibold tracking-[-0.04em] text-slate-950">{widget.title}</h3>
        {widget.subtitle ? <p className="mt-1 text-sm leading-6 text-slate-500">{widget.subtitle}</p> : null}
      </div>
      <div className="flex shrink-0 items-center gap-2">
        {widget.pinned ? <Badge variant="dark">Pinned</Badge> : null}
        <Badge variant={statusVariant(widget.data_status)}>{statusLabel(widget.data_status)}</Badge>
      </div>
    </div>
  );
}

function widgetFooter(widget: DashboardManifestWidget) {
  const href = buildDrilldownHref(widget.drilldown);
  return (
    <div className="mt-4 flex items-center justify-between gap-3 border-t border-slate-100 pt-4">
      <div className="drag-handle flex flex-wrap gap-2 text-xs text-slate-400">
        <span>{widget.source_type}</span>
        <span>Priority {widget.priority}</span>
        <span>{widget.semantic_size}</span>
      </div>
      {href ? (
        <Link
          href={href}
          className="inline-flex items-center rounded-full border border-slate-200 bg-white px-3 py-2 text-sm font-medium text-slate-700 transition hover:border-slate-300 hover:text-slate-950"
        >
          Открыть
        </Link>
      ) : null}
    </div>
  );
}

function SmallStat({ label, value, note }: { label: string; value: string; note?: string | null }) {
  return (
    <div className="rounded-[18px] border border-slate-100 bg-slate-50/80 p-3">
      <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">{label}</p>
      <p className="mt-2 text-lg font-semibold tracking-[-0.03em] text-slate-950">{value}</p>
      {note ? <p className="mt-1 text-xs text-slate-500">{note}</p> : null}
    </div>
  );
}

function ListShell({ children, scroll }: { children: React.ReactNode; scroll?: boolean }) {
  return (
    <div className={cn("mt-4 min-h-0 flex-1", scroll ? "overflow-y-auto pr-1" : "")}>{children}</div>
  );
}

function MetricStatusNote({ metric }: { metric?: SerializedMetricValue | null }) {
  if (!metric || metric.data_status === "AVAILABLE") return null;
  return <p className="text-xs leading-5 text-slate-500">{statusLabel(metric.data_status)}</p>;
}

function KpiWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{ metric?: SerializedMetricValue; metric_key?: string }>(widget);
  const metric = payload.metric;
  const delta = metricDelta(metric);
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <div className="mt-6 flex min-h-0 flex-1 flex-col justify-between gap-6">
        <div>
          <p className={cn("text-[40px] font-semibold tracking-[-0.08em]", metricTone(metric))}>{formatMetric(metric)}</p>
          <MetricStatusNote metric={metric} />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <SmallStat label="Покрытие" value={metric?.coverage !== null && metric?.coverage !== undefined ? formatPercent(metric.coverage) : "—"} />
          <SmallStat label="Изменение" value={delta ?? "—"} note={metric?.note ?? null} />
        </div>
      </div>
      {widgetFooter(widget)}
    </Surface>
  );
}

function buildSparkPath(values: number[], width: number, height: number) {
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const range = Math.max(max - min, 1);
  const step = values.length > 1 ? width / (values.length - 1) : width;
  return values
    .map((value, index) => {
      const x = index * step;
      const y = height - ((value - min) / range) * height;
      return `${index === 0 ? "M" : "L"}${x},${y}`;
    })
    .join(" ");
}

function TrendWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{ metric?: SerializedMetricValue; series?: Array<{ organization_name?: string; value?: string | number | null; status?: AnalyticsDataStatus }>; period_label?: string }>(widget);
  const metric = payload.metric;
  const values = (payload.series ?? []).map((item) => parseNumber(item.value) ?? 0);
  const hasSeries = values.some((value) => value > 0);
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <div className="mt-5 flex min-h-0 flex-1 flex-col gap-4">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className={cn("text-[38px] font-semibold tracking-[-0.08em]", metricTone(metric))}>{formatMetric(metric)}</p>
            <p className="mt-1 text-sm text-slate-500">{payload.period_label ?? widget.summary ?? "Выбранный период"}</p>
          </div>
          {metricDelta(metric) ? <Badge variant="accent">{metricDelta(metric)}</Badge> : null}
        </div>
        <div className="rounded-[24px] border border-slate-100 bg-[linear-gradient(180deg,#ffffff_0%,#f8fbff_100%)] p-4">
          {hasSeries ? (
            <>
              <svg viewBox="0 0 520 180" className="h-[180px] w-full">
                <g stroke="#e2e8f0" strokeDasharray="4 6">
                  {[0, 1, 2, 3].map((index) => {
                    const y = 12 + index * 48;
                    return <line key={index} x1="0" x2="520" y1={y} y2={y} />;
                  })}
                </g>
                <path d={buildSparkPath(values, 520, 152)} fill="none" stroke="#4f46e5" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <div className="mt-3 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                {(payload.series ?? []).slice(0, 6).map((row, index) => (
                  <div key={`${row.organization_name ?? "series"}-${index}`} className="rounded-2xl border border-slate-100 bg-white px-3 py-2">
                    <p className="text-xs uppercase tracking-[0.22em] text-slate-400">{row.organization_name ?? `Сегмент ${index + 1}`}</p>
                    <p className="mt-1 text-sm font-semibold text-slate-900">{formatMoney(row.value ?? null, metricCurrency(metric))}</p>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex h-full min-h-[220px] items-center justify-center rounded-[20px] border border-dashed border-slate-200 bg-white/60 px-6 text-center text-sm leading-6 text-slate-500">
              Manifest пока не вернул временной ряд. Виджет остаётся честным и не рисует фиктивный график.
            </div>
          )}
        </div>
      </div>
      {widgetFooter(widget)}
    </Surface>
  );
}

function ExecutiveBriefWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{
    headline?: string;
    business_status?: string;
    key_numbers?: ExecutiveNumber[];
    top_insights?: SerializedAIInsight[];
    risks?: SerializedAIInsight[];
    opportunities?: SerializedAIInsight[];
    data_warnings?: SerializedAIInsight[];
  }>(widget);
  const sections: Array<{ title: string; rows: SerializedAIInsight[] | undefined }> = [
    { title: "Ключевые сигналы", rows: payload.top_insights },
    { title: "Риски", rows: payload.risks },
    { title: "Возможности", rows: payload.opportunities },
    { title: "Ограничения данных", rows: payload.data_warnings },
  ];
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <div className="mt-5 min-h-0 flex-1 overflow-y-auto pr-1">
        <div className="rounded-[22px] border border-violet-100 bg-[radial-gradient(circle_at_top_left,rgba(139,92,246,0.12),transparent_48%),linear-gradient(180deg,#ffffff_0%,#faf8ff_100%)] p-5">
          <p className="text-lg font-semibold tracking-[-0.03em] text-slate-950">{payload.headline ?? widget.summary ?? "Краткая executive-сводка"}</p>
          {payload.business_status ? <p className="mt-2 text-sm text-slate-500">{payload.business_status}</p> : null}
          {payload.key_numbers?.length ? (
            <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {payload.key_numbers.slice(0, 4).map((item, index) => (
                <SmallStat
                  key={`${item.label ?? "num"}-${index}`}
                  label={item.label ?? `Метрика ${index + 1}`}
                  value={typeof item.current === "number" || typeof item.current === "string" ? String(item.current) : "—"}
                  note={item.delta ? `Δ ${item.delta}` : null}
                />
              ))}
            </div>
          ) : null}
        </div>

        {sections.map(({ title, rows }) => (
          rows && rows.length ? (
            <section key={title} className="mt-4">
              <div className="mb-3 flex items-center justify-between gap-3">
                <h4 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-400">{title}</h4>
                <Badge variant="soft">{rows.length}</Badge>
              </div>
              <div className="space-y-3">
                {rows.slice(0, 4).map((item, index) => (
                  <div key={`${item.id ?? title}-${index}`} className="rounded-[20px] border border-slate-100 bg-slate-50/80 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-base font-semibold tracking-[-0.03em] text-slate-950">{item.title ?? "Сигнал"}</p>
                        {item.summary ? <p className="mt-2 text-sm leading-6 text-slate-600">{item.summary}</p> : null}
                      </div>
                      {item.severity ? <Badge variant="accent">{item.severity}</Badge> : null}
                    </div>
                    {item.recommendation ? <p className="mt-3 text-sm font-medium text-violet-700">{item.recommendation}</p> : null}
                    {item.evidence?.length ? (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {item.evidence.slice(0, 3).map((evidence, evidenceIndex) => (
                          <Badge key={`${item.id ?? index}-evidence-${evidenceIndex}`} variant="soft">{evidence}</Badge>
                        ))}
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </section>
          ) : null
        ))}
      </div>
      {widgetFooter(widget)}
    </Surface>
  );
}

function RankingWidget({ widget, rows, customerMode = false }: { widget: DashboardManifestWidget; rows: SerializedProductRow[] | SerializedCustomerRow[]; customerMode?: boolean }) {
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <ListShell scroll>
        <div className="space-y-3">
          {rows.length ? rows.map((row, index) => {
            const productRow = row as SerializedProductRow;
            const customerRow = row as SerializedCustomerRow;
            const name = customerMode ? customerRow.customer_name : productRow.product_name;
            const sublabel = customerMode
              ? `${formatMetric(customerRow.orders_count)} заказов · ${formatMetric(customerRow.sold_units)} ед.`
              : `${productRow.organization_name ?? "Организация"} · ${formatMetric(productRow.sold_units)} ед.`;
            const valueMetric = customerMode ? customerRow.revenue : productRow.revenue;
            const noteMetric = customerMode ? customerRow.days_since_last_order : productRow.current_stock;
            return (
              <div key={`${name ?? "row"}-${index}`} className="rounded-[20px] border border-slate-100 bg-slate-50/80 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-3">
                      <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-900 text-sm font-semibold text-white">{index + 1}</span>
                      <div className="min-w-0">
                        <p className="truncate text-base font-semibold tracking-[-0.03em] text-slate-950">{name ?? "Без названия"}</p>
                        <p className="mt-1 text-sm text-slate-500">{sublabel}</p>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-semibold tracking-[-0.03em] text-slate-950">{formatMetric(valueMetric)}</p>
                    {noteMetric ? <p className="mt-1 text-xs text-slate-500">{customerMode ? `С последнего заказа: ${formatMetric(noteMetric)}` : `Остаток: ${formatMetric(noteMetric)}`}</p> : null}
                  </div>
                </div>
              </div>
            );
          }) : (
            <div className="rounded-[20px] border border-dashed border-slate-200 bg-slate-50/60 px-5 py-10 text-center text-sm text-slate-500">
              Нет строк для текущего контекста.
            </div>
          )}
        </div>
      </ListShell>
      {widgetFooter(widget)}
    </Surface>
  );
}

function OrganizationComparisonWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{ rows?: SerializedOrganizationRow[] }>(widget);
  const rows = payload.rows ?? [];
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <div className="mt-4 min-h-0 flex-1 overflow-auto rounded-[22px] border border-slate-100 bg-white">
        <table className="min-w-full text-left text-sm">
          <thead className="sticky top-0 bg-slate-50 text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">Организация</th>
              <th className="px-4 py-3 font-medium">Выручка</th>
              <th className="px-4 py-3 font-medium">Заказы</th>
              <th className="px-4 py-3 font-medium">Продано</th>
              <th className="px-4 py-3 font-medium">Поступления</th>
              <th className="px-4 py-3 font-medium">Клиенты</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.organization_id} className="border-t border-slate-100 align-top">
                <td className="px-4 py-4 font-semibold text-slate-950">{row.organization_name}</td>
                <td className="px-4 py-4 text-slate-700">{formatMetric(row.metrics.revenue)}</td>
                <td className="px-4 py-4 text-slate-700">{formatMetric(row.metrics.orders)}</td>
                <td className="px-4 py-4 text-slate-700">{formatMetric(row.metrics.sold_units)}</td>
                <td className="px-4 py-4 text-slate-700">{formatMetric(row.metrics.payments_received)}</td>
                <td className="px-4 py-4 text-slate-700">{formatMetric(row.metrics.customers)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {widgetFooter(widget)}
    </Surface>
  );
}

function InventoryRiskWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{
    low_stock?: SerializedProductRow[];
    overstock?: SerializedProductRow[];
    stockout_risk?: SerializedProductRow[];
    transfer_opportunities?: SerializedInventoryOpportunity[];
  }>(widget);

  const sections = [
    ["Низкий остаток", payload.low_stock ?? []],
    ["Избыток", payload.overstock ?? []],
    ["Риск stockout", payload.stockout_risk ?? []],
  ] as const;

  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <ListShell scroll>
        <div className="space-y-4">
          {sections.map(([title, rows]) =>
            rows.length ? (
              <section key={title}>
                <div className="mb-2 flex items-center justify-between gap-3">
                  <h4 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-400">{title}</h4>
                  <Badge variant="soft">{rows.length}</Badge>
                </div>
                <div className="space-y-3">
                  {rows.slice(0, 5).map((row, index) => (
                    <div key={`${title}-${row.product_external_id ?? row.product_name ?? index}`} className="rounded-[18px] border border-slate-100 bg-slate-50/80 p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="truncate text-base font-semibold tracking-[-0.03em] text-slate-950">{row.product_name ?? "Товар без имени"}</p>
                          <p className="mt-1 text-sm text-slate-500">{row.organization_name ?? "Организация"}</p>
                        </div>
                        <Badge variant="accent">{row.stockout_risk ?? title}</Badge>
                      </div>
                      <div className="mt-3 grid gap-3 sm:grid-cols-3">
                        <SmallStat label="Остаток" value={formatMetric(row.current_stock)} />
                        <SmallStat label="Дней запаса" value={formatMetric(row.days_of_stock)} />
                        <SmallStat label="Скорость 30д" value={formatMetric(row.sales_velocity_30d)} />
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            ) : null,
          )}

          {payload.transfer_opportunities?.length ? (
            <section>
              <div className="mb-2 flex items-center justify-between gap-3">
                <h4 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-400">Переброска запасов</h4>
                <Badge variant="soft">{payload.transfer_opportunities.length}</Badge>
              </div>
              <div className="space-y-3">
                {payload.transfer_opportunities.slice(0, 5).map((item, index) => (
                  <div key={`${item.product_external_id ?? item.product_name ?? index}-transfer`} className="rounded-[18px] border border-slate-100 bg-slate-50/80 p-4">
                    <p className="text-base font-semibold tracking-[-0.03em] text-slate-950">{item.product_name ?? "Товар"}</p>
                    <p className="mt-1 text-sm text-slate-500">{item.from_organization_name} → {item.to_organization_name}</p>
                    <div className="mt-3 grid gap-3 sm:grid-cols-2">
                      <SmallStat label="Источник" value={formatMetric(item.source_stock)} note={formatMetric(item.source_days)} />
                      <SmallStat label="Назначение" value={formatMetric(item.destination_stock)} note={formatMetric(item.destination_days)} />
                    </div>
                    {item.reason ? <p className="mt-3 text-sm text-violet-700">{item.reason}</p> : null}
                  </div>
                ))}
              </div>
            </section>
          ) : null}
        </div>
      </ListShell>
      {widgetFooter(widget)}
    </Surface>
  );
}

function VisitSummaryWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{ metric?: SerializedMetricValue; sales_reps?: SerializedSalesRepRow[] }>(widget);
  const reps = payload.sales_reps ?? [];
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <SmallStat label="Визиты" value={formatMetric(payload.metric)} note={payload.metric?.note ?? null} />
        <SmallStat label="Покрытие" value={payload.metric?.coverage !== null && payload.metric?.coverage !== undefined ? formatPercent(payload.metric.coverage) : "—"} />
        <SmallStat label="Статус" value={statusLabel(payload.metric?.data_status ?? widget.data_status)} />
      </div>
      <ListShell scroll>
        <div className="space-y-3">
          {reps.length ? reps.map((rep, index) => (
            <div key={`${rep.sales_rep_external_id ?? rep.sales_rep_name ?? index}`} className="rounded-[18px] border border-slate-100 bg-slate-50/80 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-base font-semibold tracking-[-0.03em] text-slate-950">{rep.sales_rep_name ?? "Без имени"}</p>
                  <p className="mt-1 text-sm text-slate-500">{rep.organization_name ?? "Организация"}</p>
                </div>
                <Badge variant="soft">{formatMetric(rep.conversion_rate)}</Badge>
              </div>
              <div className="mt-3 grid gap-3 sm:grid-cols-4">
                <SmallStat label="Визиты" value={formatMetric(rep.visits_count)} />
                <SmallStat label="Заказы" value={formatMetric(rep.orders_count)} />
                <SmallStat label="Выручка" value={formatMetric(rep.revenue)} />
                <SmallStat label="Продано" value={formatMetric(rep.sold_units)} />
              </div>
            </div>
          )) : (
            <div className="rounded-[18px] border border-dashed border-slate-200 bg-slate-50/60 px-5 py-10 text-center text-sm text-slate-500">Нет данных по полевой команде.</div>
          )}
        </div>
      </ListShell>
      {widgetFooter(widget)}
    </Surface>
  );
}

function DataQualityWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{ items?: Array<{ metric_key?: string; data_status?: AnalyticsDataStatus; coverage?: number | null; confidence?: number | null; message?: string | null; missing_fields?: string[] }>; notes?: string[] }>(widget);
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <ListShell scroll>
        <div className="space-y-3">
          {(payload.items ?? []).map((item, index) => (
            <div key={`${item.metric_key ?? "quality"}-${index}`} className="rounded-[18px] border border-slate-100 bg-slate-50/80 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">{item.metric_key ?? "metric"}</p>
                  <p className="mt-2 text-sm leading-6 text-slate-700">{item.message ?? "Ограничение данных без пояснения."}</p>
                </div>
                <Badge variant={statusVariant(item.data_status ?? "NO_DATA")}>{statusLabel(item.data_status ?? "NO_DATA")}</Badge>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {item.coverage !== null && item.coverage !== undefined ? <Badge variant="soft">Coverage {formatPercent(item.coverage)}</Badge> : null}
                {item.confidence !== null && item.confidence !== undefined ? <Badge variant="soft">Confidence {formatPercent(item.confidence)}</Badge> : null}
                {(item.missing_fields ?? []).slice(0, 4).map((field) => (
                  <Badge key={field} variant="neutral">{field}</Badge>
                ))}
              </div>
            </div>
          ))}
          {(payload.notes ?? []).length ? (
            <div className="rounded-[18px] border border-slate-100 bg-white p-4">
              <h4 className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-400">Примечания</h4>
              <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-600">
                {(payload.notes ?? []).map((note, index) => (
                  <li key={`${note}-${index}`}>• {note}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      </ListShell>
      {widgetFooter(widget)}
    </Surface>
  );
}

function AlertWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<SerializedAIInsight>(widget);
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <div className="mt-5 flex min-h-0 flex-1 flex-col gap-4 rounded-[22px] border border-violet-100 bg-[linear-gradient(180deg,#ffffff_0%,#faf8ff_100%)] p-5">
        <div>
          <p className="text-lg font-semibold tracking-[-0.03em] text-slate-950">{payload.title ?? widget.title}</p>
          <p className="mt-2 text-sm leading-6 text-slate-600">{payload.summary ?? widget.summary ?? "AI-сигнал без резюме."}</p>
        </div>
        {payload.recommendation ? <p className="text-sm font-medium text-violet-700">{payload.recommendation}</p> : null}
        {payload.metrics?.length ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {payload.metrics.slice(0, 4).map((metric, index) => (
              <SmallStat key={`${metric.label ?? "metric"}-${index}`} label={metric.label ?? `Метрика ${index + 1}`} value={typeof metric.current === "number" || typeof metric.current === "string" ? String(metric.current) : "—"} note={metric.delta ? `Δ ${metric.delta}` : null} />
            ))}
          </div>
        ) : null}
        {payload.evidence?.length ? (
          <div className="flex flex-wrap gap-2">
            {payload.evidence.slice(0, 4).map((evidence, index) => (
              <Badge key={`${evidence}-${index}`} variant="soft">{evidence}</Badge>
            ))}
          </div>
        ) : null}
      </div>
      {widgetFooter(widget)}
    </Surface>
  );
}

function WatchlistWidget({ widget }: { widget: DashboardManifestWidget }) {
  const payload = widgetPayload<{ rows?: SerializedAIInsight[] }>(widget);
  const rows = payload.rows ?? [];
  return (
    <Surface className="flex h-full min-h-0 flex-col overflow-hidden p-5">
      {widgetHeader(widget)}
      <ListShell scroll>
        <div className="space-y-3">
          {rows.length ? rows.map((row, index) => (
            <div key={`${row.id ?? row.title ?? index}`} className="rounded-[18px] border border-slate-100 bg-slate-50/80 p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-base font-semibold tracking-[-0.03em] text-slate-950">{row.title ?? "Сигнал"}</p>
                  <p className="mt-1 text-sm text-slate-500">{row.summary ?? "Без описания"}</p>
                </div>
                {row.severity ? <Badge variant="accent">{row.severity}</Badge> : null}
              </div>
            </div>
          )) : (
            <div className="rounded-[18px] border border-dashed border-slate-200 bg-slate-50/60 px-5 py-10 text-center text-sm text-slate-500">Watchlist пуст.</div>
          )}
        </div>
      </ListShell>
      {widgetFooter(widget)}
    </Surface>
  );
}

function UnknownWidgetCard({ widget }: { widget: DashboardManifestWidget }) {
  return (
    <Surface className="flex h-full flex-col justify-between p-5">
      <div>
        <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">Unknown widget</p>
        <h3 className="mt-2 text-[20px] font-semibold tracking-[-0.04em] text-slate-950">{widget.title}</h3>
        <p className="mt-3 text-sm leading-6 text-slate-500">
          Фронтенд пока не знает, как отрисовать тип <code>{widget.widget_type}</code>. Manifest не сломан, рендерер просто отсутствует.
        </p>
      </div>
      <div className="mt-4">
        <Badge variant="neutral">safe fallback</Badge>
      </div>
    </Surface>
  );
}

function renderWidget(widget: DashboardManifestWidget) {
  switch (widget.widget_type) {
    case "kpi":
      return <KpiWidget widget={widget} />;
    case "line_chart":
    case "trend":
    case "bar_chart":
      return <TrendWidget widget={widget} />;
    case "organization_comparison":
      return <OrganizationComparisonWidget widget={widget} />;
    case "product_ranking":
      return <RankingWidget widget={widget} rows={widgetPayload<{ rows?: SerializedProductRow[] }>(widget).rows ?? []} />;
    case "customer_ranking":
      return <RankingWidget widget={widget} rows={widgetPayload<{ rows?: SerializedCustomerRow[] }>(widget).rows ?? []} customerMode />;
    case "inventory_risk":
      return <InventoryRiskWidget widget={widget} />;
    case "visit_summary":
      return <VisitSummaryWidget widget={widget} />;
    case "data_quality":
      return <DataQualityWidget widget={widget} />;
    case "ai_insight":
    case "ai_recommendation":
      return widget.widget_id === "executive-brief" ? <ExecutiveBriefWidget widget={widget} /> : <AlertWidget widget={widget} />;
    case "watchlist":
      return <WatchlistWidget widget={widget} />;
    case "alert":
    case "product_alert":
    case "customer_alert":
    case "inventory_alert":
    case "photo_alert":
      return <AlertWidget widget={widget} />;
    default:
      return <UnknownWidgetCard widget={widget} />;
  }
}

export function DashboardGrid() {
  const { manifest, loading, error } = useDashboardManifest();
  const [layouts, setLayouts] = useState<ResponsiveLayouts | null>(null);
  const [containerRef, containerWidth] = useMeasuredWidth<HTMLDivElement>();

  const widgets = useMemo(
    () => manifest?.widgets.filter((widget) => !widget.hidden) ?? [],
    [manifest],
  );

  const resolvedLayouts = useMemo(() => {
    if (widgets.length === 0) return { lg: [] } satisfies ResponsiveLayouts;
    const saved = loadSavedLayouts(widgets.map((widget) => widget.widget_id));
    return saved ?? buildDefaultLayouts(widgets);
  }, [widgets]);

  if (loading) {
    return (
      <Surface className="p-6">
        <p className="text-sm text-slate-500">Загружаю semantic manifest дашборда…</p>
      </Surface>
    );
  }

  if (error) {
    return (
      <Surface className="p-6">
        <p className="text-sm font-medium text-slate-950">Manifest не загрузился</p>
        <p className="mt-2 text-sm leading-6 text-slate-500">{error}</p>
      </Surface>
    );
  }

  if (!manifest || widgets.length === 0) {
    return (
      <Surface className="p-6">
        <p className="text-sm font-medium text-slate-950">Нет виджетов для текущего контекста</p>
        <p className="mt-2 text-sm leading-6 text-slate-500">
          Backend manifest не вернул виджеты для выбранной организации или периода.
        </p>
      </Surface>
    );
  }

  return (
    <div ref={containerRef} className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="accent">Manifest {manifest.manifest_version}</Badge>
          <Badge variant="soft">Widgets: {widgets.length}</Badge>
          <Badge variant={statusVariant(manifest.data_quality.overall_status)}>
            {statusLabel(manifest.data_quality.overall_status)}
          </Badge>
        </div>
        <p className="text-sm text-slate-400">
          Coordinates сохраняются как пользовательский layout поверх semantic manifest.
        </p>
      </div>

      <Responsive
        className="layout"
        width={containerWidth || 1200}
        layouts={layouts ?? resolvedLayouts}
        breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
        cols={GRID_COLS}
        rowHeight={74}
        margin={[18, 18]}
        containerPadding={[0, 0]}
        draggableHandle=".drag-handle"
        compactType="vertical"
        preventCollision={false}
        isResizable
        isDraggable
        onLayoutChange={(_, allLayouts) => {
          setLayouts(allLayouts);
          saveLayouts(allLayouts);
        }}
      >
        {widgets.map((widget) => (
          <div key={widget.widget_id} className="min-h-0">
            {renderWidget(widget)}
          </div>
        ))}
      </Responsive>
    </div>
  );
}
