import { NotificationsCenter } from "@/modules/alerts/notifications-center";

type AlertsPageProps = {
  searchParams?: {
    item?: string | string[];
  };
};

export default function Page({ searchParams }: AlertsPageProps) {
  const selectedId = Array.isArray(searchParams?.item) ? searchParams?.item[0] : searchParams?.item;

  return <NotificationsCenter selectedId={selectedId} />;
}
