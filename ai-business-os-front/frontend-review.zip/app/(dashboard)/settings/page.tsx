import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/ui/section-heading";
import { Surface } from "@/components/ui/surface";
import { SmartUpAccessForm } from "@/components/settings/smartup-access-form";

const settingsGroups = [
  {
    title: "Интерфейс",
    items: [
      "Тема и контрастность",
      "Плотность интерфейса",
      "Размер шрифта",
    ],
  },
  {
    title: "Навигация",
    items: [
      "Структура меню",
      "Порядок разделов",
      "Быстрые переходы",
    ],
  },
  {
    title: "Доступ",
    items: [
      "Роли пользователей",
      "Права по модулям",
      "Доступ к аналитике",
    ],
  },
  {
    title: "Система",
    items: [
      "Источник данных",
      "Подключения к сервисам",
      "Окна уведомлений",
      "Доступ к источнику данных",
    ],
  },
] as const;

export default function SettingsPage() {
  return (
    <section className="space-y-5">
      <SectionHeading
        eyebrow="Настройки"
        title="Окно настроек платформы"
        description="Здесь собрана конфигурация интерфейса, навигации, доступа и системных параметров. Структура уже отделена от бизнес-логики и готова к развитию."
        actions={
          <>
            <Badge variant="accent">Отдельный экран</Badge>
            <Badge variant="soft">Для конфигурации</Badge>
          </>
        }
      />

      <Surface className="p-5 sm:p-6 lg:p-7">
        <div className="grid gap-4 xl:grid-cols-2">
          <div className="rounded-[24px] border border-slate-200 bg-slate-50 p-5">
            <p className="text-xs uppercase tracking-[0.34em] text-slate-500">
              Источник данных
            </p>
            <h2 className="mt-3 text-xl font-semibold tracking-[-0.04em] text-slate-950">
              Подключение источника данных и ручные организации
            </h2>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Здесь вводятся данные доступа, а организации создаются вручную и связываются с нужным кодом филиала.
            </p>

            <div className="mt-5">
              <SmartUpAccessForm />
            </div>
          </div>

          {settingsGroups.map((group) => (
            <div
              key={group.title}
              className="rounded-[24px] border border-slate-200 bg-slate-50 p-5"
            >
              <p className="text-xs uppercase tracking-[0.34em] text-slate-500">
                {group.title}
              </p>
              <ul className="mt-4 space-y-3">
                {group.items.map((item) => (
                  <li key={item} className="flex gap-3">
                    <span className="mt-2 h-2 w-2 rounded-full bg-violet-500" />
                    <p className="text-sm leading-6 text-slate-700">{item}</p>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </Surface>
    </section>
  );
}
