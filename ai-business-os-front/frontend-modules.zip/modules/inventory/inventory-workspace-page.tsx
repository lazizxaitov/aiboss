"use client";

import Link from "next/link";
import { startTransition, useEffect, useMemo, useState } from "react";

import {
  useBusinessContext,
  useSelectedOrganizationNames,
} from "@/components/business/business-context-provider";
import { Badge } from "@/components/ui/badge";
import { Drawer } from "@/components/ui/drawer";
import { Surface } from "@/components/ui/surface";
import { cn } from "@/lib/cn";
import {
  getInventoryCurrentStockDetail,
  getInventoryWarehouseDetail,
  getInventoryWorkspace,
  type AnalyticsDataStatus,
  type InventoryWorkspaceCurrentStockDetail,
  type InventoryWorkspaceCurrentStockRow,
  type InventoryWorkspaceFilters,
  type InventoryWorkspaceResponse,
  type InventoryWorkspaceSortBy,
  type InventoryWorkspaceSortOrder,
  type InventoryWorkspaceStockStatus,
  type InventoryWorkspaceSupplierReturnRow,
  type InventoryWorkspaceView,
  type InventoryWorkspaceWarehouseDetail,
  type InventoryWorkspaceWarehouseRow,
} from "@/lib/core-api";
import { formatMoneyValue } from "@/lib/money";

const PAGE_SIZE = 25;

type DetailState =
  | { kind: "current_stock"; row: InventoryWorkspaceCurrentStockRow }
  | { kind: "warehouse"; row: InventoryWorkspaceWarehouseRow }
  | null;

type QueryState = {
  view: InventoryWorkspaceView;
  search: string;
  warehouseId: string[];
  productId: string[];
  categoryId: string[];
  stockStatus: InventoryWorkspaceStockStatus[];
  hasStock: "all" | "yes" | "no";
  zeroStock: "all" | "yes" | "no";
  negativeStock: "all" | "yes" | "no";
  dataQuality: Array<"verified" | "partial" | "unresolved" | "unsafe">;
  sortBy: InventoryWorkspaceSortBy;
  sortOrder: InventoryWorkspaceSortOrder;
  page: number;
};

const VIEW_LABELS: Record<InventoryWorkspaceView, string> = {
  current_stock: "Текущий остаток",
  warehouses: "Склады",
  purchases: "Закупки",
  receipts: "Поступления",
  writeoffs: "Списания",
  movements: "Перемещения",
  stocktaking: "Инвентаризации",
  supplier_returns: "Возвраты поставщику",
};

const SORT_OPTIONS: Array<{ value: InventoryWorkspaceSortBy; label: string }> = [
  { value: "snapshot_date", label: "Дата snapshot" },
  { value: "quantity", label: "Количество" },
  { value: "product_name", label: "Товар" },
  { value: "warehouse", label: "Склад" },
  { value: "organization", label: "Организация" },
  { value: "stock_status", label: "Статус остатка" },
  { value: "document_date", label: "Дата документа" },
  { value: "amount", label: "Сумма" },
];

const SUMMARY_REGISTRY = [
  { key: "current_stock_quantity", label: "Текущий остаток" },
  { key: "products_in_stock", label: "Товаров в наличии" },
  { key: "warehouses", label: "Складов" },
  { key: "zero_stock_products", label: "Нулевой остаток" },
  { key: "negative_stock_products", label: "Отрицательный остаток" },
  { key: "low_stock_signals", label: "Низкий остаток" },
  { key: "overstock_signals", label: "Избыточный остаток" },
  { key: "inventory_value", label: "Оценка остатка" },
] as const;

function normalizeTriState(value: QueryState["hasStock" | "zeroStock" | "negativeStock"]) {
  if (value === "all") return null;
  return value === "yes";
}

function buildWorkspaceFilters(
  businessState: ReturnType<typeof useBusinessContext>["state"],
  query: QueryState,
): InventoryWorkspaceFilters {
  return {
    organizationIds: businessState.selectedOrganizationIds,
    period: businessState.period.preset,
    dateFrom: businessState.period.dateFrom,
    dateTo: businessState.period.dateTo,
    view: query.view,
    search: query.search || null,
    warehouseId: query.warehouseId,
    productId: query.productId,
    categoryId: query.categoryId,
    stockStatus: query.stockStatus,
    hasStock: normalizeTriState(query.hasStock),
    zeroStock: normalizeTriState(query.zeroStock),
    negativeStock: normalizeTriState(query.negativeStock),
    dataQuality: query.dataQuality,
    sortBy: query.sortBy,
    sortOrder: query.sortOrder,
    page: query.page,
    pageSize: PAGE_SIZE,
  };
}

function formatDateOnly(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

function metricTone(status: AnalyticsDataStatus) {
  return status === "AVAILABLE" || status === "PARTIAL"
    ? "text-slate-950"
    : "text-slate-400";
}

function statusLabel(status: AnalyticsDataStatus) {
  switch (status) {
    case "AVAILABLE":
      return "Подтверждено";
    case "PARTIAL":
      return "Частично";
    case "NO_DATA":
      return "Нет данных";
    case "NO_VERIFIED_DATA":
      return "Нет подтверждённых данных";
    case "UNRESOLVED":
      return "Неразрешено";
    case "NOT_AVAILABLE":
      return "Недоступно";
    default:
      return status;
  }
}

function qualityVariant(status: "verified" | "partial" | "unresolved" | "unsafe") {
  if (status === "verified") return "accent" as const;
  if (status === "partial") return "soft" as const;
  if (status === "unresolved") return "neutral" as const;
  return "dark" as const;
}

function stockVariant(status: InventoryWorkspaceStockStatus) {
  if (status === "IN_STOCK") return "accent" as const;
  if (status === "LOW_STOCK") return "soft" as const;
  if (status === "OVERSTOCK") return "soft" as const;
  if (status === "OUT_OF_STOCK") return "dark" as const;
  return "neutral" as const;
}

function stockLabel(status: InventoryWorkspaceStockStatus) {
  switch (status) {
    case "IN_STOCK":
      return "В наличии";
    case "LOW_STOCK":
      return "Низкий остаток";
    case "OUT_OF_STOCK":
      return "Нет остатка";
    case "OVERSTOCK":
      return "Избыточный остаток";
    case "STOCKOUT_RISK":
      return "Риск дефицита";
    case "NEGATIVE_STOCK":
      return "Отрицательный остаток";
    default:
      return status;
  }
}

function capabilityVariant(status: string) {
  if (status === "AVAILABLE") return "accent" as const;
  if (status === "NO_DATA" || status === "NO_VERIFIED_DATA") return "neutral" as const;
  return "soft" as const;
}

function formatMetricValue(
  value: string | number | null | undefined,
  currency?: string | null,
  status?: AnalyticsDataStatus,
) {
  if (status === "NOT_AVAILABLE") return "Недоступно";
  if (value == null) return "—";
  return formatMoneyValue(value, currency);
}

function MultiSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string[];
  options: Array<{ value: string; label: string; count?: number }>;
  onChange: (next: string[]) => void;
}) {
  return (
    <label className="flex min-w-[180px] flex-col gap-2">
      <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">{label}</span>
      <select
        multiple
        value={value}
        onChange={(event) => {
          const next = Array.from(event.target.selectedOptions).map((item) => item.value);
          onChange(next);
        }}
        className="min-h-[116px] rounded-[20px] border border-slate-200 bg-white px-3 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
      >
        {options.map((option) => (
          <option key={`${label}-${option.value}`} value={option.value}>
            {option.label}
            {typeof option.count === "number" ? ` (${option.count})` : ""}
          </option>
        ))}
      </select>
    </label>
  );
}

function buildDocumentRows(data: InventoryWorkspaceResponse) {
  switch (data.active_view) {
    case "purchases":
      return data.rows.purchases;
    case "receipts":
      return data.rows.receipts;
    case "writeoffs":
      return data.rows.writeoffs;
    case "movements":
      return data.rows.movements;
    case "stocktaking":
      return data.rows.stocktaking;
    case "supplier_returns":
      return data.rows.supplier_returns;
    default:
      return [];
  }
}

function renderDocumentTable(data: InventoryWorkspaceResponse) {
  const rows = buildDocumentRows(data);

  if (rows.length === 0) {
    return <div className="px-5 py-6 text-sm text-slate-500">По выбранному контексту записи не найдены.</div>;
  }

  if (data.active_view === "purchases") {
    return (
      <div className="overflow-x-auto">
        <table className="min-w-[1280px] border-separate border-spacing-0 text-left text-sm">
          <thead className="sticky top-0 z-10 bg-white">
            <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              {["Документ", "Дата", "Организация", "Склад", "Поставщик", "Qty", "Сумма", "Покрытие", "Качество"].map((column) => (
                <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.purchases.map((row) => (
              <tr key={row.purchase_id} className="border-b border-slate-100">
                <td className="px-4 py-4 font-medium text-slate-950">{row.document_number ?? row.source_external_id}</td>
                <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.document_date)}</td>
                <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
                <td className="px-4 py-4 text-slate-600">{row.warehouse_name ?? row.warehouse_code ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.supplier_code ?? row.supplier_external_id ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.total_quantity ?? "—"}</td>
                <td className="px-4 py-4 font-medium text-slate-950">{row.amount ? formatMoneyValue(row.amount, row.currency_code) : "—"}</td>
                <td className="px-4 py-4 text-slate-600">
                  Товар {row.product_linkage_coverage ?? "—"} · Склад {row.warehouse_linkage_coverage ?? "—"}
                </td>
                <td className="px-4 py-4">
                  <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (data.active_view === "receipts") {
    return (
      <div className="overflow-x-auto">
        <table className="min-w-[1240px] border-separate border-spacing-0 text-left text-sm">
          <thead className="sticky top-0 z-10 bg-white">
            <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              {["Документ", "Дата", "Организация", "Склад", "Поставщик", "Связь с закупкой", "Qty", "Сумма", "Качество"].map((column) => (
                <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.receipts.map((row) => (
              <tr key={row.receipt_id} className="border-b border-slate-100">
                <td className="px-4 py-4 font-medium text-slate-950">{row.document_number ?? row.source_external_id}</td>
                <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.document_date)}</td>
                <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
                <td className="px-4 py-4 text-slate-600">{row.warehouse_name ?? row.warehouse_code ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.supplier_code ?? row.supplier_external_id ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.linked_purchase_external_id ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.total_quantity ?? "—"}</td>
                <td className="px-4 py-4 font-medium text-slate-950">{row.amount ? formatMoneyValue(row.amount, row.currency_code) : "—"}</td>
                <td className="px-4 py-4">
                  <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (data.active_view === "writeoffs") {
    return (
      <div className="overflow-x-auto">
        <table className="min-w-[1120px] border-separate border-spacing-0 text-left text-sm">
          <thead className="sticky top-0 z-10 bg-white">
            <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              {["Документ", "Дата", "Организация", "Склад", "Причина", "Qty", "Сумма", "Статус", "Качество"].map((column) => (
                <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.writeoffs.map((row) => (
              <tr key={row.writeoff_id} className="border-b border-slate-100">
                <td className="px-4 py-4 font-medium text-slate-950">{row.document_number ?? row.source_external_id}</td>
                <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.document_date)}</td>
                <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
                <td className="px-4 py-4 text-slate-600">{row.warehouse_name ?? row.warehouse_code ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.reason_code ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.total_quantity ?? "—"}</td>
                <td className="px-4 py-4 font-medium text-slate-950">{row.amount ? formatMoneyValue(row.amount, row.currency_code) : "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.status ?? "—"}</td>
                <td className="px-4 py-4">
                  <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (data.active_view === "movements") {
    return (
      <div className="overflow-x-auto">
        <table className="min-w-[1360px] border-separate border-spacing-0 text-left text-sm">
          <thead className="sticky top-0 z-10 bg-white">
            <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              {["Документ", "Дата", "Организация", "Источник", "Назначение", "Qty", "Сумма", "Тип", "Качество"].map((column) => (
                <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.movements.map((row) => (
              <tr key={row.movement_id} className="border-b border-slate-100">
                <td className="px-4 py-4 font-medium text-slate-950">{row.document_number ?? row.source_external_id}</td>
                <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.document_date)}</td>
                <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
                <td className="px-4 py-4 text-slate-600">
                  {[row.source_organization_name, row.source_warehouse_name ?? row.source_warehouse_code].filter(Boolean).join(" · ") || "—"}
                </td>
                <td className="px-4 py-4 text-slate-600">
                  {[row.destination_organization_name, row.destination_warehouse_name ?? row.destination_warehouse_code].filter(Boolean).join(" · ") || "—"}
                </td>
                <td className="px-4 py-4 text-slate-600">{row.total_quantity ?? "—"}</td>
                <td className="px-4 py-4 font-medium text-slate-950">{row.amount ? formatMoneyValue(row.amount, row.currency_code) : "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.movement_type}</td>
                <td className="px-4 py-4">
                  <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (data.active_view === "stocktaking") {
    return (
      <div className="overflow-x-auto">
        <table className="min-w-[1000px] border-separate border-spacing-0 text-left text-sm">
          <thead className="sticky top-0 z-10 bg-white">
            <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
              {["Документ", "Дата", "Организация", "Склад", "Qty", "Качество"].map((column) => (
                <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.stocktaking.map((row) => (
              <tr key={row.stocktaking_id} className="border-b border-slate-100">
                <td className="px-4 py-4 font-medium text-slate-950">{row.document_number ?? row.source_external_id}</td>
                <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.document_date)}</td>
                <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
                <td className="px-4 py-4 text-slate-600">{row.warehouse_name ?? row.warehouse_code ?? "—"}</td>
                <td className="px-4 py-4 text-slate-600">{row.total_quantity ?? "—"}</td>
                <td className="px-4 py-4">
                  <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-[1180px] border-separate border-spacing-0 text-left text-sm">
        <thead className="sticky top-0 z-10 bg-white">
          <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
            {["Документ", "Дата", "Организация", "Склад", "Поставщик", "Причина", "Qty", "Сумма", "Качество"].map((column) => (
              <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.rows.supplier_returns.map((row: InventoryWorkspaceSupplierReturnRow) => (
            <tr key={row.supplier_return_id} className="border-b border-slate-100">
              <td className="px-4 py-4 font-medium text-slate-950">{row.document_number ?? row.source_external_id}</td>
              <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.document_date)}</td>
              <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
              <td className="px-4 py-4 text-slate-600">{row.warehouse_name ?? row.warehouse_code ?? "—"}</td>
              <td className="px-4 py-4 text-slate-600">{row.supplier_code ?? row.supplier_external_id ?? "—"}</td>
              <td className="px-4 py-4 text-slate-600">{row.reason_code ?? "—"}</td>
              <td className="px-4 py-4 text-slate-600">{row.total_quantity ?? "—"}</td>
              <td className="px-4 py-4 font-medium text-slate-950">{row.amount ? formatMoneyValue(row.amount, row.currency_code) : "—"}</td>
              <td className="px-4 py-4">
                <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function InventoryWorkspacePage() {
  const business = useBusinessContext();
  const selectedNames = useSelectedOrganizationNames();
  const [query, setQuery] = useState<QueryState>({
    view: "current_stock",
    search: "",
    warehouseId: [],
    productId: [],
    categoryId: [],
    stockStatus: [],
    hasStock: "all",
    zeroStock: "all",
    negativeStock: "all",
    dataQuality: [],
    sortBy: "snapshot_date",
    sortOrder: "desc",
    page: 1,
  });
  const [data, setData] = useState<InventoryWorkspaceResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedDetail, setSelectedDetail] = useState<DetailState>(null);
  const [stockDetail, setStockDetail] = useState<InventoryWorkspaceCurrentStockDetail | null>(null);
  const [warehouseDetail, setWarehouseDetail] = useState<InventoryWorkspaceWarehouseDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);

  const filters = useMemo(() => buildWorkspaceFilters(business.state, query), [business.state, query]);

  useEffect(() => {
    let active = true;
    startTransition(() => {
      setLoading(true);
    });
    void getInventoryWorkspace(filters)
      .then((response) => {
        if (!active) return;
        setData(response);
        setError(null);
      })
      .catch((reason) => {
        if (!active) return;
        setError(reason instanceof Error ? reason.message : "Не удалось загрузить складской workspace.");
        setData(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [filters]);

  useEffect(() => {
    if (!selectedDetail) return;
    let active = true;
    startTransition(() => {
      setDetailLoading(true);
      setDetailError(null);
    });

    const detailRequest =
      selectedDetail.kind === "current_stock"
        ? getInventoryCurrentStockDetail(selectedDetail.row.inventory_balance_id, filters)
        : getInventoryWarehouseDetail(selectedDetail.row.warehouse_key, filters);

    void detailRequest
      .then((response) => {
        if (!active) return;
        if (selectedDetail.kind === "current_stock") {
          setStockDetail(response as InventoryWorkspaceCurrentStockDetail);
          setWarehouseDetail(null);
        } else {
          setWarehouseDetail(response as InventoryWorkspaceWarehouseDetail);
          setStockDetail(null);
        }
      })
      .catch((reason) => {
        if (!active) return;
        setDetailError(reason instanceof Error ? reason.message : "Не удалось загрузить детали.");
        setStockDetail(null);
        setWarehouseDetail(null);
      })
      .finally(() => {
        if (active) setDetailLoading(false);
      });

    return () => {
      active = false;
    };
  }, [selectedDetail, filters]);

  const summaryTiles = useMemo(() => {
    if (!data) return [];
    return SUMMARY_REGISTRY.map(({ key, label }) => ({
      key,
      label,
      metric: data.summary[key],
    }));
  }, [data]);

  return (
    <section className="space-y-5">
      <div className="space-y-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">Inventory / Warehouse</p>
            <h1 className="mt-2 text-3xl font-semibold tracking-[-0.05em] text-slate-950">
              Склад и warehouse workspace
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
              Канонический слой по остаткам, складам, закупкам, поступлениям, списаниям и движениям.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="soft">{selectedNames.join(", ") || "Все организации"}</Badge>
            <Badge variant="soft">{data?.period.label ?? "Период загружается"}</Badge>
          </div>
        </div>
      </div>

      <Surface className="overflow-visible px-4 py-4 sm:px-5">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {summaryTiles.map(({ key, label, metric }) => (
            <div key={key} className="rounded-[22px] border border-slate-200 bg-white px-4 py-4">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{label}</p>
                <Badge variant="soft">{statusLabel(metric.data_status)}</Badge>
              </div>
              <p className={cn("mt-4 text-3xl font-semibold tracking-[-0.05em]", metricTone(metric.data_status))}>
                {formatMetricValue(metric.value, metric.currency, metric.data_status)}
              </p>
              <p className="mt-2 min-h-[40px] text-sm leading-5 text-slate-500">{metric.note ?? "—"}</p>
            </div>
          ))}
        </div>
      </Surface>

      <Surface className="overflow-visible px-4 py-4 sm:px-5">
        <div className="flex flex-wrap gap-2">
          {(data?.tabs ?? []).map((tab) => (
            <button
              key={tab.view}
              type="button"
              onClick={() => {
                setQuery((current) => ({
                  ...current,
                  view: tab.view,
                  page: 1,
                  sortBy: tab.view === "current_stock" || tab.view === "warehouses" ? "snapshot_date" : "document_date",
                }));
              }}
              className={cn(
                "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition",
                query.view === tab.view
                  ? "border-slate-900 bg-slate-950 text-white"
                  : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:text-slate-900",
              )}
            >
              <span>{tab.label}</span>
              <Badge variant={query.view === tab.view ? "dark" : capabilityVariant(tab.status)}>
                {tab.count}
              </Badge>
            </button>
          ))}
        </div>
      </Surface>

      <Surface className="overflow-visible px-4 py-4 sm:px-5">
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Поиск</span>
              <input
                value={query.search}
                onChange={(event) => setQuery((current) => ({ ...current, search: event.target.value, page: 1 }))}
                placeholder="товар, код, склад, batch"
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-950 outline-none transition focus:border-violet-300"
              />
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Наличие</span>
              <select
                value={query.hasStock}
                onChange={(event) => setQuery((current) => ({ ...current, hasStock: event.target.value as QueryState["hasStock"], page: 1 }))}
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="all">Все</option>
                <option value="yes">Только с остатком</option>
                <option value="no">Без остатка</option>
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Нулевой остаток</span>
              <select
                value={query.zeroStock}
                onChange={(event) => setQuery((current) => ({ ...current, zeroStock: event.target.value as QueryState["zeroStock"], page: 1 }))}
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="all">Все</option>
                <option value="yes">Только нулевой</option>
                <option value="no">Исключить нулевой</option>
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Отрицательный остаток</span>
              <select
                value={query.negativeStock}
                onChange={(event) => setQuery((current) => ({ ...current, negativeStock: event.target.value as QueryState["negativeStock"], page: 1 }))}
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="all">Все</option>
                <option value="yes">Только отрицательный</option>
                <option value="no">Исключить отрицательный</option>
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Сортировка</span>
              <select
                value={query.sortBy}
                onChange={(event) => setQuery((current) => ({ ...current, sortBy: event.target.value as InventoryWorkspaceSortBy }))}
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                {SORT_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>{option.label}</option>
                ))}
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Порядок</span>
              <select
                value={query.sortOrder}
                onChange={(event) => setQuery((current) => ({ ...current, sortOrder: event.target.value as InventoryWorkspaceSortOrder }))}
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="desc">Сначала больше</option>
                <option value="asc">Сначала меньше</option>
              </select>
            </label>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-2">
            <MultiSelect
              label="Склады"
              value={query.warehouseId}
              options={data?.filters.warehouses ?? []}
              onChange={(next) => setQuery((current) => ({ ...current, warehouseId: next, page: 1 }))}
            />
            <MultiSelect
              label="Статус остатка"
              value={query.stockStatus}
              options={data?.filters.stock_statuses ?? []}
              onChange={(next) =>
                setQuery((current) => ({
                  ...current,
                  stockStatus: next as InventoryWorkspaceStockStatus[],
                  page: 1,
                }))
              }
            />
            <MultiSelect
              label="Категории"
              value={query.categoryId}
              options={data?.filters.categories ?? []}
              onChange={(next) => setQuery((current) => ({ ...current, categoryId: next, page: 1 }))}
            />
            <MultiSelect
              label="Товары"
              value={query.productId}
              options={data?.filters.products ?? []}
              onChange={(next) => setQuery((current) => ({ ...current, productId: next, page: 1 }))}
            />
          </div>
        </div>
      </Surface>

      <Surface className="overflow-hidden">
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">{VIEW_LABELS[query.view]}</p>
            <h2 className="mt-1 text-xl font-semibold tracking-[-0.04em] text-slate-950">
              {query.view === "current_stock"
                ? "Текущий остаток по товарам и складам"
                : query.view === "warehouses"
                  ? "Склады и состояние запасов"
                  : "Операционный список документов"}
            </h2>
          </div>
          <Badge variant="soft">{data?.pagination.total_items ?? 0} записей</Badge>
        </div>

        {error ? (
          <div className="px-5 py-6 text-sm text-rose-600">{error}</div>
        ) : loading ? (
          <div className="px-5 py-6 text-sm text-slate-500">Загрузка склада...</div>
        ) : !data ? (
          <div className="px-5 py-6 text-sm text-slate-500">Нет данных для выбранного контекста.</div>
        ) : query.view === "current_stock" ? (
          data.rows.current_stock.length === 0 ? (
            <div className="px-5 py-6 text-sm text-slate-500">Остатки не найдены.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-[1560px] border-separate border-spacing-0 text-left text-sm">
                <thead className="sticky top-0 z-10 bg-white">
                  <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
                    {["Товар", "Код", "Организация", "Склад", "Qty", "Available", "Reserved", "Оценка", "Snapshot", "Velocity 30d", "Дней остатка", "Статус", "Качество"].map((column) => (
                      <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.rows.current_stock.map((row) => (
                    <tr
                      key={row.inventory_balance_id}
                      className="cursor-pointer border-b border-slate-100 transition hover:bg-slate-50/80"
                      onClick={() => {
                        setSelectedDetail({ kind: "current_stock", row });
                        setStockDetail(null);
                        setWarehouseDetail(null);
                      }}
                    >
                      <td className="px-4 py-4 align-top">
                        <div className="space-y-1">
                          <p className="font-semibold text-slate-950">
                            {row.product_id ? (
                              <Link
                                href={`/products?entity_id=${encodeURIComponent(row.product_id)}`}
                                className="transition hover:text-violet-600"
                                onClick={(event) => event.stopPropagation()}
                              >
                                {row.product_name}
                              </Link>
                            ) : (
                              row.product_name
                            )}
                          </p>
                          <p className="text-xs text-slate-400">
                            {[row.category_name, row.batch_number, row.inventory_kind].filter(Boolean).join(" · ") || "—"}
                          </p>
                        </div>
                      </td>
                      <td className="px-4 py-4 text-slate-600">{row.product_code ?? "—"}</td>
                      <td className="px-4 py-4 text-slate-950">{row.organization_name}</td>
                      <td className="px-4 py-4 text-slate-600">{row.warehouse_name ?? row.warehouse_code ?? "—"}</td>
                      <td className="px-4 py-4 font-medium text-slate-950">{row.quantity ?? "—"}</td>
                      <td className="px-4 py-4 text-slate-600">{row.available_quantity ?? "—"}</td>
                      <td className="px-4 py-4 text-slate-600">{row.reserved_quantity ?? "—"}</td>
                      <td className="px-4 py-4 text-slate-600">{row.valuation_amount ? formatMoneyValue(row.valuation_amount, row.currency_code) : "—"}</td>
                      <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.snapshot_date)}</td>
                      <td className="px-4 py-4 text-slate-600">{row.sales_velocity_30d ?? "—"}</td>
                      <td className="px-4 py-4 text-slate-600">{row.days_of_stock ?? "—"}</td>
                      <td className="px-4 py-4">
                        <Badge variant={stockVariant(row.stock_status)}>{stockLabel(row.stock_status)}</Badge>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        ) : query.view === "warehouses" ? (
          data.rows.warehouses.length === 0 ? (
            <div className="px-5 py-6 text-sm text-slate-500">Склады не найдены.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-[1300px] border-separate border-spacing-0 text-left text-sm">
                <thead className="sticky top-0 z-10 bg-white">
                  <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
                    {["Склад", "Организация", "Товаров", "Qty", "Последний snapshot", "Low stock", "Out", "Overstock", "Negative", "Качество"].map((column) => (
                      <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.rows.warehouses.map((row) => (
                    <tr
                      key={row.warehouse_key}
                      className="cursor-pointer border-b border-slate-100 transition hover:bg-slate-50/80"
                      onClick={() => {
                        setSelectedDetail({ kind: "warehouse", row });
                        setStockDetail(null);
                        setWarehouseDetail(null);
                      }}
                    >
                      <td className="px-4 py-4 font-medium text-slate-950">{row.warehouse_name ?? row.warehouse_code ?? "Без кода"}</td>
                      <td className="px-4 py-4 text-slate-600">{row.organization_name}</td>
                      <td className="px-4 py-4 text-slate-600">{row.products_count}</td>
                      <td className="px-4 py-4 font-medium text-slate-950">{row.current_quantity ?? "—"}</td>
                      <td className="px-4 py-4 text-slate-600">{formatDateOnly(row.last_snapshot)}</td>
                      <td className="px-4 py-4 text-slate-600">{row.low_stock_count}</td>
                      <td className="px-4 py-4 text-slate-600">{row.out_of_stock_count}</td>
                      <td className="px-4 py-4 text-slate-600">{row.overstock_count}</td>
                      <td className="px-4 py-4 text-slate-600">{row.negative_stock_count}</td>
                      <td className="px-4 py-4">
                        <Badge variant={qualityVariant(row.data_quality_status)}>{row.data_quality_status}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        ) : (
          renderDocumentTable(data)
        )}

        {data ? (
          <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
            <p className="text-sm text-slate-500">
              Показано {data.pagination.total_items === 0 ? 0 : Math.min(data.rows[query.view].length, data.pagination.total_items)} из {data.pagination.total_items}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={data.pagination.page <= 1}
                onClick={() => setQuery((current) => ({ ...current, page: Math.max(1, current.page - 1) }))}
                className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 transition hover:border-slate-300 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Назад
              </button>
              <Badge variant="soft">{data.pagination.page} / {data.pagination.total_pages}</Badge>
              <button
                type="button"
                disabled={data.pagination.page >= data.pagination.total_pages}
                onClick={() => setQuery((current) => ({ ...current, page: current.page + 1 }))}
                className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 transition hover:border-slate-300 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Далее
              </button>
            </div>
          </div>
        ) : null}
      </Surface>

      <Drawer
        open={selectedDetail !== null}
        onClose={() => {
          setSelectedDetail(null);
          setStockDetail(null);
          setWarehouseDetail(null);
          setDetailError(null);
        }}
        title={
          selectedDetail?.kind === "current_stock"
            ? selectedDetail.row.product_name
            : selectedDetail?.kind === "warehouse"
              ? selectedDetail.row.warehouse_name ?? selectedDetail.row.warehouse_code ?? "Склад"
              : "Детали"
        }
        description={
          selectedDetail?.kind === "current_stock"
            ? `${selectedDetail.row.organization_name} · ${selectedDetail.row.warehouse_name ?? selectedDetail.row.warehouse_code ?? "Без склада"}`
            : selectedDetail?.kind === "warehouse"
              ? selectedDetail.row.organization_name
              : undefined
        }
        badges={
          selectedDetail?.kind === "current_stock" ? (
            <>
              <Badge variant={stockVariant(selectedDetail.row.stock_status)}>{stockLabel(selectedDetail.row.stock_status)}</Badge>
              <Badge variant={qualityVariant(selectedDetail.row.data_quality_status)}>{selectedDetail.row.data_quality_status}</Badge>
            </>
          ) : selectedDetail?.kind === "warehouse" ? (
            <Badge variant={qualityVariant(selectedDetail.row.data_quality_status)}>{selectedDetail.row.data_quality_status}</Badge>
          ) : null
        }
        className="max-w-[min(48rem,100vw)]"
      >
        {detailError ? (
          <p className="text-sm text-rose-600">{detailError}</p>
        ) : detailLoading ? (
          <p className="text-sm text-slate-500">Загрузка деталей...</p>
        ) : selectedDetail?.kind === "current_stock" && stockDetail ? (
          <div className="space-y-5">
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              {[
                { label: "Текущий qty", value: stockDetail.row.quantity, currency: null },
                { label: "Available", value: stockDetail.row.available_quantity, currency: null },
                { label: "Reserved", value: stockDetail.row.reserved_quantity, currency: null },
                { label: "Оценка", value: stockDetail.row.valuation_amount, currency: stockDetail.row.currency_code },
              ].map((item) => (
                <div key={item.label} className="rounded-[20px] border border-slate-200 bg-white px-4 py-4">
                  <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{item.label}</p>
                  <p className="mt-3 text-xl font-semibold tracking-[-0.04em] text-slate-950">
                    {formatMetricValue(item.value, item.currency)}
                  </p>
                </div>
              ))}
            </div>

            <Surface className="overflow-hidden">
              <div className="border-b border-slate-200 px-5 py-4">
                <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Последние snapshot</h3>
              </div>
              <div className="max-h-[260px] overflow-y-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500">
                    <tr>
                      {["Дата", "Qty", "Available", "Reserved", "Оценка"].map((column) => (
                        <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {stockDetail.recent_snapshots.map((item) => (
                      <tr key={item.inventory_balance_id} className="border-b border-slate-100">
                        <td className="px-4 py-3 text-slate-600">{formatDateOnly(item.snapshot_date)}</td>
                        <td className="px-4 py-3 text-slate-950">{item.quantity ?? "—"}</td>
                        <td className="px-4 py-3 text-slate-600">{item.available_quantity ?? "—"}</td>
                        <td className="px-4 py-3 text-slate-600">{item.reserved_quantity ?? "—"}</td>
                        <td className="px-4 py-3 text-slate-600">{item.valuation_amount ? formatMoneyValue(item.valuation_amount, item.currency_code) : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Surface>

            <div className="grid gap-4 xl:grid-cols-3">
              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-base font-semibold tracking-[-0.04em] text-slate-950">Поступления</h3>
                </div>
                <div className="max-h-[240px] overflow-y-auto px-5 py-4 text-sm text-slate-600">
                  <div className="space-y-3">
                    {stockDetail.recent_receipts.length === 0 ? (
                      <p>Нет связанных поступлений.</p>
                    ) : (
                      stockDetail.recent_receipts.map((item) => (
                        <div key={item.receipt_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                          <p className="font-medium text-slate-950">{item.document_number ?? item.source_external_id}</p>
                          <p className="mt-1 text-sm text-slate-500">
                            {formatDateOnly(item.document_date)} · {item.total_quantity ?? "—"} · {item.amount ? formatMoneyValue(item.amount, item.currency_code) : "—"}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-base font-semibold tracking-[-0.04em] text-slate-950">Списания</h3>
                </div>
                <div className="max-h-[240px] overflow-y-auto px-5 py-4 text-sm text-slate-600">
                  <div className="space-y-3">
                    {stockDetail.recent_writeoffs.length === 0 ? (
                      <p>Нет связанных списаний.</p>
                    ) : (
                      stockDetail.recent_writeoffs.map((item) => (
                        <div key={item.writeoff_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                          <p className="font-medium text-slate-950">{item.document_number ?? item.source_external_id}</p>
                          <p className="mt-1 text-sm text-slate-500">
                            {formatDateOnly(item.document_date)} · {item.total_quantity ?? "—"} · {item.amount ? formatMoneyValue(item.amount, item.currency_code) : "—"}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-base font-semibold tracking-[-0.04em] text-slate-950">Перемещения</h3>
                </div>
                <div className="max-h-[240px] overflow-y-auto px-5 py-4 text-sm text-slate-600">
                  <div className="space-y-3">
                    {stockDetail.recent_movements.length === 0 ? (
                      <p>Нет связанных перемещений.</p>
                    ) : (
                      stockDetail.recent_movements.map((item) => (
                        <div key={item.movement_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                          <p className="font-medium text-slate-950">{item.document_number ?? item.source_external_id}</p>
                          <p className="mt-1 text-sm text-slate-500">
                            {formatDateOnly(item.document_date)} · {item.total_quantity ?? "—"} · {item.direction ?? item.movement_type}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </Surface>
            </div>

            <Surface className="px-5 py-4">
              <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">Ограничения</p>
              <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-600">
                {stockDetail.limitations.length === 0 ? (
                  <li>Явных ограничений не обнаружено.</li>
                ) : (
                  stockDetail.limitations.map((item) => <li key={item}>• {item}</li>)
                )}
              </ul>
            </Surface>
          </div>
        ) : selectedDetail?.kind === "warehouse" && warehouseDetail ? (
          <div className="space-y-5">
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              {[
                { label: "Товаров", value: warehouseDetail.row.products_count, currency: null },
                { label: "Qty", value: warehouseDetail.row.current_quantity, currency: null },
                { label: "Low stock", value: warehouseDetail.row.low_stock_count, currency: null },
                { label: "Out of stock", value: warehouseDetail.row.out_of_stock_count, currency: null },
              ].map((item) => (
                <div key={item.label} className="rounded-[20px] border border-slate-200 bg-white px-4 py-4">
                  <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{item.label}</p>
                  <p className="mt-3 text-xl font-semibold tracking-[-0.04em] text-slate-950">
                    {formatMetricValue(item.value, item.currency)}
                  </p>
                </div>
              ))}
            </div>

            <Surface className="overflow-hidden">
              <div className="border-b border-slate-200 px-5 py-4">
                <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Текущий остаток по складу</h3>
              </div>
              <div className="max-h-[320px] overflow-y-auto">
                <table className="min-w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500">
                    <tr>
                      {["Товар", "Qty", "Available", "Reserved", "Snapshot", "Статус"].map((column) => (
                        <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {warehouseDetail.current_stock.map((item) => (
                      <tr key={item.inventory_balance_id} className="border-b border-slate-100">
                        <td className="px-4 py-3 font-medium text-slate-950">{item.product_name}</td>
                        <td className="px-4 py-3 text-slate-600">{item.quantity ?? "—"}</td>
                        <td className="px-4 py-3 text-slate-600">{item.available_quantity ?? "—"}</td>
                        <td className="px-4 py-3 text-slate-600">{item.reserved_quantity ?? "—"}</td>
                        <td className="px-4 py-3 text-slate-600">{formatDateOnly(item.snapshot_date)}</td>
                        <td className="px-4 py-3">
                          <Badge variant={stockVariant(item.stock_status)}>{stockLabel(item.stock_status)}</Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Surface>

            <div className="grid gap-4 xl:grid-cols-2">
              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-base font-semibold tracking-[-0.04em] text-slate-950">Закупки и поступления</h3>
                </div>
                <div className="max-h-[280px] overflow-y-auto px-5 py-4">
                  <div className="space-y-3">
                    {[...warehouseDetail.purchases, ...warehouseDetail.receipts].length === 0 ? (
                      <p className="text-sm text-slate-500">Нет связанных документов.</p>
                    ) : (
                      [...warehouseDetail.purchases, ...warehouseDetail.receipts].map((item) => (
                        <div key={item.source_external_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                          <p className="font-medium text-slate-950">{item.document_number ?? item.source_external_id}</p>
                          <p className="mt-1 text-sm text-slate-500">
                            {formatDateOnly(item.document_date)} · {item.total_quantity ?? "—"} · {item.amount ? formatMoneyValue(item.amount, item.currency_code) : "—"}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-base font-semibold tracking-[-0.04em] text-slate-950">Списания и движения</h3>
                </div>
                <div className="max-h-[280px] overflow-y-auto px-5 py-4">
                  <div className="space-y-3">
                    {[...warehouseDetail.writeoffs, ...warehouseDetail.movements, ...warehouseDetail.stocktaking, ...warehouseDetail.supplier_returns].length === 0 ? (
                      <p className="text-sm text-slate-500">Нет связанных документов.</p>
                    ) : (
                      [...warehouseDetail.writeoffs, ...warehouseDetail.movements, ...warehouseDetail.stocktaking, ...warehouseDetail.supplier_returns].map((item) => (
                        <div key={item.source_external_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                          <p className="font-medium text-slate-950">{item.document_number ?? item.source_external_id}</p>
                          <p className="mt-1 text-sm text-slate-500">
                            {formatDateOnly(item.document_date)} · {"total_quantity" in item ? item.total_quantity ?? "—" : "—"} · {"amount" in item && item.amount ? formatMoneyValue(item.amount, item.currency_code) : "—"}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </Surface>
            </div>

            <Surface className="px-5 py-4">
              <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">Ограничения</p>
              <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-600">
                {warehouseDetail.limitations.length === 0 ? (
                  <li>Явных ограничений не обнаружено.</li>
                ) : (
                  warehouseDetail.limitations.map((item) => <li key={item}>• {item}</li>)
                )}
              </ul>
            </Surface>
          </div>
        ) : (
          <p className="text-sm text-slate-500">Выберите строку для просмотра деталей.</p>
        )}
      </Drawer>
    </section>
  );
}
