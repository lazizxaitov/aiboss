"use client";

import { useEffect, useMemo, useState } from "react";

import {
  useBusinessContext,
  useSelectedOrganizationNames,
} from "@/components/business/business-context-provider";
import { Badge } from "@/components/ui/badge";
import { Drawer } from "@/components/ui/drawer";
import { Surface } from "@/components/ui/surface";
import { cn } from "@/lib/cn";
import {
  getProductWorkspace,
  getProductWorkspaceDetail,
  type AnalyticsDataStatus,
  type ProductWorkspaceDetail,
  type ProductWorkspaceFilters,
  type ProductWorkspaceRow,
  type ProductWorkspaceSortBy,
  type ProductWorkspaceSortOrder,
  type ProductWorkspaceStockStatus,
} from "@/lib/core-api";
import { formatMoneyValue } from "@/lib/money";

const PAGE_SIZE = 25;

const SUMMARY_REGISTRY = [
  { key: "products", label: "Товаров" },
  { key: "products_sold", label: "Продавалось" },
  { key: "sold_units", label: "Продано единиц" },
  { key: "revenue", label: "Выручка" },
  { key: "average_selling_price", label: "Средняя цена" },
  { key: "current_stock", label: "Текущий остаток" },
  { key: "out_of_stock", label: "Нет в наличии" },
  { key: "low_stock", label: "Низкий остаток" },
  { key: "overstock", label: "Избыточный остаток" },
  { key: "return_quantity", label: "Возвращено ед." },
  { key: "return_value", label: "Сумма возвратов" },
] as const;

const SORT_OPTIONS: Array<{ value: ProductWorkspaceSortBy; label: string }> = [
  { value: "revenue", label: "Выручка" },
  { value: "sold_units", label: "Продано единиц" },
  { value: "orders", label: "Заказы" },
  { value: "customers", label: "Клиенты" },
  { value: "current_stock", label: "Текущий остаток" },
  { value: "last_sale", label: "Последняя продажа" },
  { value: "return_quantity", label: "Возвраты" },
  { value: "product_name", label: "Товар" },
] as const;

type QueryState = {
  search: string;
  categoryIds: string[];
  stockStatus: ProductWorkspaceStockStatus[];
  hasSales: "all" | "yes" | "no";
  hasReturns: "all" | "yes" | "no";
  dataQuality: Array<"verified" | "partial" | "unresolved" | "unsafe">;
  sortBy: ProductWorkspaceSortBy;
  sortOrder: ProductWorkspaceSortOrder;
  page: number;
};

function normalizeBooleanFilter(value: QueryState["hasSales" | "hasReturns"]) {
  if (value === "all") return null;
  return value === "yes";
}

function formatDateTime(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatDateOnly(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(date);
}

function statusLabel(status: AnalyticsDataStatus) {
  switch (status) {
    case "AVAILABLE":
      return "Подтверждено";
    case "PARTIAL":
      return "Частично";
    case "NO_DATA":
      return "Нет данных";
    case "NO_VERIFIED_DATA":
      return "Нет подтверждённых данных";
    case "UNRESOLVED":
      return "Есть неразрешённые связи";
    case "NOT_AVAILABLE":
      return "Недоступно";
    default:
      return status;
  }
}

function qualityBadgeVariant(status: ProductWorkspaceRow["data_quality_status"]) {
  if (status === "verified") return "accent" as const;
  if (status === "partial") return "soft" as const;
  if (status === "unresolved") return "neutral" as const;
  return "dark" as const;
}

function stockBadgeVariant(status: ProductWorkspaceStockStatus | null) {
  if (status === "IN_STOCK") return "accent" as const;
  if (status === "LOW_STOCK") return "soft" as const;
  if (status === "OUT_OF_STOCK") return "dark" as const;
  return "neutral" as const;
}

function stockStatusLabel(status: ProductWorkspaceStockStatus | null) {
  switch (status) {
    case "IN_STOCK":
      return "В наличии";
    case "LOW_STOCK":
      return "Низкий остаток";
    case "OUT_OF_STOCK":
      return "Нет остатка";
    case "OVERSTOCK":
      return "Избыток";
    default:
      return "—";
  }
}

function metricValueTone(status: AnalyticsDataStatus) {
  if (status === "AVAILABLE") return "text-slate-950";
  if (status === "PARTIAL") return "text-slate-950";
  return "text-slate-400";
}

function formatMetricValue(
  value: string | number | null | undefined,
  currency?: string | null,
  status?: AnalyticsDataStatus,
) {
  if (status === "NOT_AVAILABLE") return "Недоступно";
  if (value == null) return "—";
  return formatMoneyValue(value, currency);
}

function buildWorkspaceFilters(
  businessState: ReturnType<typeof useBusinessContext>["state"],
  query: QueryState,
): ProductWorkspaceFilters {
  return {
    organizationIds: businessState.selectedOrganizationIds,
    period: businessState.period.preset,
    dateFrom: businessState.period.dateFrom,
    dateTo: businessState.period.dateTo,
    search: query.search || null,
    categoryIds: query.categoryIds,
    stockStatus: query.stockStatus,
    hasSales: normalizeBooleanFilter(query.hasSales),
    hasReturns: normalizeBooleanFilter(query.hasReturns),
    dataQuality: query.dataQuality,
    sortBy: query.sortBy,
    sortOrder: query.sortOrder,
    page: query.page,
    pageSize: PAGE_SIZE,
  };
}

function MultiSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string[];
  options: Array<{ value: string; label: string; count?: number }>;
  onChange: (next: string[]) => void;
}) {
  return (
    <label className="flex min-w-[180px] flex-col gap-2">
      <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">{label}</span>
      <select
        multiple
        value={value}
        onChange={(event) => {
          const next = Array.from(event.target.selectedOptions).map((item) => item.value);
          onChange(next);
        }}
        className="min-h-[116px] rounded-[20px] border border-slate-200 bg-white px-3 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
      >
        {options.map((option) => (
          <option key={`${label}-${option.value}`} value={option.value}>
            {option.label}
            {typeof option.count === "number" ? ` (${option.count})` : ""}
          </option>
        ))}
      </select>
    </label>
  );
}

export function ProductsWorkspacePage() {
  const business = useBusinessContext();
  const selectedNames = useSelectedOrganizationNames();
  const [query, setQuery] = useState<QueryState>({
    search: "",
    categoryIds: [],
    stockStatus: [],
    hasSales: "all",
    hasReturns: "all",
    dataQuality: [],
    sortBy: "revenue",
    sortOrder: "desc",
    page: 1,
  });
  const [data, setData] = useState<Awaited<ReturnType<typeof getProductWorkspace>> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRow, setSelectedRow] = useState<ProductWorkspaceRow | null>(null);
  const [detail, setDetail] = useState<ProductWorkspaceDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);

  const filters = useMemo(() => buildWorkspaceFilters(business.state, query), [business.state, query]);

  useEffect(() => {
    let active = true;
    void getProductWorkspace(filters)
      .then((response) => {
        if (!active) return;
        setData(response);
        setError(null);
      })
      .catch((reason) => {
        if (!active) return;
        setError(reason instanceof Error ? reason.message : "Не удалось загрузить товары.");
        setData(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [filters]);

  useEffect(() => {
    if (!selectedRow) return;
    let active = true;
    void getProductWorkspaceDetail(selectedRow.product_id, filters)
      .then((response) => {
        if (!active) return;
        setDetail(response);
        setDetailError(null);
      })
      .catch((reason) => {
        if (!active) return;
        setDetailError(reason instanceof Error ? reason.message : "Не удалось загрузить Product 360.");
        setDetail(null);
      })
      .finally(() => {
        if (active) setDetailLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedRow, filters]);

  const summaryTiles = useMemo(() => {
    if (!data) return [];
    return SUMMARY_REGISTRY.map(({ key, label }) => ({
      key,
      label,
      metric: data.summary[key],
    }));
  }, [data]);

  return (
    <section className="space-y-5">
      <div className="space-y-3">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">Products / Product 360</p>
            <h1 className="mt-2 text-3xl font-semibold tracking-[-0.05em] text-slate-950">
              Товары и Product 360
            </h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
              Канонический business workspace по товарам, продажам, остаткам, возвратам и наблюдаемым ценам.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Badge variant="soft">{selectedNames.join(", ") || "Все организации"}</Badge>
            <Badge variant="soft">{data?.period.label ?? "Период загружается"}</Badge>
          </div>
        </div>
      </div>

      <Surface className="overflow-visible px-4 py-4 sm:px-5">
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {summaryTiles.map(({ key, label, metric }) => (
            <div key={key} className="rounded-[22px] border border-slate-200 bg-white px-4 py-4">
              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{label}</p>
                <Badge variant="soft">{statusLabel(metric.data_status)}</Badge>
              </div>
              <p
                className={cn(
                  "mt-4 text-3xl font-semibold tracking-[-0.05em]",
                  metricValueTone(metric.data_status),
                )}
              >
                {formatMetricValue(metric.value, metric.currency, metric.data_status)}
              </p>
              <p className="mt-2 min-h-[40px] text-sm leading-5 text-slate-500">
                {metric.note ?? "—"}
              </p>
            </div>
          ))}
        </div>
      </Surface>

      <Surface className="overflow-visible px-4 py-4 sm:px-5">
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Поиск</span>
              <input
                value={query.search}
                onChange={(event) =>
                  setQuery((current) => ({ ...current, search: event.target.value, page: 1 }))
                }
                placeholder="название, код, article, barcode"
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-950 outline-none transition focus:border-violet-300"
              />
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Продажи</span>
              <select
                value={query.hasSales}
                onChange={(event) =>
                  setQuery((current) => ({
                    ...current,
                    hasSales: event.target.value as QueryState["hasSales"],
                    page: 1,
                  }))
                }
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="all">Все</option>
                <option value="yes">Только с продажами</option>
                <option value="no">Без продаж</option>
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Возвраты</span>
              <select
                value={query.hasReturns}
                onChange={(event) =>
                  setQuery((current) => ({
                    ...current,
                    hasReturns: event.target.value as QueryState["hasReturns"],
                    page: 1,
                  }))
                }
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="all">Все</option>
                <option value="yes">Только с возвратами</option>
                <option value="no">Без возвратов</option>
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Сортировка</span>
              <select
                value={query.sortBy}
                onChange={(event) =>
                  setQuery((current) => ({
                    ...current,
                    sortBy: event.target.value as ProductWorkspaceSortBy,
                  }))
                }
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                {SORT_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </label>

            <label className="flex flex-col gap-2">
              <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Порядок</span>
              <select
                value={query.sortOrder}
                onChange={(event) =>
                  setQuery((current) => ({
                    ...current,
                    sortOrder: event.target.value as ProductWorkspaceSortOrder,
                  }))
                }
                className="rounded-[20px] border border-slate-200 bg-white px-4 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
              >
                <option value="desc">Сначала больше</option>
                <option value="asc">Сначала меньше</option>
              </select>
            </label>
          </div>

          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-2">
            <MultiSelect
              label="Категории"
              value={query.categoryIds}
              options={data?.filters.categories ?? []}
              onChange={(next) => setQuery((current) => ({ ...current, categoryIds: next, page: 1 }))}
            />
            <MultiSelect
              label="Stock status"
              value={query.stockStatus}
              options={data?.filters.stock_statuses ?? []}
              onChange={(next) =>
                setQuery((current) => ({
                  ...current,
                  stockStatus: next as ProductWorkspaceStockStatus[],
                  page: 1,
                }))
              }
            />
          </div>
        </div>
      </Surface>

      <Surface className="overflow-hidden">
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 px-5 py-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Products table</p>
            <h2 className="mt-1 text-xl font-semibold tracking-[-0.04em] text-slate-950">
              Продажи, остатки и возвраты по товарам
            </h2>
          </div>
          <Badge variant="soft">{data?.pagination.total_items ?? 0} товаров</Badge>
        </div>

        {error ? (
          <div className="px-5 py-6 text-sm text-rose-600">{error}</div>
        ) : loading ? (
          <div className="px-5 py-6 text-sm text-slate-500">Загрузка товаров...</div>
        ) : !data || data.rows.length === 0 ? (
          <div className="px-5 py-6 text-sm text-slate-500">По выбранному контексту товары не найдены.</div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="min-w-[1520px] border-separate border-spacing-0 text-left text-sm">
                <thead className="sticky top-0 z-10 bg-white">
                  <tr className="text-[11px] uppercase tracking-[0.18em] text-slate-400">
                    {[
                      "Товар",
                      "Код",
                      "Категория",
                      "Организации",
                      "Продано",
                      "Выручка",
                      "Заказы",
                      "Клиенты",
                      "Средняя цена",
                      "Текущий остаток",
                      "Последняя продажа",
                      "Возвраты",
                      "Сумма возвратов",
                      "Stock status",
                      "Качество",
                    ].map((column) => (
                      <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">
                        {column}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.rows.map((row) => (
                    <tr
                      key={row.product_id}
                      className="cursor-pointer transition hover:bg-slate-50/80"
                      onClick={() => {
                        setSelectedRow(row);
                        setDetail(null);
                        setDetailLoading(true);
                      }}
                    >
                      <td className="border-b border-slate-100 px-4 py-4 align-top">
                        <div className="space-y-1">
                          <p className="font-semibold text-slate-950">{row.product_name}</p>
                          <p className="text-xs text-slate-400">
                            {[row.article_code, ...row.barcodes.slice(0, 2)].filter(Boolean).join(" · ") || "—"}
                          </p>
                        </div>
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.product_code ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.category_name ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.organization_names.join(", ") || "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 font-medium text-slate-950">
                        {row.sold_units ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 font-medium text-slate-950">
                        {row.revenue ? formatMoneyValue(row.revenue, "UZS") : "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.orders_count ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.customers_count ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.average_selling_price ? formatMoneyValue(row.average_selling_price, "UZS") : "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.current_stock ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {formatDateTime(row.last_sale)}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.return_quantity ?? "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4 text-slate-600">
                        {row.return_value ? formatMoneyValue(row.return_value, "UZS") : "—"}
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4">
                        <Badge variant={stockBadgeVariant(row.stock_status)}>
                          {stockStatusLabel(row.stock_status)}
                        </Badge>
                      </td>
                      <td className="border-b border-slate-100 px-4 py-4">
                        <Badge variant={qualityBadgeVariant(row.data_quality_status)}>
                          {row.data_quality_status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4">
              <p className="text-sm text-slate-500">
                Показано {data.rows.length} из {data.pagination.total_items}
              </p>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={data.pagination.page <= 1}
                  onClick={() =>
                    setQuery((current) => ({ ...current, page: Math.max(1, current.page - 1) }))
                  }
                  className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 transition hover:border-slate-300 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  Назад
                </button>
                <Badge variant="soft">
                  {data.pagination.page} / {data.pagination.total_pages}
                </Badge>
                <button
                  type="button"
                  disabled={data.pagination.page >= data.pagination.total_pages}
                  onClick={() => setQuery((current) => ({ ...current, page: current.page + 1 }))}
                  className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600 transition hover:border-slate-300 hover:text-slate-900 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  Далее
                </button>
              </div>
            </div>
          </>
        )}
      </Surface>

      <Drawer
        open={selectedRow !== null}
        onClose={() => {
          setSelectedRow(null);
          setDetail(null);
          setDetailError(null);
        }}
        title={selectedRow?.product_name ?? "Product 360"}
        description={selectedRow ? `${selectedRow.product_code ?? "Без кода"} · ${selectedRow.category_name ?? "Без категории"}` : undefined}
        badges={
          selectedRow ? (
            <>
              <Badge variant={stockBadgeVariant(selectedRow.stock_status)}>
                {stockStatusLabel(selectedRow.stock_status)}
              </Badge>
              <Badge variant={qualityBadgeVariant(selectedRow.data_quality_status)}>
                {selectedRow.data_quality_status}
              </Badge>
            </>
          ) : null
        }
        className="max-w-[min(48rem,100vw)]"
      >
        {detailError ? (
          <p className="text-sm text-rose-600">{detailError}</p>
        ) : detailLoading || !detail ? (
          <p className="text-sm text-slate-500">Загрузка Product 360...</p>
        ) : (
          <div className="space-y-6">
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
              {[
                { label: "Выручка", value: detail.overview.revenue.value, currency: detail.overview.revenue.currency },
                { label: "Продано единиц", value: detail.overview.sold_units.value, currency: null },
                { label: "Средняя цена", value: detail.overview.average_selling_price.value, currency: detail.overview.average_selling_price.currency },
                { label: "Текущий остаток", value: detail.overview.current_stock.value, currency: null },
              ].map((item) => (
                <div key={item.label} className="rounded-[20px] border border-slate-200 bg-white px-4 py-4">
                  <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">{item.label}</p>
                  <p className="mt-3 text-xl font-semibold tracking-[-0.04em] text-slate-950">
                    {formatMetricValue(item.value, item.currency)}
                  </p>
                </div>
              ))}
            </div>

            {detail.ai_summary ? (
              <Surface className="px-5 py-4">
                <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">AI Summary</p>
                <p className="mt-2 text-sm leading-6 text-slate-700">{detail.ai_summary}</p>
              </Surface>
            ) : null}

            <div className="grid gap-4 xl:grid-cols-2">
              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Продажи</h3>
                </div>
                <div className="max-h-[320px] overflow-y-auto">
                  <table className="min-w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500">
                      <tr>
                        {["Дата", "Организация", "Сделка", "Клиент", "Qty", "Цена", "Сумма"].map((column) => (
                          <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {detail.sales.map((item) => (
                        <tr key={item.sale_item_id} className="border-b border-slate-100">
                          <td className="px-4 py-3 text-slate-600">{formatDateTime(item.business_date)}</td>
                          <td className="px-4 py-3 text-slate-950">{item.organization_name}</td>
                          <td className="px-4 py-3 font-medium text-slate-950">{item.order_number ?? item.sale_number ?? item.deal_id ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.customer_name ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.sold_quantity ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.unit_price ? formatMoneyValue(item.unit_price, item.currency_code) : "—"}</td>
                          <td className="px-4 py-3 font-medium text-slate-950">{item.amount ? formatMoneyValue(item.amount, item.currency_code) : "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">По организациям</h3>
                </div>
                <div className="max-h-[320px] overflow-y-auto px-5 py-4">
                  <div className="space-y-3">
                    {detail.organizations.map((item) => (
                      <div key={item.organization_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-medium text-slate-950">{item.organization_name}</p>
                            <p className="mt-1 text-sm text-slate-500">
                              Выручка {item.revenue ? formatMoneyValue(item.revenue, "UZS") : "—"} · Продано {item.sold_units ?? "—"} · Остаток {item.current_stock ?? "—"}
                            </p>
                          </div>
                          <Badge variant={stockBadgeVariant(item.stock_status)}>
                            {stockStatusLabel(item.stock_status)}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Клиенты</h3>
                </div>
                <div className="max-h-[320px] overflow-y-auto">
                  <table className="min-w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500">
                      <tr>
                        {["Клиент", "Организация", "Qty", "Выручка", "Заказы", "Последняя покупка"].map((column) => (
                          <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {detail.customers.map((item) => (
                        <tr key={item.customer_id} className="border-b border-slate-100">
                          <td className="px-4 py-3 font-medium text-slate-950">{item.customer_name}</td>
                          <td className="px-4 py-3 text-slate-600">{item.organization_name}</td>
                          <td className="px-4 py-3 text-slate-600">{item.sold_units ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-950">{item.revenue ? formatMoneyValue(item.revenue, "UZS") : "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.orders_count ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{formatDateTime(item.last_purchase)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Текущий склад</h3>
                </div>
                <div className="max-h-[320px] overflow-y-auto">
                  <table className="min-w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500">
                      <tr>
                        {["Организация", "Склад", "Qty", "Available", "Reserved", "Дата snapshot"].map((column) => (
                          <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {detail.inventory.map((item) => (
                        <tr key={item.inventory_balance_id} className="border-b border-slate-100">
                          <td className="px-4 py-3 text-slate-950">{item.organization_name}</td>
                          <td className="px-4 py-3 text-slate-600">{item.warehouse_name ?? item.warehouse_code ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.quantity ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.available_quantity ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{item.reserved_quantity ?? "—"}</td>
                          <td className="px-4 py-3 text-slate-600">{formatDateOnly(item.snapshot_date)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Surface>
            </div>

            <div className="grid gap-4 xl:grid-cols-2">
              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Цены</h3>
                </div>
                <div className="max-h-[280px] overflow-y-auto">
                  <table className="min-w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500">
                      <tr>
                        {["Источник", "Организация", "Тип", "Цена", "Дата", "Комментарий"].map((column) => (
                          <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {detail.prices.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-4 text-slate-500">
                            Нет подтверждённой прайс-лист цены. Показываются только наблюдаемые transaction sale prices, если они появятся.
                          </td>
                        </tr>
                      ) : (
                        detail.prices.map((item, index) => (
                          <tr key={`${item.source_type}-${item.organization_id}-${item.effective_date ?? index}`} className="border-b border-slate-100">
                            <td className="px-4 py-3 text-slate-600">{item.source_type}</td>
                            <td className="px-4 py-3 text-slate-950">{item.organization_name}</td>
                            <td className="px-4 py-3 text-slate-600">{item.price_type_name ?? item.price_type_code ?? "—"}</td>
                            <td className="px-4 py-3 text-slate-950">{item.price ? formatMoneyValue(item.price, item.currency_code) : "—"}</td>
                            <td className="px-4 py-3 text-slate-600">{formatDateTime(item.effective_date)}</td>
                            <td className="px-4 py-3 text-slate-600">{item.note ?? "—"}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </Surface>

              <Surface className="overflow-hidden">
                <div className="border-b border-slate-200 px-5 py-4">
                  <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Возвраты</h3>
                </div>
                <div className="max-h-[280px] overflow-y-auto">
                  <table className="min-w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500">
                      <tr>
                        {["Дата", "Организация", "Документ", "Клиент", "Qty", "Сумма"].map((column) => (
                          <th key={column} className="border-b border-slate-200 px-4 py-3 font-medium">{column}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {detail.returns.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-4 py-4 text-slate-500">Возвраты по товару не найдены.</td>
                        </tr>
                      ) : (
                        detail.returns.map((item) => (
                          <tr key={item.return_item_id} className="border-b border-slate-100">
                            <td className="px-4 py-3 text-slate-600">{formatDateTime(item.return_at)}</td>
                            <td className="px-4 py-3 text-slate-950">{item.organization_name}</td>
                            <td className="px-4 py-3 font-medium text-slate-950">{item.return_number ?? "Возврат"}</td>
                            <td className="px-4 py-3 text-slate-600">{item.customer_name ?? "—"}</td>
                            <td className="px-4 py-3 text-slate-600">{item.returned_quantity ?? "—"}</td>
                            <td className="px-4 py-3 text-slate-950">{item.amount ? formatMoneyValue(item.amount, item.currency_code) : "—"}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </Surface>
            </div>

            <Surface className="overflow-hidden">
              <div className="border-b border-slate-200 px-5 py-4">
                <h3 className="text-lg font-semibold tracking-[-0.04em] text-slate-950">Timeline и ограничения</h3>
              </div>
              <div className="grid gap-4 px-5 py-4 xl:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
                <div className="max-h-[340px] overflow-y-auto">
                  <div className="space-y-3">
                    {detail.timeline.map((item) => (
                      <div key={item.event_id} className="rounded-[18px] border border-slate-200 bg-white px-4 py-3">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="font-medium text-slate-950">{item.title}</p>
                            <p className="mt-1 text-sm text-slate-500">
                              {item.organization_name ?? "—"} · {formatDateTime(item.happened_at)}
                            </p>
                          </div>
                          <Badge variant="soft">{item.event_type}</Badge>
                        </div>
                        <p className="mt-3 text-sm text-slate-600">
                          {[item.description, item.quantity ? `Qty ${item.quantity}` : null, item.amount ? formatMoneyValue(item.amount, item.currency_code) : null]
                            .filter(Boolean)
                            .join(" · ") || "—"}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="rounded-[20px] border border-slate-200 bg-white px-4 py-4">
                    <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">Data quality</p>
                    <p className="mt-3 text-sm leading-6 text-slate-700">
                      {detail.provenance.data_quality_status}
                    </p>
                    <p className="mt-2 text-sm leading-6 text-slate-500">
                      Источник: {detail.provenance.source_endpoint}
                    </p>
                    <p className="mt-1 text-sm leading-6 text-slate-500">
                      External ID: {detail.provenance.source_external_id}
                    </p>
                  </div>
                  <div className="rounded-[20px] border border-slate-200 bg-white px-4 py-4">
                    <p className="text-[11px] uppercase tracking-[0.22em] text-slate-400">Ограничения</p>
                    <ul className="mt-3 space-y-2 text-sm leading-6 text-slate-600">
                      {detail.limitations.length === 0 ? (
                        <li>Явных source limitations для текущего товара не найдено.</li>
                      ) : (
                        detail.limitations.map((item) => <li key={item}>• {item}</li>)
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            </Surface>
          </div>
        )}
      </Drawer>
    </section>
  );
}
