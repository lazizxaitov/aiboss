"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

import {
  useBusinessContext,
  useSelectedOrganizationNames,
} from "@/components/business/business-context-provider";
import { Badge } from "@/components/ui/badge";
import { Drawer } from "@/components/ui/drawer";
import { Surface } from "@/components/ui/surface";
import { cn } from "@/lib/cn";
import {
  getVisitsWorkspace,
  getVisitsWorkspaceDetail,
  type AnalyticsDataStatus,
  type VisitsWorkspaceCapabilityItem,
  type VisitsWorkspaceDetail,
  type VisitsWorkspaceFilters,
  type VisitsWorkspaceSalesRepRow,
  type VisitsWorkspaceSortBy,
  type VisitsWorkspaceSortOrder,
  type VisitsWorkspaceTab,
  type VisitsWorkspaceVisitRow,
  type VisitsWorkspaceWorkingZoneRow,
} from "@/lib/core-api";

const PAGE_SIZE = 25;

const SUMMARY_REGISTRY = [
  { key: "visits", label: "Визитов" },
  { key: "unique_customers", label: "Уникальных клиентов" },
  { key: "sales_reps", label: "Торговых представителей" },
  { key: "working_zones", label: "Рабочих зон" },
  { key: "planned_visits", label: "Плановых визитов" },
  { key: "completed_visits", label: "Completed/approved" },
  { key: "average_duration", label: "Средняя длительность" },
  { key: "visit_conversion", label: "Конверсия визита" },
] as const;

const TAB_LABELS: Record<VisitsWorkspaceTab, string> = {
  visits: "Визиты",
  sales_reps: "Торговые представители",
  working_zones: "Рабочие зоны",
  capabilities: "Покрытие данных",
};

const SORT_OPTIONS: Array<{ value: VisitsWorkspaceSortBy; label: string }> = [
  { value: "date", label: "Дата" },
  { value: "customer", label: "Клиент" },
  { value: "sales_rep", label: "Торговый представитель" },
  { value: "working_zone", label: "Рабочая зона" },
  { value: "status", label: "Статус" },
  { value: "organization", label: "Организация" },
];

type QueryState = {
  tab: VisitsWorkspaceTab;
  search: string;
  customer: string[];
  salesRep: string[];
  workingZone: string[];
  status: string[];
  planned: string[];
  dataQuality: Array<"verified" | "partial" | "unresolved" | "unsafe">;
  sortBy: VisitsWorkspaceSortBy;
  sortOrder: VisitsWorkspaceSortOrder;
  page: number;
};

type DetailState = VisitsWorkspaceVisitRow | null;

function buildWorkspaceFilters(
  businessState: ReturnType<typeof useBusinessContext>["state"],
  query: QueryState,
): VisitsWorkspaceFilters {
  return {
    organizationIds: businessState.selectedOrganizationIds,
    period: businessState.period.preset,
    dateFrom: businessState.period.dateFrom,
    dateTo: businessState.period.dateTo,
    tab: query.tab,
    search: query.search || null,
    customer: query.customer,
    salesRep: query.salesRep,
    workingZone: query.workingZone,
    status: query.status,
    planned: query.planned,
    dataQuality: query.dataQuality,
    sortBy: query.sortBy,
    sortOrder: query.sortOrder,
    page: query.page,
    pageSize: PAGE_SIZE,
  };
}

function formatDateTime(value: string | null) {
  if (!value) return "—";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function formatMetricValue(
  value: string | number | null | undefined,
  unit: string,
  status?: AnalyticsDataStatus,
) {
  if (status === "NOT_AVAILABLE") return "Недоступно";
  if (status === "NO_DATA" && value == null) return "Нет данных";
  if (value == null) return "—";
  if (unit === "seconds") {
    const seconds = Number(value);
    if (!Number.isFinite(seconds)) return "—";
    const minutes = Math.floor(seconds / 60);
    const remainder = seconds % 60;
    if (minutes <= 0) return `${remainder} сек`;
    return remainder > 0 ? `${minutes} мин ${remainder} сек` : `${minutes} мин`;
  }
  if (unit === "percent") return `${value}%`;
  return String(value);
}

function statusLabel(status: AnalyticsDataStatus) {
  switch (status) {
    case "AVAILABLE":
      return "Подтверждено";
    case "PARTIAL":
      return "Частично";
    case "NO_DATA":
      return "Нет данных";
    case "NO_VERIFIED_DATA":
      return "Нет подтверждённых данных";
    case "UNRESOLVED":
      return "Неразрешено";
    case "NOT_AVAILABLE":
      return "Недоступно";
    default:
      return status;
  }
}

function qualityVariant(status: "verified" | "partial" | "unresolved" | "unsafe") {
  if (status === "verified") return "accent" as const;
  if (status === "partial") return "soft" as const;
  if (status === "unresolved") return "neutral" as const;
  return "dark" as const;
}

function capabilityVariant(status: string) {
  if (status === "AVAILABLE") return "accent" as const;
  if (status === "PARTIAL") return "soft" as const;
  if (status === "NO_DATA" || status === "NO_DATA_IN_CURRENT_RAW") return "neutral" as const;
  return "dark" as const;
}

function plannedLabel(value: boolean | null) {
  if (value === true) return "Плановый";
  if (value === false) return "Вне плана";
  return "Не указан";
}

function MultiSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string[];
  options: Array<{ value: string; label: string; count?: number }>;
  onChange: (next: string[]) => void;
}) {
  return (
    <label className="flex min-w-[180px] flex-col gap-2">
      <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">{label}</span>
      <select
        multiple
        value={value}
        onChange={(event) => {
          const next = Array.from(event.target.selectedOptions).map((item) => item.value);
          onChange(next);
        }}
        className="min-h-[116px] rounded-[20px] border border-slate-200 bg-white px-3 py-3 text-sm text-slate-700 outline-none transition focus:border-violet-300"
      >
        {options.map((option) => (
          <option key={`${label}-${option.value}`} value={option.value}>
            {option.label}
            {typeof option.count === "number" ? ` (${option.count})` : ""}
          </option>
        ))}
      </select>
    </label>
  );
}

function renderVisitsTable(
  rows: VisitsWorkspaceVisitRow[],
  onSelect: (row: VisitsWorkspaceVisitRow) => void,
) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-left text-sm">
        <thead className="border-b border-slate-200 text-xs uppercase tracking-[0.22em] text-slate-400">
          <tr>
            <th className="px-5 py-4 font-medium">Визит</th>
            <th className="px-5 py-4 font-medium">Дата</th>
            <th className="px-5 py-4 font-medium">Организация</th>
            <th className="px-5 py-4 font-medium">Клиент</th>
            <th className="px-5 py-4 font-medium">Представитель</th>
            <th className="px-5 py-4 font-medium">Зона</th>
            <th className="px-5 py-4 font-medium">Статус</th>
            <th className="px-5 py-4 font-medium">План</th>
            <th className="px-5 py-4 font-medium">Начало</th>
            <th className="px-5 py-4 font-medium">Конец</th>
            <th className="px-5 py-4 font-medium">Длительность</th>
            <th className="px-5 py-4 font-medium">Покрытие</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr
              key={row.visit_id}
              className="cursor-pointer border-b border-slate-100 transition hover:bg-slate-50 last:border-b-0"
              onClick={() => onSelect(row)}
            >
              <td className="px-5 py-4">
                <div className="font-medium text-slate-950">
                  {row.source_visit_id || row.source_external_id}
                </div>
                <div className="mt-1 text-xs text-slate-500">
                  {[
                    row.has_comments ? "коммент." : null,
                    row.has_media ? "фото" : null,
                    row.has_visit_stock ? "остатки" : null,
                    row.has_quiz_answers ? "анкета" : null,
                    row.has_equipment ? "оборуд." : null,
                  ]
                    .filter(Boolean)
                    .join(" · ") || "только header"}
                </div>
              </td>
              <td className="px-5 py-4 text-slate-700">{formatDateTime(row.business_date)}</td>
              <td className="px-5 py-4 text-slate-700">{row.organization_name}</td>
              <td className="px-5 py-4">
                <div className="font-medium text-slate-900">{row.customer_name ?? "—"}</div>
                <div className="mt-1 text-xs text-slate-500">{row.customer_code ?? row.customer_external_id ?? "—"}</div>
              </td>
              <td className="px-5 py-4 text-slate-700">{row.sales_rep_name ?? "—"}</td>
              <td className="px-5 py-4 text-slate-700">{row.working_zone_name ?? "—"}</td>
              <td className="px-5 py-4">
                <div className="font-medium text-slate-900">{row.display_status}</div>
                <div className="mt-1 text-xs text-slate-500">{row.normalized_status}</div>
              </td>
              <td className="px-5 py-4 text-slate-700">{plannedLabel(row.is_planned)}</td>
              <td className="px-5 py-4 text-slate-700">{formatDateTime(row.start_time)}</td>
              <td className="px-5 py-4 text-slate-700">{formatDateTime(row.end_time)}</td>
              <td className="px-5 py-4 text-slate-700">
                {row.duration_seconds == null ? "Не зафиксирована" : formatMetricValue(row.duration_seconds, "seconds")}
              </td>
              <td className="px-5 py-4">
                <Badge variant={qualityVariant(row.data_quality_status)}>
                  {row.data_quality_status}
                </Badge>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderSalesRepsTable(rows: VisitsWorkspaceSalesRepRow[]) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-left text-sm">
        <thead className="border-b border-slate-200 text-xs uppercase tracking-[0.22em] text-slate-400">
          <tr>
            <th className="px-5 py-4 font-medium">Представитель</th>
            <th className="px-5 py-4 font-medium">Организации</th>
            <th className="px-5 py-4 font-medium">Визиты</th>
            <th className="px-5 py-4 font-medium">Клиенты</th>
            <th className="px-5 py-4 font-medium">Зоны</th>
            <th className="px-5 py-4 font-medium">Плановые</th>
            <th className="px-5 py-4 font-medium">Conversion</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.sales_rep_id} className="border-b border-slate-100 last:border-b-0">
              <td className="px-5 py-4">
                <div className="font-medium text-slate-950">{row.sales_rep_name}</div>
                <div className="mt-1 text-xs text-slate-500">{row.sales_rep_key}</div>
              </td>
              <td className="px-5 py-4 text-slate-700">{row.organization_names.join(", ") || "—"}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.visits.value, row.visits.unit, row.visits.data_status)}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.unique_customers.value, row.unique_customers.unit, row.unique_customers.data_status)}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.working_zones.value, row.working_zones.unit, row.working_zones.data_status)}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.planned_visits.value, row.planned_visits.unit, row.planned_visits.data_status)}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.visit_conversion.value, row.visit_conversion.unit, row.visit_conversion.data_status)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderWorkingZonesTable(rows: VisitsWorkspaceWorkingZoneRow[]) {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-left text-sm">
        <thead className="border-b border-slate-200 text-xs uppercase tracking-[0.22em] text-slate-400">
          <tr>
            <th className="px-5 py-4 font-medium">Рабочая зона</th>
            <th className="px-5 py-4 font-medium">Организации</th>
            <th className="px-5 py-4 font-medium">Визиты</th>
            <th className="px-5 py-4 font-medium">Клиенты</th>
            <th className="px-5 py-4 font-medium">Представители</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.working_zone_id} className="border-b border-slate-100 last:border-b-0">
              <td className="px-5 py-4">
                <div className="font-medium text-slate-950">{row.working_zone_name}</div>
                <div className="mt-1 text-xs text-slate-500">{row.working_zone_key}</div>
              </td>
              <td className="px-5 py-4 text-slate-700">{row.organization_names.join(", ") || "—"}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.visits.value, row.visits.unit, row.visits.data_status)}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.unique_customers.value, row.unique_customers.unit, row.unique_customers.data_status)}</td>
              <td className="px-5 py-4 text-slate-700">{formatMetricValue(row.sales_reps.value, row.sales_reps.unit, row.sales_reps.data_status)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function renderCapabilities(rows: VisitsWorkspaceCapabilityItem[]) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {rows.map((row) => (
        <Surface key={row.key} className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-lg font-semibold tracking-[-0.04em] text-slate-950">{row.label}</p>
              <p className="mt-2 text-sm leading-6 text-slate-500">{row.message}</p>
            </div>
            <Badge variant={capabilityVariant(row.status)}>{row.status}</Badge>
          </div>
          {typeof row.count === "number" ? (
            <p className="mt-4 text-sm text-slate-600">Записей: {row.count}</p>
          ) : null}
        </Surface>
      ))}
    </div>
  );
}

export function VisitsWorkspacePage() {
  const business = useBusinessContext();
  const selectedNames = useSelectedOrganizationNames();
  const [query, setQuery] = useState<QueryState>({
    tab: "visits",
    search: "",
    customer: [],
    salesRep: [],
    workingZone: [],
    status: [],
    planned: [],
    dataQuality: [],
    sortBy: "date",
    sortOrder: "desc",
    page: 1,
  });
  const [data, setData] = useState<Awaited<ReturnType<typeof getVisitsWorkspace>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedRow, setSelectedRow] = useState<DetailState>(null);
  const [detail, setDetail] = useState<VisitsWorkspaceDetail | null>(null);
  const [detailError, setDetailError] = useState<string | null>(null);

  const filters = useMemo(
    () => buildWorkspaceFilters(business.state, query),
    [business.state, query],
  );

  const updateQuery = (updater: (current: QueryState) => QueryState) => {
    setRefreshing(true);
    setError(null);
    setQuery(updater);
  };

  const handleSelectRow = (row: VisitsWorkspaceVisitRow) => {
    setDetail(null);
    setDetailError(null);
    setSelectedRow(row);
  };

  useEffect(() => {
    let active = true;
    void getVisitsWorkspace(filters)
      .then((response) => {
        if (!active) return;
        setData(response);
      })
      .catch((reason) => {
        if (!active) return;
        setError(reason instanceof Error ? reason.message : "Не удалось загрузить визиты.");
        setData(null);
      })
      .finally(() => {
        if (active) setRefreshing(false);
      });
    return () => {
      active = false;
    };
  }, [filters]);

  useEffect(() => {
    if (!selectedRow) return;
    let active = true;
    void getVisitsWorkspaceDetail(selectedRow.visit_id, filters)
      .then((response) => {
        if (!active) return;
        setDetail(response);
      })
      .catch((reason) => {
        if (!active) return;
        setDetailError(reason instanceof Error ? reason.message : "Не удалось загрузить Visit 360.");
        setDetail(null);
      })
    return () => {
      active = false;
    };
  }, [selectedRow, filters]);

  const summaryCards = useMemo(() => {
    if (!data) return [];
    return SUMMARY_REGISTRY.map((item) => ({
      ...item,
      metric: data.summary[item.key],
    }));
  }, [data]);

  const emptyMessage = useMemo(() => {
    if (!data) return null;
    if (query.tab === "capabilities") return null;
    const count = data.pagination.total_items;
    if (count > 0) return null;
    if (selectedNames.length === 1) {
      return `В выбранном контексте для ${selectedNames[0]} визиты не найдены.`;
    }
    return "В выбранном контексте визиты не найдены.";
  }, [data, query.tab, selectedNames]);

  return (
    <div className="flex h-full min-h-0 flex-col gap-4">
      <Surface className="px-6 py-5">
        <div className="flex flex-col gap-5 xl:flex-row xl:items-start xl:justify-between">
          <div className="max-w-3xl">
            <p className="text-[11px] uppercase tracking-[0.32em] text-slate-400">
              Field Sales
            </p>
            <h1 className="mt-3 text-[34px] font-semibold tracking-[-0.06em] text-slate-950">
              Визиты и полевые продажи
            </h1>
            <p className="mt-3 text-sm leading-6 text-slate-500">
              Канонические визиты, торговые представители и рабочие зоны по выбранным организациям.
              Конверсия визита отключена, пока нет детерминированной связи визит → продажа.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 xl:w-[440px]">
            {summaryCards.slice(0, 4).map((card) => (
              <div
                key={card.key}
                className="rounded-[22px] border border-slate-200 bg-[#f8fbff] px-4 py-4"
              >
                <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">{card.label}</p>
                <p className="mt-3 text-2xl font-semibold tracking-[-0.05em] text-slate-950">
                  {formatMetricValue(card.metric.value, card.metric.unit, card.metric.data_status)}
                </p>
                <p className="mt-2 text-xs text-slate-500">
                  {card.metric.note ?? statusLabel(card.metric.data_status)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </Surface>

      <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
        <Surface className="px-6 py-5">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">Контекст</p>
              <h2 className="mt-2 text-xl font-semibold tracking-[-0.04em] text-slate-950">
                {selectedNames.length === 0 ? "Все организации" : selectedNames.join(", ")}
              </h2>
              <p className="mt-2 text-sm text-slate-500">
                {data?.period.label ?? "Загрузка периода..."}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              {(data?.tabs ?? []).map((tab) => (
                <button
                  key={tab.tab}
                  type="button"
                  onClick={() =>
                    updateQuery((current) => ({
                      ...current,
                      tab: tab.tab,
                      page: 1,
                    }))
                  }
                  className={cn(
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition",
                    query.tab === tab.tab
                      ? "border-slate-900 bg-slate-900 text-white"
                      : "border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:text-slate-950",
                  )}
                >
                  <span>{TAB_LABELS[tab.tab]}</span>
                  <span className="text-xs opacity-80">{tab.count}</span>
                </button>
              ))}
            </div>
          </div>
        </Surface>

        <Surface className="px-6 py-5">
          <p className="text-[11px] uppercase tracking-[0.28em] text-slate-400">Статус</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {(data?.data_quality.items ?? []).map((item) => (
              <Badge key={`${item.metric_key}-${item.data_status}`} variant="soft">
                {item.metric_key}: {item.data_status}
              </Badge>
            ))}
          </div>
          <div className="mt-4 space-y-2 text-sm text-slate-500">
            {(data?.data_quality.notes ?? []).map((note) => (
              <p key={note}>{note}</p>
            ))}
          </div>
        </Surface>
      </div>

      <Surface className="px-6 py-5">
        <div className="flex flex-wrap gap-4">
          <label className="min-w-[240px] flex-1">
            <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Поиск</span>
              <input
              value={query.search}
              onChange={(event) =>
                updateQuery((current) => ({ ...current, search: event.target.value, page: 1 }))
              }
              placeholder="ID визита, клиент, представитель, зона"
              className="mt-2 h-12 w-full rounded-[18px] border border-slate-200 bg-white px-4 text-sm text-slate-700 outline-none transition focus:border-violet-300"
            />
          </label>

          <label className="flex min-w-[180px] flex-col gap-2">
            <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Сортировка</span>
            <select
              value={query.sortBy}
              onChange={(event) =>
                updateQuery((current) => ({
                  ...current,
                  sortBy: event.target.value as VisitsWorkspaceSortBy,
                  page: 1,
                }))
              }
              className="h-12 rounded-[18px] border border-slate-200 bg-white px-4 text-sm text-slate-700 outline-none transition focus:border-violet-300"
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>

          <label className="flex min-w-[160px] flex-col gap-2">
            <span className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Порядок</span>
            <select
              value={query.sortOrder}
              onChange={(event) =>
                updateQuery((current) => ({
                  ...current,
                  sortOrder: event.target.value as VisitsWorkspaceSortOrder,
                  page: 1,
                }))
              }
              className="h-12 rounded-[18px] border border-slate-200 bg-white px-4 text-sm text-slate-700 outline-none transition focus:border-violet-300"
            >
              <option value="desc">Сначала новые</option>
              <option value="asc">Сначала старые</option>
            </select>
          </label>
        </div>

        <div className="mt-5 flex flex-wrap gap-4">
          <MultiSelect
            label="Клиенты"
            value={query.customer}
            options={data?.filters.customers ?? []}
            onChange={(value) => updateQuery((current) => ({ ...current, customer: value, page: 1 }))}
          />
          <MultiSelect
            label="Торговые представители"
            value={query.salesRep}
            options={data?.filters.sales_reps ?? []}
            onChange={(value) => updateQuery((current) => ({ ...current, salesRep: value, page: 1 }))}
          />
          <MultiSelect
            label="Рабочие зоны"
            value={query.workingZone}
            options={data?.filters.working_zones ?? []}
            onChange={(value) => updateQuery((current) => ({ ...current, workingZone: value, page: 1 }))}
          />
          <MultiSelect
            label="Статус"
            value={query.status}
            options={data?.filters.statuses ?? []}
            onChange={(value) => updateQuery((current) => ({ ...current, status: value, page: 1 }))}
          />
          <MultiSelect
            label="План"
            value={query.planned}
            options={data?.filters.planned ?? []}
            onChange={(value) => updateQuery((current) => ({ ...current, planned: value, page: 1 }))}
          />
          <MultiSelect
            label="Качество"
            value={query.dataQuality}
            options={data?.filters.data_quality ?? []}
            onChange={(value) =>
              updateQuery((current) => ({
                ...current,
                dataQuality: value as QueryState["dataQuality"],
                page: 1,
              }))
            }
          />
        </div>
      </Surface>

      <Surface className="min-h-0 flex-1 overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div>
            <p className="text-[11px] uppercase tracking-[0.26em] text-slate-400">
              {TAB_LABELS[query.tab]}
            </p>
            <p className="mt-2 text-sm text-slate-500">
              {data ? `${data.pagination.total_items} строк в текущем контексте` : "Загрузка..."}
            </p>
          </div>
          <Badge variant="soft">
            {refreshing || (!data && !error)
              ? "Обновление..."
              : error
                ? "Ошибка"
                : statusLabel(data?.data_quality.overall_status ?? "NO_DATA")}
          </Badge>
        </div>

        <div className="min-h-0 overflow-auto">
          {error ? (
            <div className="px-6 py-6 text-sm text-rose-600">{error}</div>
          ) : !data && !error ? (
            <div className="px-6 py-6 text-sm text-slate-500">Загрузка workspace...</div>
          ) : emptyMessage ? (
            <div className="px-6 py-6 text-sm text-slate-500">{emptyMessage}</div>
          ) : query.tab === "visits" ? (
            renderVisitsTable(data?.rows.visits ?? [], handleSelectRow)
          ) : query.tab === "sales_reps" ? (
            renderSalesRepsTable(data?.rows.sales_reps ?? [])
          ) : query.tab === "working_zones" ? (
            renderWorkingZonesTable(data?.rows.working_zones ?? [])
          ) : (
            <div className="px-6 py-6">{renderCapabilities(data?.rows.capabilities ?? [])}</div>
          )}
        </div>

        <div className="flex items-center justify-between border-t border-slate-200 px-6 py-4 text-sm text-slate-500">
          <div>
            Страница {data?.pagination.page ?? 1} из {data?.pagination.total_pages ?? 1}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={(data?.pagination.page ?? 1) <= 1}
              onClick={() =>
                updateQuery((current) => ({
                  ...current,
                  page: Math.max(1, current.page - 1),
                }))
              }
              className="rounded-full border border-slate-200 px-4 py-2 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Назад
            </button>
            <button
              type="button"
              disabled={(data?.pagination.page ?? 1) >= (data?.pagination.total_pages ?? 1)}
              onClick={() =>
                updateQuery((current) => ({
                  ...current,
                  page: current.page + 1,
                }))
              }
              className="rounded-full border border-slate-200 px-4 py-2 disabled:cursor-not-allowed disabled:opacity-40"
            >
              Дальше
            </button>
          </div>
        </div>
      </Surface>

      <Drawer
        open={selectedRow !== null}
        onClose={() => {
          setSelectedRow(null);
          setDetail(null);
          setDetailError(null);
        }}
        title={detail?.row.source_visit_id || detail?.row.source_external_id || "Визит"}
        description={
          detail?.row.business_date
            ? `${detail.row.organization_name} · ${formatDateTime(detail.row.business_date)}`
            : detail?.row.organization_name
        }
        badges={
          detail ? (
            <>
              <Badge variant={qualityVariant(detail.row.data_quality_status)}>
                {detail.row.data_quality_status}
              </Badge>
              <Badge variant="soft">{detail.row.display_status}</Badge>
              <Badge variant="soft">{plannedLabel(detail.row.is_planned)}</Badge>
            </>
          ) : null
        }
      >
        {selectedRow !== null && detail === null && detailError === null ? (
          <p className="text-sm text-slate-500">Загрузка Visit 360...</p>
        ) : detailError ? (
          <p className="text-sm text-rose-600">{detailError}</p>
        ) : detail ? (
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <Surface className="p-5">
                <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Клиент</p>
                <p className="mt-3 text-lg font-semibold tracking-[-0.03em] text-slate-950">
                  {detail.customer.customer_name ?? "Не определён"}
                </p>
                <p className="mt-2 text-sm text-slate-500">
                  {detail.customer.customer_code ?? detail.customer.customer_external_id ?? "—"}
                </p>
                {detail.customer.detail_href ? (
                  <Link href={detail.customer.detail_href} className="mt-4 inline-flex text-sm font-medium text-violet-600 hover:text-violet-700">
                    Открыть Customer 360
                  </Link>
                ) : null}
              </Surface>

              <Surface className="p-5">
                <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Полевой контекст</p>
                <div className="mt-3 space-y-3 text-sm text-slate-600">
                  <p><span className="font-medium text-slate-900">Торговый представитель:</span> {detail.sales_rep.sales_rep_name ?? "Не определён"}</p>
                  <p><span className="font-medium text-slate-900">Рабочая зона:</span> {detail.working_zone.working_zone_name ?? "Не определена"}</p>
                  <p><span className="font-medium text-slate-900">Длительность:</span> {detail.row.duration_seconds == null ? "Длительность не зафиксирована в текущих данных" : formatMetricValue(detail.row.duration_seconds, "seconds")}</p>
                </div>
              </Surface>
            </div>

            <Surface className="p-5">
              <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Ограничения источника</p>
              <div className="mt-4 space-y-2 text-sm leading-6 text-slate-600">
                {detail.limitations.map((item) => (
                  <p key={item}>{item}</p>
                ))}
              </div>
            </Surface>

            <Surface className="p-5">
              <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Вложенные данные</p>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <div className="rounded-[20px] border border-slate-200 p-4">
                  <p className="font-medium text-slate-900">Остатки в точке</p>
                  <p className="mt-2 text-sm text-slate-500">{detail.visit_stocks.length > 0 ? `${detail.visit_stocks.length} строк` : "Не загружены"}</p>
                </div>
                <div className="rounded-[20px] border border-slate-200 p-4">
                  <p className="font-medium text-slate-900">Анкеты</p>
                  <p className="mt-2 text-sm text-slate-500">{detail.quiz_answers.length > 0 ? `${detail.quiz_answers.length} ответов` : "Не загружены"}</p>
                </div>
                <div className="rounded-[20px] border border-slate-200 p-4">
                  <p className="font-medium text-slate-900">Оборудование</p>
                  <p className="mt-2 text-sm text-slate-500">{detail.equipments.length > 0 ? `${detail.equipments.length} записей` : "Не загружено"}</p>
                </div>
                <div className="rounded-[20px] border border-slate-200 p-4">
                  <p className="font-medium text-slate-900">Фото и медиа</p>
                  <p className="mt-2 text-sm text-slate-500">{detail.media_assets.length > 0 ? `${detail.media_assets.length} файлов` : "Не загружены"}</p>
                </div>
              </div>
            </Surface>

            <Surface className="p-5">
              <p className="text-[11px] uppercase tracking-[0.24em] text-slate-400">Provenance</p>
              <div className="mt-4 grid gap-3 md:grid-cols-2 text-sm text-slate-600">
                <p><span className="font-medium text-slate-900">Endpoint:</span> {detail.provenance.source_endpoint}</p>
                <p><span className="font-medium text-slate-900">Source external ID:</span> {detail.provenance.source_external_id}</p>
                <p><span className="font-medium text-slate-900">Raw record:</span> {detail.provenance.source_raw_record_id ?? "—"}</p>
                <p><span className="font-medium text-slate-900">Request filial:</span> {detail.provenance.request_filial_id ?? "—"}</p>
                <p><span className="font-medium text-slate-900">Response filial:</span> {detail.provenance.response_filial_id ?? "—"}</p>
                <p><span className="font-medium text-slate-900">Project:</span> {detail.provenance.request_project_code ?? "—"}</p>
              </div>
            </Surface>
          </div>
        ) : null}
      </Drawer>
    </div>
  );
}
